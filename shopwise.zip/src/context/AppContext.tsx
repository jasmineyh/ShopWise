import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Store,
  ConditionSnapshot,
  Recommendation,
  SavedTrip,
  Alert,
  UserProfile,
  NavigationTab,
  StoreCategory,
  HourlyForecast,
  CommunityReport,
  ShoppingList,
  ShoppingListItem,
  SavedLocation,
  ActiveLocation,
  PlannedDeparture,
  DeparturePreset
} from '../types';
import {
  INITIAL_STORES,
  INITIAL_CONDITION_SNAPSHOTS,
  INITIAL_USER_PROFILE,
  INITIAL_SAVED_TRIPS,
  INITIAL_ALERTS,
} from '../data/mockData';
import { generateLocalRecommendation, DecisionPriority } from '../utils/recommendationEngine';
import { fetchNearbySupermarkets, reverseGeocode } from '../services/mapsService';
import { calculatePlannedDeparture, adjustTrafficForTime, adjustCrowdForTime } from '../utils/dateIntelligence';
import confetti from 'canvas-confetti';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
}

interface AppContextType {
  userProfile: UserProfile;
  stores: Store[];
  activeLocation: ActiveLocation;
  searchRadiusKm: number;
  isLoadingStores: boolean;
  snapshots: Record<string, ConditionSnapshot>;
  recommendation: Recommendation | null;
  isEvaluating: boolean;
  isRefreshing: boolean;
  savedTrips: SavedTrip[];
  alerts: Alert[];
  selectedCompareIds: string[];
  activeTab: NavigationTab;
  activeStoreId: string | null;
  searchQuery: string;
  selectedCategory: StoreCategory | 'All';
  selectedSort: 'score' | 'distance' | 'parking' | 'price';
  toasts: Toast[];
  navigationHistory: NavigationTab[];
  hourlyForecasts: HourlyForecast[];
  communityReports: CommunityReport[];
  shoppingLists: ShoppingList[];
  shoppingListItems: ShoppingListItem[];
  savedLocations: SavedLocation[];
  currentLocation: { lat: number, lng: number, address: string } | null;
  locationPermissionGranted: boolean;
  plannedDeparture: PlannedDeparture;
  decisionPriority: DecisionPriority;
  setDecisionPriority: (priority: DecisionPriority) => void;

  // Setters & Actions
  setActiveTab: (tab: NavigationTab) => void;
  goBack: () => void;
  setActiveLocation: (loc: ActiveLocation) => void;
  setSearchRadiusKm: (radius: number) => void;
  setPlannedDeparturePreset: (preset: DeparturePreset, customDate?: Date) => void;
  setActiveStoreId: (id: string | null) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (cat: StoreCategory | 'All') => void;
  setSelectedSort: (sort: 'score' | 'distance' | 'parking' | 'price') => void;
  
  createShoppingList: (name: string) => void;
  deleteShoppingList: (id: string) => void;
  addShoppingListItem: (listId: string, item: Omit<ShoppingListItem, 'id' | 'list_id'>) => void;
  toggleShoppingListItem: (id: string) => void;
  removeShoppingListItem: (id: string) => void;
  
  addSavedLocation: (location: Omit<SavedLocation, 'id'>) => void;
  removeSavedLocation: (id: string) => void;
  setCurrentLocation: (location: { lat: number, lng: number, address: string } | null) => void;
  requestLocationPermission: () => void;
  
  evaluateBestStore: () => Promise<void>;
  refreshConditions: () => Promise<void>;
  toggleCompareStore: (storeId: string) => void;
  clearCompare: () => void;
  createSavedTrip: (storeId: string, plannedTime: string, notes?: string, isMultiStop?: boolean, storeIds?: string[]) => void;
  updateTripStatus: (tripId: string, status: 'Planned' | 'Completed' | 'Cancelled') => void;
  rescheduleTrip: (tripId: string, newTime: string) => void;
  toggleStoreAlert: (storeId: string) => void;
  markAlertRead: (alertId: string) => void;
  markAllAlertsRead: () => void;
  updateUserProfile: (updated: UserProfile) => void;
  navigateToStoreDetails: (storeId: string) => void;
  addToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
  removeToast: (id: string) => void;
  toggleFavoriteStore: (storeId: string) => void;
  addCommunityReport: (report: Omit<CommunityReport, 'id' | 'created_at' | 'upvotes'>) => void;
  upvoteCommunityReport: (reportId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load state from localStorage if available
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('shopwise_user');
    if (!saved) return INITIAL_USER_PROFILE;
    try {
      const parsed = JSON.parse(saved);
      return {
        ...INITIAL_USER_PROFILE,
        ...parsed,
        favorite_stores: Array.isArray(parsed?.favorite_stores)
          ? parsed.favorite_stores
          : INITIAL_USER_PROFILE.favorite_stores || [],
        preferred_categories: Array.isArray(parsed?.preferred_categories)
          ? parsed.preferred_categories
          : INITIAL_USER_PROFILE.preferred_categories || [],
        preferred_store_ids: Array.isArray(parsed?.preferred_store_ids)
          ? parsed.preferred_store_ids
          : INITIAL_USER_PROFILE.preferred_store_ids || [],
      };
    } catch {
      return INITIAL_USER_PROFILE;
    }
  });

  const [activeLocation, setActiveLocationState] = useState<ActiveLocation>(() => {
    const saved = localStorage.getItem('shopwise_active_location');
    return saved ? JSON.parse(saved) : {
      placeId: 'kl_center',
      displayName: 'Bukit Jalil',
      formattedAddress: 'Bukit Jalil, Kuala Lumpur, Malaysia',
      city: 'Kuala Lumpur',
      country: 'Malaysia',
      latitude: 3.0569,
      longitude: 101.6934
    };
  });

  const [searchRadiusKm, setSearchRadiusKmState] = useState<number>(5);
  const [stores, setStores] = useState<Store[]>(INITIAL_STORES);
  const [isLoadingStores, setIsLoadingStores] = useState<boolean>(false);

  const [snapshots, setSnapshots] = useState<Record<string, ConditionSnapshot>>(() => {
    const saved = localStorage.getItem('shopwise_snapshots');
    return saved ? JSON.parse(saved) : INITIAL_CONDITION_SNAPSHOTS;
  });

  const [savedTrips, setSavedTrips] = useState<SavedTrip[]>(() => {
    const saved = localStorage.getItem('shopwise_trips');
    return saved ? JSON.parse(saved) : INITIAL_SAVED_TRIPS;
  });

  const [alerts, setAlerts] = useState<Alert[]>(() => {
    const saved = localStorage.getItem('shopwise_alerts');
    return saved ? JSON.parse(saved) : INITIAL_ALERTS;
  });

  const [recommendation, setRecommendation] = useState<Recommendation | null>(() => {
    // Generate initial recommendation on first load
    return generateLocalRecommendation(INITIAL_STORES, INITIAL_CONDITION_SNAPSHOTS, INITIAL_USER_PROFILE);
  });

  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [selectedCompareIds, setSelectedCompareIds] = useState<string[]>([]);
  const [activeTab, setActiveTabState] = useState<NavigationTab>('home');
  const [navigationHistory, setNavigationHistory] = useState<NavigationTab[]>([]);
  const [activeStoreId, setActiveStoreId] = useState<string | null>('store_apex_hyper');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<StoreCategory | 'All'>('All');
  const [selectedSort, setSelectedSort] = useState<'score' | 'distance' | 'parking' | 'price'>('score');
  const [toasts, setToasts] = useState<Toast[]>([]);
  
  const [communityReports, setCommunityReports] = useState<CommunityReport[]>([]);
  const [shoppingLists, setShoppingLists] = useState<ShoppingList[]>([]);
  const [shoppingListItems, setShoppingListItems] = useState<ShoppingListItem[]>([]);
  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>([]);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number, lng: number, address: string } | null>(null);
  const [locationPermissionGranted, setLocationPermissionGranted] = useState(false);
  const [plannedDeparture, setPlannedDeparture] = useState<PlannedDeparture>(() => calculatePlannedDeparture('now'));
  const [decisionPriority, setDecisionPriorityState] = useState<DecisionPriority>('balanced');

  const setDecisionPriority = (priority: DecisionPriority) => {
    setDecisionPriorityState(priority);
    setRecommendation(generateLocalRecommendation(stores, snapshots, userProfile, priority));
    const labelMap: Record<DecisionPriority, string> = {
      balanced: 'Balanced Conditions',
      fastest: 'Fastest Route & Travel',
      cheapest: 'Best Prices & Deals',
      crowd: 'Lowest Crowd Density',
      risk: 'Lowest Environmental Risk',
      one_stop: 'One-stop Destination',
    };
    addToast(`Decision priority: ${labelMap[priority]}`, 'info');
  };

  const setPlannedDeparturePreset = (preset: DeparturePreset, customDate?: Date) => {
    const updatedDeparture = calculatePlannedDeparture(preset, customDate);
    setPlannedDeparture(updatedDeparture);

    setSnapshots((prev) => {
      const updated: Record<string, ConditionSnapshot> = {};
      Object.keys(prev).forEach((id) => {
        const snap = prev[id];
        updated[id] = {
          ...snap,
          traffic_level: adjustTrafficForTime(snap.traffic_level, updatedDeparture.trafficMultiplier),
          crowd_density: adjustCrowdForTime(snap.crowd_density, updatedDeparture.crowdMultiplier),
        };
      });
      return updated;
    });

    // Re-evaluate local recommendation with adjusted snapshots
    setTimeout(() => {
      setRecommendation(generateLocalRecommendation(stores, snapshots, userProfile, decisionPriority));
    }, 100);

    addToast(`Departure set: ${updatedDeparture.formattedFull}`, 'info');
  };
  
  // Generating a mocked 12-hour forecast based on INITIAL_STORES
  const [hourlyForecasts] = useState<HourlyForecast[]>(() => {
    const forecasts: HourlyForecast[] = [];
    INITIAL_STORES.forEach(store => {
      const currentHour = new Date().getHours();
      for (let i = 0; i < 12; i++) {
        const hour = (currentHour + i) % 24;
        forecasts.push({
          store_id: store.id,
          hour_of_day: hour,
          predicted_crowd_density: Math.random() > 0.7 ? 'High' : (Math.random() > 0.4 ? 'Medium' : 'Low'),
          predicted_traffic_level: Math.random() > 0.8 ? 'Heavy' : (Math.random() > 0.3 ? 'Moderate' : 'Light'),
          predicted_flood_risk: Math.random() > 0.9 ? 'High' : 'Low',
          predicted_safety_score: Math.floor(Math.random() * 40) + 60,
        });
      }
    });
    return forecasts;
  });

  const loadStoresForLocation = async (loc: ActiveLocation, radius: number) => {
    setIsLoadingStores(true);
    setStores([]); // Immediately clear previous location stores
    try {
      const fetchedStores = await fetchNearbySupermarkets(loc, radius);
      if (fetchedStores && fetchedStores.length > 0) {
        setStores(fetchedStores);
        if (fetchedStores[0]) {
          setActiveStoreId(fetchedStores[0].id);
        }

        // Generate condition snapshots for new stores
        setSnapshots((prev) => {
          const updated = { ...prev };
          fetchedStores.forEach((s) => {
            if (!updated[s.id]) {
              updated[s.id] = {
                store_id: s.id,
                weather_status: 'Clear',
                flood_risk: 'Low',
                traffic_level: 'Light',
                crowd_density: 'Medium',
                air_quality_index: 42,
                parking_availability_percent: 75,
                active_promotions: ['10% Cashback with ShopWise'],
                last_updated: new Date().toISOString()
              };
            }
          });
          return updated;
        });

        setRecommendation(generateLocalRecommendation(fetchedStores, snapshots, userProfile));
      } else {
        setStores([]);
      }
    } catch (err) {
      console.warn("Failed to load stores for location:", err);
      setStores([]);
    } finally {
      setIsLoadingStores(false);
    }
  };

  const setActiveLocation = (loc: ActiveLocation) => {
    setActiveLocationState(loc);
    localStorage.setItem('shopwise_active_location', JSON.stringify(loc));
    loadStoresForLocation(loc, searchRadiusKm);
    addToast(`Active location set to ${loc.displayName}`, 'info');
  };

  const setSearchRadiusKm = (radius: number) => {
    setSearchRadiusKmState(radius);
    loadStoresForLocation(activeLocation, radius);
    addToast(`Search radius set to ${radius} km`, 'info');
  };

  useEffect(() => {
    // Attempt automatic current location detection if user has location service enabled
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            const currentLoc = await reverseGeocode(lat, lng);
            if (currentLoc && currentLoc.latitude && currentLoc.longitude) {
              setActiveLocationState(currentLoc);
              localStorage.setItem('shopwise_active_location', JSON.stringify(currentLoc));
              loadStoresForLocation(currentLoc, searchRadiusKm);
              setLocationPermissionGranted(true);
              setCurrentLocation({ lat, lng, address: currentLoc.formattedAddress });
              return;
            }
          } catch (err) {
            console.warn('Automatic location detection error:', err);
          }
          loadStoresForLocation(activeLocation, searchRadiusKm);
        },
        (err) => {
          console.log('Location service disabled or permission denied:', err.message);
          setLocationPermissionGranted(false);
          loadStoresForLocation(activeLocation, searchRadiusKm);
        },
        { timeout: 8000, enableHighAccuracy: false }
      );
    } else {
      loadStoresForLocation(activeLocation, searchRadiusKm);
    }
  }, []);

  const setActiveTab = (tab: NavigationTab) => {
    setNavigationHistory(prev => [...prev, activeTab]);
    setActiveTabState(tab);
  };

  const goBack = () => {
    setNavigationHistory(prev => {
      const history = [...prev];
      const previousTab = history.pop() || 'dashboard';
      setActiveTabState(previousTab);
      return history;
    });
  };

  // Persist local state
  useEffect(() => {
    localStorage.setItem('shopwise_user', JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('shopwise_snapshots', JSON.stringify(snapshots));
  }, [snapshots]);

  useEffect(() => {
    localStorage.setItem('shopwise_trips', JSON.stringify(savedTrips));
  }, [savedTrips]);

  useEffect(() => {
    localStorage.setItem('shopwise_alerts', JSON.stringify(alerts));
  }, [alerts]);

  const addToast = (message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const id = 'toast_' + Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const evaluateBestStore = async () => {
    setIsEvaluating(true);
    try {
      // Call backend AI route
      const response = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stores, snapshots, userProfile }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.data) {
          const aiData = data.data;
          const recStore = stores.find(
            (s) => s.name.toLowerCase() === (aiData.recommended_store_name || '').toLowerCase()
          ) || stores[0];

          const altStore = stores.find(
            (s) => s.name.toLowerCase() === (aiData.alternative_store_name || '').toLowerCase()
          ) || stores[1] || stores[0];

          if (recStore) {
            setRecommendation({
              user_id: userProfile.id,
              recommended_store_id: recStore.id,
              alternative_store_id: altStore ? altStore.id : '',
              reason_summary: aiData.reason_summary,
              safety_score: aiData.safety_score || 95,
              advantages: aiData.advantages || [],
              warnings: aiData.warnings || [],
              tradeoff_analysis: aiData.tradeoff_analysis || '',
              generated_at: new Date().toISOString(),
              is_ai_generated: true,
            });
          }

          addToast('AI recalculated live store recommendation!', 'success');
          setIsEvaluating(false);
          return;
        }
      }
    } catch (err) {
      console.warn('Backend AI unavailable, using local recommendation algorithm', err);
    }

    // Fallback to local engine
    setTimeout(() => {
      const localRec = generateLocalRecommendation(stores, snapshots, userProfile);
      setRecommendation(localRec);
      addToast('Evaluated live conditions across all nearby stores', 'success');
      setIsEvaluating(false);
    }, 600);
  };

  const refreshConditions = async () => {
    setIsRefreshing(true);
    try {
      const response = await fetch('/api/refresh-conditions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentSnapshots: snapshots }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.snapshots) {
          setSnapshots(data.snapshots);
          // Re-evaluate local recommendation with fresh snapshots
          setRecommendation(generateLocalRecommendation(stores, data.snapshots, userProfile));
          addToast('Live condition snapshots updated across all stores!', 'success');
          setIsRefreshing(false);
          return;
        }
      }
    } catch (err) {
      console.warn('Backend refresh endpoint error, using local simulation', err);
    }

    // Local simulation fallback
    setTimeout(() => {
      const weatherOptions = ['Clear', 'Clear', 'Clear', 'Rain', 'Storm'] as const;
      const updated: Record<string, ConditionSnapshot> = {};

      Object.keys(snapshots).forEach((id) => {
        const prev = snapshots[id];
        const newParking = Math.min(100, Math.max(10, prev.parking_availability_percent + Math.floor(Math.random() * 21) - 10));
        updated[id] = {
          ...prev,
          parking_availability_percent: newParking,
          weather_status: Math.random() < 0.2 ? weatherOptions[Math.floor(Math.random() * weatherOptions.length)] : prev.weather_status,
          last_updated: new Date().toISOString(),
        };
      });

      setSnapshots(updated);
      setRecommendation(generateLocalRecommendation(stores, updated, userProfile));
      addToast('Refreshed live condition snapshots!', 'success');
      setIsRefreshing(false);
    }, 500);
  };

  const toggleCompareStore = (storeId: string) => {
    if (selectedCompareIds.includes(storeId)) {
      setSelectedCompareIds((prev) => prev.filter((id) => id !== storeId));
      addToast('Removed store from comparison list', 'info');
    } else {
      if (selectedCompareIds.length >= 3) {
        addToast('You can compare a maximum of 3 stores side-by-side.', 'warning');
        return;
      }
      setSelectedCompareIds((prev) => [...prev, storeId]);
      addToast('Added store to comparison list!', 'info');
    }
  };

  const clearCompare = () => {
    setSelectedCompareIds([]);
  };

  const createSavedTrip = (storeId: string, plannedTime: string, notes: string = '', isMultiStop: boolean = false, storeIds: string[] = []) => {
    const store = stores.find((s) => s.id === storeId);
    const snap = snapshots[storeId];

    const newTrip: SavedTrip = {
      id: 'trip_' + Date.now(),
      user_id: userProfile.id,
      store_id: storeId,
      store_ids: storeIds,
      is_multi_stop: isMultiStop,
      planned_time: plannedTime,
      notes,
      status: 'Planned',
      created_at: new Date().toISOString(),
      snapshot_at_planning: snap ? {
        weather: snap.weather_status,
        traffic: snap.traffic_level,
        crowd: snap.crowd_density,
        flood: snap.flood_risk,
      } : undefined,
    };

    setSavedTrips((prev) => [newTrip, ...prev]);

    // Celebrate with confetti
    confetti({
      particleCount: 60,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#0284c7', '#0d9488', '#10b981', '#3b82f6'],
    });

    if (isMultiStop) {
        addToast(`Multi-stop trip planned (${plannedTime})!`, 'success');
    } else {
        addToast(`Trip planned to ${store ? store.name : 'store'} (${plannedTime})!`, 'success');
    }
  };

  const toggleFavoriteStore = (storeId: string) => {
    setUserProfile((prev) => {
      const favs = prev?.favorite_stores || [];
      const isFav = favs.includes(storeId);
      const newFavs = isFav
        ? favs.filter((id) => id !== storeId)
        : [...favs, storeId];
      return { ...prev, favorite_stores: newFavs };
    });
    addToast('Favorites updated', 'info');
  };

  const addCommunityReport = (report: Omit<CommunityReport, 'id' | 'created_at' | 'upvotes'>) => {
    const newReport: CommunityReport = {
      ...report,
      id: 'rep_' + Date.now(),
      created_at: new Date().toISOString(),
      upvotes: 0,
    };
    setCommunityReports((prev) => [newReport, ...prev]);
    addToast('Report submitted! Thanks for helping the community.', 'success');
  };

  const upvoteCommunityReport = (reportId: string) => {
    setCommunityReports((prev) =>
      prev.map((r) => (r.id === reportId ? { ...r, upvotes: r.upvotes + 1 } : r))
    );
  };

  const updateTripStatus = (tripId: string, status: 'Planned' | 'Completed' | 'Cancelled') => {
    setSavedTrips((prev) =>
      prev.map((t) => (t.id === tripId ? { ...t, status } : t))
    );
    const statusLabels = {
      Completed: 'marked as completed 🎉',
      Cancelled: 'cancelled',
      Planned: 'moved back to planned',
    };
    addToast(`Trip ${statusLabels[status]}.`, 'info');
  };

  const rescheduleTrip = (tripId: string, newTime: string) => {
    setSavedTrips((prev) =>
      prev.map((t) => (t.id === tripId ? { ...t, planned_time: newTime } : t))
    );
    addToast(`Trip rescheduled for ${newTime}!`, 'success');
  };

  const toggleStoreAlert = (storeId: string) => {
    const store = stores.find((s) => s.id === storeId);
    const existingAlertIndex = alerts.findIndex((a) => a.store_id === storeId && a.condition_type === 'flood');

    if (existingAlertIndex >= 0) {
      setAlerts((prev) => prev.filter((a, idx) => idx !== existingAlertIndex));
      addToast(`Alert monitoring turned off for ${store?.name || 'store'}.`, 'info');
    } else {
      const newAlert: Alert = {
        id: 'alert_' + Date.now(),
        user_id: userProfile.id,
        store_id: storeId,
        condition_type: 'flood',
        message: `Alert set for ${store?.name || 'store'}: You will be notified immediately if flood risk, traffic, or crowds reach High levels.`,
        is_read: false,
        severity: 'medium',
        created_at: new Date().toISOString(),
      };
      setAlerts((prev) => [newAlert, ...prev]);
      addToast(`Alert monitoring activated for ${store?.name || 'store'}!`, 'success');
    }
  };

  const markAlertRead = (alertId: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, is_read: true } : a))
    );
  };

  const markAllAlertsRead = () => {
    setAlerts((prev) => prev.map((a) => ({ ...a, is_read: true })));
    addToast('All alerts marked as read.', 'info');
  };

  const updateUserProfile = (updated: UserProfile) => {
    setUserProfile(updated);
    addToast('Profile and preferences updated successfully!', 'success');
  };

  const navigateToStoreDetails = (storeId: string) => {
    setActiveStoreId(storeId);
    setActiveTab('store_details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const createShoppingList = (name: string) => {
    const newList: ShoppingList = {
      id: 'list_' + Date.now(),
      user_id: userProfile.id,
      name,
      created_at: new Date().toISOString(),
    };
    setShoppingLists(prev => [newList, ...prev]);
    addToast(`Created list: ${name}`, 'success');
  };

  const deleteShoppingList = (id: string) => {
    setShoppingLists(prev => prev.filter(l => l.id !== id));
    setShoppingListItems(prev => prev.filter(i => i.list_id !== id));
    addToast('Shopping list deleted', 'info');
  };

  const addShoppingListItem = (listId: string, item: Omit<ShoppingListItem, 'id' | 'list_id'>) => {
    const newItem: ShoppingListItem = {
      ...item,
      id: 'item_' + Date.now(),
      list_id: listId,
    };
    setShoppingListItems(prev => [...prev, newItem]);
  };

  const toggleShoppingListItem = (id: string) => {
    setShoppingListItems(prev => prev.map(item => 
      item.id === id ? { ...item, is_checked: !item.is_checked } : item
    ));
  };

  const removeShoppingListItem = (id: string) => {
    setShoppingListItems(prev => prev.filter(item => item.id !== id));
  };

  const addSavedLocation = (location: Omit<SavedLocation, 'id'>) => {
    const newLoc: SavedLocation = {
      ...location,
      id: 'loc_' + Date.now()
    };
    setSavedLocations(prev => [...prev, newLoc]);
    addToast(`Location ${location.label} saved`, 'success');
  };

  const removeSavedLocation = (id: string) => {
    setSavedLocations(prev => prev.filter(loc => loc.id !== id));
    addToast('Location removed', 'info');
  };

  const requestLocationPermission = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            address: 'Current Location'
          });
          setLocationPermissionGranted(true);
          addToast('Location updated', 'success');
        },
        () => {
          addToast('Location access denied. Please set manually.', 'warning');
        }
      );
    }
  };

  return (
    <AppContext.Provider
      value={{
        userProfile,
        stores,
        activeLocation,
        searchRadiusKm,
        isLoadingStores,
        snapshots,
        recommendation,
        isEvaluating,
        isRefreshing,
        savedTrips,
        alerts,
        selectedCompareIds,
        activeTab,
        activeStoreId,
        searchQuery,
        selectedCategory,
        selectedSort,
        toasts,
        navigationHistory,
        hourlyForecasts,
        communityReports,
        shoppingLists,
        shoppingListItems,
        savedLocations,
        currentLocation,
        locationPermissionGranted,
        plannedDeparture,
        decisionPriority,
        setDecisionPriority,

        setActiveTab,
        goBack,
        setActiveLocation,
        setSearchRadiusKm,
        setPlannedDeparturePreset,
        setActiveStoreId,
        setSearchQuery,
        setSelectedCategory,
        setSelectedSort,
        evaluateBestStore,
        refreshConditions,
        toggleCompareStore,
        clearCompare,
        createSavedTrip,
        updateTripStatus,
        rescheduleTrip,
        toggleStoreAlert,
        markAlertRead,
        markAllAlertsRead,
        updateUserProfile,
        navigateToStoreDetails,
        addToast,
        removeToast,
        toggleFavoriteStore,
        addCommunityReport,
        upvoteCommunityReport,
        createShoppingList,
        deleteShoppingList,
        addShoppingListItem,
        toggleShoppingListItem,
        removeShoppingListItem,
        addSavedLocation,
        removeSavedLocation,
        setCurrentLocation,
        requestLocationPermission,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
