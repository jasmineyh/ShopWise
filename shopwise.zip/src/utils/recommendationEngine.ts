import { Store, ConditionSnapshot, Recommendation, UserProfile } from '../types';

export type DecisionPriority = 'balanced' | 'fastest' | 'cheapest' | 'crowd' | 'risk' | 'one_stop';

export interface EvaluatedStore {
  store: Store;
  snapshot: ConditionSnapshot;
  score: number;
  scoreCategory: string;
  advantages: string[];
  warnings: string[];
}

export function getScoreCategory(score: number): { label: string; colorClass: string; bgClass: string } {
  if (score >= 90) return { label: 'Excellent', colorClass: 'text-emerald-700 dark:text-emerald-300', bgClass: 'bg-emerald-100 dark:bg-emerald-950/80 border-emerald-300 dark:border-emerald-800' };
  if (score >= 80) return { label: 'Very Good', colorClass: 'text-teal-700 dark:text-teal-300', bgClass: 'bg-teal-100 dark:bg-teal-950/80 border-teal-300 dark:border-teal-800' };
  if (score >= 70) return { label: 'Good', colorClass: 'text-sky-700 dark:text-sky-300', bgClass: 'bg-sky-100 dark:bg-sky-950/80 border-sky-300 dark:border-sky-800' };
  if (score >= 60) return { label: 'Fair', colorClass: 'text-amber-700 dark:text-amber-300', bgClass: 'bg-amber-100 dark:bg-amber-950/80 border-amber-300 dark:border-amber-800' };
  return { label: 'Poor Choice', colorClass: 'text-rose-700 dark:text-rose-300', bgClass: 'bg-rose-100 dark:bg-rose-950/80 border-rose-300 dark:border-rose-800' };
}

export function calculateSafetyScore(
  store: Store,
  snapshot: ConditionSnapshot,
  priority: DecisionPriority = 'balanced'
): {
  score: number;
  advantages: string[];
  warnings: string[];
} {
  let score = 50; // base score
  const advantages: string[] = [];
  const warnings: string[] = [];

  // 1. Flood Risk
  if (snapshot.flood_risk === 'Low') {
    score += priority === 'risk' ? 30 : 24;
    advantages.push('Zero flood risk detected');
  } else if (snapshot.flood_risk === 'Medium') {
    score += 5;
    warnings.push('Moderate flood risk / water pooling on access roads');
  } else if (snapshot.flood_risk === 'High') {
    score -= priority === 'risk' ? 45 : 32;
    warnings.push('HIGH flash flood risk on surrounding roads');
  }

  // 2. Traffic Level & Distance
  if (priority === 'fastest') {
    if (snapshot.traffic_level === 'Light') {
      score += 28;
      advantages.push('Light traffic & fast route');
    } else if (snapshot.traffic_level === 'Moderate') {
      score += 5;
    } else if (snapshot.traffic_level === 'Heavy') {
      score -= 28;
      warnings.push('Heavy traffic delay (+20 min)');
    }
    const distPenalty = Math.min(store.distance_km * 2.5, 20);
    score -= distPenalty;
  } else {
    if (snapshot.traffic_level === 'Light') {
      score += 18;
      advantages.push('Light traffic & smooth road access');
    } else if (snapshot.traffic_level === 'Moderate') {
      score += 8;
    } else if (snapshot.traffic_level === 'Heavy') {
      score -= 18;
      warnings.push('Heavy traffic congestion (+20 min driving delay)');
    }
    const distancePenalty = Math.min(store.distance_km * 1.2, 8);
    score -= distancePenalty;
  }

  // 3. Crowd Density
  if (priority === 'crowd') {
    if (snapshot.crowd_density === 'Low') {
      score += 25;
      advantages.push('Extremely low crowd & zero wait at checkout');
    } else if (snapshot.crowd_density === 'Medium') {
      score += 5;
    } else if (snapshot.crowd_density === 'High') {
      score -= 22;
      warnings.push('High crowd density (long checkout queues)');
    }
  } else {
    if (snapshot.crowd_density === 'Low') {
      score += 12;
      advantages.push('Low crowd density for fast checkout');
    } else if (snapshot.crowd_density === 'Medium') {
      score += 5;
    } else if (snapshot.crowd_density === 'High') {
      score -= 10;
      warnings.push('High crowd density (long checkout queues)');
    }
  }

  // 4. Price & Promotions (Cheapest Focus)
  if (priority === 'one_stop') {
    if (store.category === 'Hypermarket' || store.parking_capacity > 500) {
      score += 25;
      advantages.push('One-stop destination (Wide inventory selection & hypermarket capacity)');
    } else {
      score += 5;
    }
  } else if (priority === 'cheapest') {
    const priceBonus = (5 - store.average_price_index) * 7;
    score += priceBonus;
    if (store.average_price_index <= 2) {
      advantages.push('Budget-friendly prices (Low price index)');
    } else if (store.average_price_index >= 4) {
      warnings.push('Premium price tier');
    }

    if (snapshot.active_promotions.length > 0) {
      const promoBonus = Math.min(snapshot.active_promotions.length * 5, 18);
      score += promoBonus;
      advantages.push(`${snapshot.active_promotions.length} active promotion deals`);
    }
  } else {
    if (snapshot.active_promotions.length > 0) {
      const promoBonus = Math.min(snapshot.active_promotions.length * 2, 6);
      score += promoBonus;
      advantages.push(`${snapshot.active_promotions.length} active promotion deals`);
    }
  }

  // 5. Weather
  if (snapshot.weather_status === 'Clear') {
    score += 8;
    advantages.push('Clear weather conditions');
  } else if (snapshot.weather_status === 'Rain') {
    score += 2;
  } else if (snapshot.weather_status === 'Storm') {
    score -= priority === 'risk' ? 22 : 12;
    warnings.push('Stormy weather & poor visibility');
  }

  // 6. Parking Availability (0-100%)
  const parkingBonus = Math.round((snapshot.parking_availability_percent / 100) * 10);
  score += parkingBonus;
  if (snapshot.parking_availability_percent >= 75) {
    advantages.push(`Ample parking (${snapshot.parking_availability_percent}% bays free)`);
  } else if (snapshot.parking_availability_percent <= 20) {
    warnings.push(`Critically low parking (${snapshot.parking_availability_percent}% free)`);
  }

  // 7. Air Quality Index
  if (snapshot.air_quality_index <= 50) {
    score += 4;
    advantages.push(`Good Air Quality (AQI ${snapshot.air_quality_index})`);
  } else if (snapshot.air_quality_index > 100) {
    score -= 5;
    warnings.push(`Unhealthy Air Quality (AQI ${snapshot.air_quality_index})`);
  }

  // Clamp to 10 - 99
  const finalScore = Math.max(10, Math.min(99, Math.round(score)));

  return {
    score: finalScore,
    advantages,
    warnings,
  };
}

export function generateLocalRecommendation(
  stores: Store[],
  snapshots: Record<string, ConditionSnapshot>,
  user: UserProfile,
  priority: DecisionPriority = 'balanced'
): Recommendation {
  if (!stores || stores.length === 0) {
    return {
      user_id: user.id,
      recommended_store_id: '',
      alternative_store_id: '',
      safety_score: 0,
      reason_summary: 'No stores available nearby.',
      tradeoff_analysis: 'Select a location to discover nearby stores.',
      advantages: [],
      warnings: [],
      generated_at: new Date().toISOString(),
      is_ai_generated: false,
    };
  }

  const evaluated: EvaluatedStore[] = stores.map((s) => {
    const snap = snapshots[s.id] || {
      store_id: s.id,
      weather_status: 'Clear',
      flood_risk: 'Low',
      traffic_level: 'Light',
      crowd_density: 'Low',
      air_quality_index: 40,
      parking_availability_percent: 70,
      active_promotions: [],
      last_updated: new Date().toISOString(),
    };
    const { score, advantages, warnings } = calculateSafetyScore(s, snap, priority);
    const scoreCategory = getScoreCategory(score).label;
    return {
      store: s,
      snapshot: snap,
      score,
      scoreCategory,
      advantages,
      warnings,
    };
  });

  // Sort descending by score
  evaluated.sort((a, b) => b.score - a.score);

  const topStore = evaluated[0];
  
  // Find a usual/preferred store or a store with high risk to compare against
  let usualStore = evaluated.find((e) => (user?.preferred_store_ids || []).includes(e.store.id) && e.store.id !== topStore.store.id);
  if (!usualStore) {
    usualStore = evaluated.find((e) => e.snapshot.flood_risk === 'High' || e.snapshot.traffic_level === 'Heavy') || evaluated[evaluated.length - 1];
  }

  const topStoreName = topStore.store.name;
  const usualStoreName = usualStore ? usualStore.store.name : 'other area malls';

  // Build 1-line reason summary
  let reasonSummary = '';
  if (usualStore && (usualStore.snapshot.flood_risk === 'High' || usualStore.snapshot.traffic_level === 'Heavy' || usualStore.score < 60)) {
    const topReason1 = usualStore.warnings[0] || 'heavy traffic';
    const advantage1 = topStore.advantages[0] || 'clear driving conditions';
    const advantage2 = topStore.advantages[1] || `${topStore.snapshot.parking_availability_percent}% parking availability`;

    reasonSummary = `Avoid ${usualStoreName} today — ${topReason1.toLowerCase()}. ${topStoreName} is ${topStore.store.distance_km} km away with ${advantage1.toLowerCase()} and ${advantage2.toLowerCase()}.`;
  } else {
    reasonSummary = `${topStoreName} is your smartest trip right now with a safety/convenience score of ${topStore.score}/100. Smooth traffic, low flood risk, and ${topStore.snapshot.parking_availability_percent}% free parking!`;
  }

  let tradeoffAnalysis = '';
  if (usualStore && usualStore.store.id !== topStore.store.id) {
    tradeoffAnalysis = `${usualStore.store.name} scores ${usualStore.score}/100 due to ${usualStore.warnings.join(', ') || 'higher crowd density'}. Switching to ${topStore.store.name} saves you an estimated 25 minutes in traffic and parking delays while ensuring 100% dry travel roads.`;
  } else {
    tradeoffAnalysis = `All factors point to ${topStore.store.name} as the top choice. Weather is clear, driving routes are open, and parking is easily accessible.`;
  }

  return {
    user_id: user.id,
    recommended_store_id: topStore.store.id,
    alternative_store_id: usualStore ? usualStore.store.id : topStore.store.id,
    reason_summary: reasonSummary,
    safety_score: topStore.score,
    advantages: topStore.advantages,
    warnings: topStore.warnings,
    tradeoff_analysis: tradeoffAnalysis,
    generated_at: new Date().toISOString(),
    is_ai_generated: false,
  };
}
