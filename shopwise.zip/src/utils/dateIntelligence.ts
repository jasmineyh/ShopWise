import { TrafficLevel, CrowdDensity } from '../types';

export type DeparturePreset =
  | 'now'
  | 'in_30m'
  | 'in_1h'
  | 'this_afternoon'
  | 'this_evening'
  | 'tomorrow_morning'
  | 'tomorrow_afternoon'
  | 'custom';

export interface PlannedDeparture {
  preset: DeparturePreset;
  targetDate: Date;
  dateLabel: string;
  timeLabel: string;
  formattedFull: string;
  isWeekend: boolean;
  isPublicHoliday: boolean;
  holidayName?: string;
  dayType: 'weekday' | 'weekend' | 'holiday';
  confidence: 'High confidence' | 'Moderate confidence' | 'Trend estimate';
  trafficMultiplier: number;
  crowdMultiplier: number;
  intelligenceNote: string;
}

// Major Malaysian / Regional holidays list for calendar intelligence
const KNOWN_HOLIDAYS: Record<string, string> = {
  '01-01': 'New Year\'s Day',
  '02-01': 'Federal Territory Day / Thaipusam',
  '05-01': 'Labour Day',
  '08-31': 'Merdeka National Day',
  '09-16': 'Malaysia Day',
  '12-25': 'Christmas Day',
  '12-31': 'New Year\'s Eve',
};

export function calculatePlannedDeparture(
  preset: DeparturePreset,
  customDate?: Date
): PlannedDeparture {
  const now = new Date();
  let target = new Date();

  switch (preset) {
    case 'now':
      target = new Date(now);
      break;
    case 'in_30m':
      target = new Date(now.getTime() + 30 * 60 * 1000);
      break;
    case 'in_1h':
      target = new Date(now.getTime() + 60 * 60 * 1000);
      break;
    case 'this_afternoon':
      target = new Date(now);
      target.setHours(15, 0, 0, 0);
      if (now.getHours() >= 15) {
        target.setDate(target.getDate() + 1);
      }
      break;
    case 'this_evening':
      target = new Date(now);
      target.setHours(18, 30, 0, 0);
      if (now.getHours() >= 19) {
        target.setDate(target.getDate() + 1);
      }
      break;
    case 'tomorrow_morning':
      target = new Date(now);
      target.setDate(target.getDate() + 1);
      target.setHours(10, 0, 0, 0);
      break;
    case 'tomorrow_afternoon':
      target = new Date(now);
      target.setDate(target.getDate() + 1);
      target.setHours(15, 0, 0, 0);
      break;
    case 'custom':
      target = customDate || new Date(now.getTime() + 2 * 60 * 60 * 1000);
      break;
  }

  const hoursDiff = (target.getTime() - now.getTime()) / (1000 * 60 * 60);

  // Day type analysis
  const dayOfWeek = target.getDay(); // 0 = Sun, 6 = Sat
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

  const monthStr = String(target.getMonth() + 1).padStart(2, '0');
  const dayStr = String(target.getDate()).padStart(2, '0');
  const monthDayKey = `${monthStr}-${dayStr}`;
  const holidayName = KNOWN_HOLIDAYS[monthDayKey];
  const isPublicHoliday = Boolean(holidayName);

  let dayType: 'weekday' | 'weekend' | 'holiday' = 'weekday';
  if (isPublicHoliday) dayType = 'holiday';
  else if (isWeekend) dayType = 'weekend';

  // Confidence calculation based on time horizon
  let confidence: 'High confidence' | 'Moderate confidence' | 'Trend estimate' = 'High confidence';
  if (hoursDiff > 24) {
    confidence = 'Trend estimate';
  } else if (hoursDiff > 2) {
    confidence = 'Moderate confidence';
  } else {
    confidence = 'High confidence';
  }

  // Formatting strings
  const isToday = target.toDateString() === now.toDateString();
  const isTomorrow =
    new Date(now.getTime() + 24 * 60 * 60 * 1000).toDateString() === target.toDateString();

  const daysOfWeekNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayName = daysOfWeekNames[dayOfWeek];

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthName = monthNames[target.getMonth()];

  let dateLabel = isToday ? 'Today' : isTomorrow ? 'Tomorrow' : `${dayName}, ${target.getDate()} ${monthName}`;
  const timeLabel = target.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const formattedFull = `${dateLabel} · ${timeLabel}`;

  // Traffic & Crowd Multiplier
  const hour = target.getHours();
  let trafficMultiplier = 1.0;
  let crowdMultiplier = 1.0;

  if (isPublicHoliday) {
    trafficMultiplier = 1.35;
    crowdMultiplier = 1.45;
  } else if (isWeekend) {
    if (hour >= 12 && hour <= 18) {
      trafficMultiplier = 1.3;
      crowdMultiplier = 1.4;
    } else if (hour >= 18 && hour <= 21) {
      trafficMultiplier = 1.25;
      crowdMultiplier = 1.3;
    }
  } else {
    // Weekday peak hours (7:30-9:30 AM, 5:30-8:00 PM)
    if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
      trafficMultiplier = 1.4;
      crowdMultiplier = 1.2;
    } else if (hour >= 12 && hour <= 14) {
      trafficMultiplier = 1.15;
      crowdMultiplier = 1.25;
    } else if (hour >= 20 || hour < 7) {
      trafficMultiplier = 0.75;
      crowdMultiplier = 0.65;
    }
  }

  // Contextual Note
  let intelligenceNote = '';
  if (isPublicHoliday) {
    intelligenceNote = `Public Holiday (${holidayName}) — Expect heavy mall crowds and busy parking throughout the day.`;
  } else if (isWeekend) {
    if (hour >= 13 && hour <= 17) {
      intelligenceNote = 'Peak Saturday/Sunday afternoon shopping hours — crowds and traffic are highest between 1 PM and 5 PM.';
    } else {
      intelligenceNote = 'Weekend trip — early morning or late evening trips offer significantly quieter shopping.';
    }
  } else {
    if (hour >= 17 && hour <= 19) {
      intelligenceNote = 'Weekday evening rush hour — major access roads will experience heavier traffic.';
    } else if (hour >= 20) {
      intelligenceNote = 'Late evening trip — traffic is light and parking availability is excellent.';
    } else {
      intelligenceNote = 'Standard weekday conditions — smooth travel with moderate store traffic.';
    }
  }

  return {
    preset,
    targetDate: target,
    dateLabel,
    timeLabel,
    formattedFull,
    isWeekend,
    isPublicHoliday,
    holidayName,
    dayType,
    confidence,
    trafficMultiplier,
    crowdMultiplier,
    intelligenceNote,
  };
}

export function adjustTrafficForTime(
  baseTraffic: TrafficLevel,
  multiplier: number
): TrafficLevel {
  if (multiplier >= 1.3) return 'Heavy';
  if (multiplier >= 1.1) return baseTraffic === 'Light' ? 'Moderate' : 'Heavy';
  if (multiplier <= 0.8) return baseTraffic === 'Heavy' ? 'Moderate' : 'Light';
  return baseTraffic;
}

export function adjustCrowdForTime(
  baseCrowd: CrowdDensity,
  multiplier: number
): CrowdDensity {
  if (multiplier >= 1.35) return 'High';
  if (multiplier >= 1.1) return baseCrowd === 'Low' ? 'Medium' : 'High';
  if (multiplier <= 0.8) return baseCrowd === 'High' ? 'Medium' : 'Low';
  return baseCrowd;
}
