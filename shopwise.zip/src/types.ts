export type DeparturePreset =
  | 'now'
  | 'in_30m'
  | 'in_1h'
  | 'this_afternoon'
  | 'this_evening'
  | 'tomorrow_morning'
  | 'tomorrow_afternoon'
  | 'custom';

export interface PlannedDeparture {
  preset: DeparturePreset;
  targetDate: Date;
  dateLabel: string;
  timeLabel: string;
  formattedFull: string;
  isWeekend: boolean;
  isPublicHoliday: boolean;
  holidayName?: string;
  dayType: 'weekday' | 'weekend' | 'holiday';
  confidence: 'High confidence' | 'Moderate confidence' | 'Trend estimate';
  trafficMultiplier: number;
  crowdMultiplier: number;
  intelligenceNote: string;
}

export type StoreCategory = 
  | 'Mall' 
  | 'Supermarket' 
  | 'Hypermarket' 
  | 'Pharmacy' 
  | 'Department Store' 
  | 'Electronics';

export type WeatherStatus = 'Clear' | 'Rain' | 'Storm';
export type FloodRisk = 'Low' | 'Medium' | 'High';
export type TrafficLevel = 'Light' | 'Moderate' | 'Heavy';
export type CrowdDensity = 'Low' | 'Medium' | 'High';
export type ParkingType = 'Covered' | 'Open' | 'Multi-level Covered';

export interface ActiveLocation {
  placeId?: string;
  displayName: string;
  formattedAddress: string;
  city?: string;
  region?: string;
  country?: string;
  countryCode?: string;
  latitude: number;
  longitude: number;
}

export interface Store {
  id: string;
  placeId?: string;
  name: string;
  category: StoreCategory;
  address: string;
  latitude: number;
  longitude: number;
  distance_km: number;
  travel_time_minutes?: number;
  image: string;
  average_price_index: number; // 1 to 5
  operating_hours: string;
  openNow?: boolean;
  parking_capacity: number;
  parking_type: ParkingType;
  rating: number;
  userRatingCount?: number;
  phone?: string;
  description?: string;
  googleMapsUri?: string;
  websiteUri?: string;
  photos?: string[];
}

export interface IoTSensorData {
  sensor_status: 'Active Streaming' | 'Calibrated' | 'Connected';
  live_occupancy_count: number;
  max_capacity: number;
  occupancy_percent: number;
  checkout_wait_minutes: number;
  camera_cv_density: 'Sparse' | 'Moderate' | 'Dense' | 'Overcrowded';
  road_sensor_speed_kmh: number;
  traffic_flow_rate_cars_per_min: number;
  parking_sensor_free_bays: number;
  last_sensor_ping_sec: number;
}

export interface ConditionSnapshot {
  store_id: string;
  weather_status: WeatherStatus;
  flood_risk: FloodRisk;
  traffic_level: TrafficLevel;
  crowd_density: CrowdDensity;
  air_quality_index: number; // 0–300
  parking_availability_percent: number; // 0–100
  active_promotions: string[];
  last_updated: string; // ISO string
  iot_sensors?: IoTSensorData;
}

export type StockStatus = 'High Stock' | 'In Stock' | 'Low Stock' | 'Out of Stock';

export interface StoreProduct {
  id: string;
  store_id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  stock_quantity: number;
  stock_status: StockStatus;
  aisle: string;
  last_updated_secs_ago: number;
  verified_by_erp: boolean;
}

export interface Recommendation {
  user_id: string;
  recommended_store_id: string;
  alternative_store_id: string;
  reason_summary: string;
  safety_score: number; // 0–100
  advantages: string[];
  warnings: string[];
  tradeoff_analysis?: string;
  generated_at: string;
  is_ai_generated?: boolean;
}

export interface HourlyForecast {
  store_id: string;
  hour_of_day: number; // 0-23
  predicted_crowd_density: CrowdDensity;
  predicted_traffic_level: TrafficLevel;
  predicted_safety_score: number;
  predicted_flood_risk: FloodRisk;
}

export interface CommunityReport {
  id: string;
  user_id: string;
  store_id: string;
  report_type: 'Flooding' | 'Heavy Crowd' | 'Traffic Jam' | 'Parking Full' | 'All Clear';
  note?: string;
  upvotes: number;
  created_at: string;
}

export interface UserPoints {
  total_points: number;
  current_streak: number;
  estimated_time_saved_minutes: number;
  estimated_trips_optimized: number;
}

export type TripStatus = 'Planned' | 'Completed' | 'Cancelled';

export interface SavedTrip {
  id: string;
  user_id: string;
  store_id: string; // Keep for backward compatibility or single trips
  store_ids?: string[]; // For multi-stop trips
  planned_time: string; // e.g. "Now", "In 1 hour", "Later today", "Tomorrow at 4:00 PM"
  notes: string;
  status: TripStatus;
  created_at: string;
  is_multi_stop?: boolean;
  snapshot_at_planning?: {
    weather: WeatherStatus;
    traffic: TrafficLevel;
    crowd: CrowdDensity;
    flood: FloodRisk;
  };
}

export interface Alert {
  id: string;
  user_id: string;
  store_id: string;
  condition_type: 'flood' | 'traffic' | 'crowd' | 'weather';
  message: string;
  is_read: boolean;
  created_at: string;
  severity: 'low' | 'medium' | 'high';
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  home_address: string;
  latitude: number;
  longitude: number;
  preferred_categories: StoreCategory[];
  preferred_store_ids: string[];
  favorite_stores: string[]; // NEW for Prompt 2
  points: UserPoints; // NEW for Prompt 2
  has_completed_onboarding?: boolean;
  preferences: { // NEW for Prompt 2
    language: 'English' | 'Bahasa Malaysia' | '中文';
    theme: 'light' | 'dark' | 'system';
  };
  notification_preferences: {
    flood_alerts: boolean;
    traffic_alerts: boolean;
    crowd_alerts: boolean;
    promotion_alerts: boolean;
    notify_for_favorites: boolean; // NEW for Prompt 2
  };
}

export type NavigationTab =
  | 'home'
  | 'explore'
  | 'plan'
  | 'profile'
  | 'store_details'
  | 'assistant'
  | 'insights';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export interface ItemMapping {
  item: string;
  recommended_store: string;
  estimated_price_range: string;
  reason: string;
}

export interface OptimizedListResult {
  recommendation_type: 'single_store' | 'multi_store';
  primary_store_name: string;
  secondary_store_name: string | null;
  item_mappings: ItemMapping[];
  total_distance_km: number;
  estimated_time_minutes: number;
  route_safety_score: number;
  route_summary: string;
  safety_warnings: string[];
}

export interface ShoppingList {
  id: string;
  user_id: string;
  name: string;
  created_at: string;
}

export interface ShoppingListItem {
  id: string;
  list_id: string;
  item_name: string;
  quantity: number;
  category: string;
  estimated_price: number;
  is_checked: boolean;
}

export interface SavedLocation {
  id: string;
  user_id: string;
  label: string;
  address: string;
  latitude: number;
  longitude: number;
}

