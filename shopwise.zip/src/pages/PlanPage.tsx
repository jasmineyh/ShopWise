import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CheckSquare, Columns3, Route, CalendarCheck2, Plus, Trash2 } from 'lucide-react';
import { ComparePage } from './ComparePage';
import { ListOptimizerPage } from './ListOptimizerPage';
import { TripsPage } from './TripsPage';

export const PlanPage: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'list' | 'compare' | 'route' | 'saved'>('list');

  useEffect(() => {
    const savedSubtab = sessionStorage.getItem('shopwise_plan_subtab') as 'list' | 'compare' | 'route' | 'saved' | null;
    if (savedSubtab) {
      setActiveSubTab(savedSubtab);
      sessionStorage.removeItem('shopwise_plan_subtab');
    }

    const handleNavigate = (e: any) => {
      if (e.detail) setActiveSubTab(e.detail);
    };

    window.addEventListener('shopwise_navigate_plan_subtab', handleNavigate);
    return () => window.removeEventListener('shopwise_navigate_plan_subtab', handleNavigate);
  }, []);
  const { shoppingLists, shoppingListItems, createShoppingList, deleteShoppingList, addShoppingListItem, toggleShoppingListItem, removeShoppingListItem } = useApp();
  const [newListName, setNewListName] = useState('');
  const [newItemName, setNewItemName] = useState('');
  const [selectedListId, setSelectedListId] = useState<string | null>(null);

  const handleCreateList = (e: React.FormEvent) => {
    e.preventDefault();
    if (newListName.trim()) {
      createShoppingList(newListName.trim());
      setNewListName('');
    }
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (newItemName.trim() && selectedListId) {
      addShoppingListItem(selectedListId, {
        item_name: newItemName.trim(),
        quantity: 1,
        category: 'Groceries',
        estimated_price: 0,
        is_checked: false
      });
      setNewItemName('');
    }
  };

  const tabs = [
    { id: 'list', label: 'Shopping List', icon: <CheckSquare size={16} /> },
    { id: 'compare', label: 'Compare', icon: <Columns3 size={16} /> },
    { id: 'route', label: 'Route', icon: <Route size={16} /> },
    { id: 'saved', label: 'Saved Trips', icon: <CalendarCheck2 size={16} /> },
  ] as const;

  return (
    <div className="space-y-6 pb-20">
      {/* Sub-tabs / Segmented Control */}
      <div className="bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-1 overflow-x-auto scrollbar-hide shadow-xs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeSubTab === tab.id
                ? 'bg-sky-50 dark:bg-sky-900/30 text-sky-700 dark:text-sky-300 shadow-sm border border-sky-100 dark:border-sky-800'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="mt-4">
        {activeSubTab === 'list' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-4">Your Shopping Lists</h2>
              
              {/* Create new list */}
              <form onSubmit={handleCreateList} className="flex items-center gap-2 mb-6">
                <input
                  type="text"
                  placeholder="New list name (e.g., Weekly Groceries)"
                  value={newListName}
                  onChange={(e) => setNewListName(e.target.value)}
                  className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
                <button 
                  type="submit"
                  disabled={!newListName.trim()}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-sm font-bold transition-colors disabled:opacity-50"
                >
                  <Plus size={18} />
                </button>
              </form>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Lists sidebar */}
                <div className="space-y-2">
                  {shoppingLists.length === 0 ? (
                    <p className="text-sm text-slate-500 italic">No lists yet. Create one above.</p>
                  ) : (
                    shoppingLists.map(list => (
                      <div 
                        key={list.id} 
                        onClick={() => setSelectedListId(list.id)}
                        className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${selectedListId === list.id ? 'bg-sky-50 dark:bg-sky-900/20 border-sky-200 dark:border-sky-800' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-sky-300'}`}
                      >
                        <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{list.name}</span>
                        <button 
                          onClick={(e) => { e.stopPropagation(); deleteShoppingList(list.id); if(selectedListId===list.id) setSelectedListId(null); }}
                          className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {/* List items */}
                <div className="md:col-span-2 bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 min-h-[300px]">
                  {selectedListId ? (
                    <>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-bold text-slate-900 dark:text-slate-100">{shoppingLists.find(l => l.id === selectedListId)?.name}</h3>
                      </div>
                      
                      <form onSubmit={handleAddItem} className="flex items-center gap-2 mb-4">
                        <input
                          type="text"
                          placeholder="Add item..."
                          value={newItemName}
                          onChange={(e) => setNewItemName(e.target.value)}
                          className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                        />
                        <button type="submit" disabled={!newItemName.trim()} className="px-3 py-1.5 bg-slate-900 dark:bg-slate-700 text-white rounded-lg text-xs font-bold disabled:opacity-50">
                          Add
                        </button>
                      </form>

                      <div className="space-y-4">
                        {shoppingListItems.filter(i => i.list_id === selectedListId).length === 0 ? (
                          <p className="text-xs text-slate-500 text-center py-6">List is empty. Add items above.</p>
                        ) : (
                          (() => {
                            const listItems = shoppingListItems.filter(i => i.list_id === selectedListId);
                            const unchecked = listItems.filter(i => !i.is_checked);
                            const checked = listItems.filter(i => i.is_checked);

                            return (
                              <div className="space-y-4">
                                {/* Unchecked items */}
                                <div className="space-y-2">
                                  {unchecked.map(item => (
                                    <div key={item.id} className="flex items-center justify-between bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-2xs">
                                      <div className="flex items-center gap-3">
                                        <input
                                          type="checkbox"
                                          checked={item.is_checked}
                                          onChange={() => toggleShoppingListItem(item.id)}
                                          className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500 border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900"
                                        />
                                        <span className="text-sm font-medium text-slate-800 dark:text-slate-100">
                                          {item.item_name}
                                        </span>
                                      </div>
                                      <button onClick={() => removeShoppingListItem(item.id)} className="text-slate-400 hover:text-rose-500 p-1">
                                        <Trash2 size={14} />
                                      </button>
                                    </div>
                                  ))}
                                </div>

                                {/* Send List to Optimizer Action Button */}
                                {unchecked.length > 0 && (
                                  <div className="pt-2">
                                    <button
                                      onClick={() => setActiveSubTab('route')}
                                      className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
                                    >
                                      <span>Send {unchecked.length} Items to Route Optimizer &rarr;</span>
                                    </button>
                                  </div>
                                )}

                                {/* Checked / Purchased items */}
                                {checked.length > 0 && (
                                  <div className="pt-3 border-t border-slate-200 dark:border-slate-700/60 space-y-2">
                                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                                      Purchased / Checked ({checked.length})
                                    </span>
                                    {checked.map(item => (
                                      <div key={item.id} className="flex items-center justify-between bg-slate-100/60 dark:bg-slate-800/40 p-2.5 rounded-xl border border-slate-200/50 dark:border-slate-700/40 opacity-75">
                                        <div className="flex items-center gap-3">
                                          <input
                                            type="checkbox"
                                            checked={item.is_checked}
                                            onChange={() => toggleShoppingListItem(item.id)}
                                            className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500 border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900"
                                          />
                                          <span className="text-sm font-medium line-through text-slate-400">
                                            {item.item_name}
                                          </span>
                                        </div>
                                        <button onClick={() => removeShoppingListItem(item.id)} className="text-slate-400 hover:text-rose-500 p-1">
                                          <Trash2 size={14} />
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })()
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full text-slate-500 text-sm">
                      Select or create a list to view items.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeSubTab === 'compare' && (
          <div className="-mt-6">
            <ComparePage />
          </div>
        )}
        
        {activeSubTab === 'route' && (
          <div className="-mt-6">
            <ListOptimizerPage />
          </div>
        )}
        
        {activeSubTab === 'saved' && (
          <div className="-mt-6">
            <TripsPage />
          </div>
        )}
      </div>
    </div>
  );
};
