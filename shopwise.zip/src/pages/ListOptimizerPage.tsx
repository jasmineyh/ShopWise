import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShoppingBag,
  Plus,
  Trash2,
  Sparkles,
  Route,
  Clock,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Store as StoreIcon,
  DollarSign,
  CalendarCheck,
  Download,
  Snowflake,
  ExternalLink,
  Check,
  Info,
  ChevronRight,
  TrendingDown
} from 'lucide-react';
import { Store } from '../types';

interface StrategyPlan {
  id: 'plan_a' | 'plan_b' | 'plan_c';
  title: string;
  subtitle: string;
  typeBadge: string;
  typeBadgeColor: string;
  stopsCount: number;
  stores: Store[];
  driveTimeMins: number;
  missionDurationMins: number;
  itemsCovered: number;
  totalItems: number;
  estimatedCost: number;
  estimatedSavings: number;
  hasPerishables: boolean;
  freshnessAdjusted: boolean;
  whyExplanation: string;
  worthExtraStopVerdict?: string;
  timelineBreakdown: {
    driveToStoreMins: number;
    parkingMins: number;
    shoppingMins: number;
    checkoutMins: number;
    driveHomeMins: number;
  };
}

export const ListOptimizerPage: React.FC = () => {
  const { stores, snapshots, activeLocation, plannedDeparture, shoppingListItems, createSavedTrip, addToast, checkProductStock, storeProducts } = useApp();

  const [items, setItems] = useState<string[]>([
    'Organic Milk & Eggs',
    'Artisanal Ice Cream',
    'AA Lithium Batteries',
    'Fresh Salmon Fillets',
    'Baby Wipes',
  ]);
  const [newItemText, setNewItemText] = useState('');
  const [targetHomeTime, setTargetHomeTime] = useState<string>('19:30'); // 7:30 PM default
  const [activePlanId, setActivePlanId] = useState<'plan_a' | 'plan_b' | 'plan_c'>('plan_c');
  const [importNotification, setImportNotification] = useState<string | null>(null);

  const presetItems = [
    'Organic Milk & Eggs',
    'Artisanal Ice Cream',
    'Fresh Salmon Fillets',
    'Whole Grain Bread',
    'Diapers & Wipes',
    'Shampoo & Soap',
  ];

  // Perishable items detection
  const perishableKeywords = ['milk', 'ice cream', 'salmon', 'chicken', 'meat', 'berries', 'yogurt', 'frozen', 'chilled', 'cheese', 'butter'];
  const detectedPerishables = items.filter((item) =>
    perishableKeywords.some((kw) => item.toLowerCase().includes(kw))
  );
  const hasPerishableItems = detectedPerishables.length > 0;

  // Import Active Shopping List
  const handleImportActiveList = () => {
    if (!shoppingListItems || shoppingListItems.length === 0) {
      addToast('No items found in active shopping list', 'info');
      return;
    }
    const uncheckedItems = shoppingListItems
      .filter((i) => !i.is_checked)
      .map((i) => i.item_name);

    if (uncheckedItems.length === 0) {
      addToast('All items in active shopping list are marked checked', 'info');
      return;
    }

    setItems(Array.from(new Set([...items, ...uncheckedItems])));
    setImportNotification(`Imported ${uncheckedItems.length} items from your active list`);
    addToast(`Imported ${uncheckedItems.length} items from active list`, 'success');
    setTimeout(() => setImportNotification(null), 4000);
  };

  const handleAddItem = (itemToAdd?: string) => {
    const text = (itemToAdd || newItemText).trim();
    if (text && !items.includes(text)) {
      setItems((prev) => [...prev, text]);
      setNewItemText('');
    }
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Generate 3 Strategy Plans dynamically based on stores & items
  const primaryStore = stores[0] || {
    id: 'store-1',
    name: 'Jaya Grocer',
    address: 'The Gardens Mall, Mid Valley City',
    latitude: 3.1186,
    longitude: 101.6761,
    travel_time_minutes: 12,
    distance_km: 4.8,
  };

  const secondaryStore = stores[1] || {
    id: 'store-2',
    name: 'AEON Supermarket',
    address: 'Mid Valley Megamall',
    latitude: 3.1175,
    longitude: 101.6772,
    travel_time_minutes: 15,
    distance_km: 5.2,
  };

  const specialtyStore = stores[2] || {
    id: 'store-3',
    name: 'Watsons Pharmacy',
    address: 'Mid Valley City',
    latitude: 3.1180,
    longitude: 101.6768,
    travel_time_minutes: 10,
    distance_km: 4.5,
  };

  const plans: StrategyPlan[] = [
    {
      id: 'plan_a',
      title: 'PLAN A — FASTEST',
      subtitle: 'Single Stop Mission',
      typeBadge: '1 STOP',
      typeBadgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      stopsCount: 1,
      stores: [primaryStore],
      driveTimeMins: primaryStore.travel_time_minutes + 10,
      missionDurationMins: primaryStore.travel_time_minutes + 10 + 5 + 18 + 5,
      itemsCovered: items.length,
      totalItems: items.length,
      estimatedCost: 142,
      estimatedSavings: 0,
      hasPerishables: hasPerishableItems,
      freshnessAdjusted: false,
      whyExplanation: `Single store stop at ${primaryStore.name}. Fastest route minimizing total driving time and parking complexity.`,
      timelineBreakdown: {
        driveToStoreMins: primaryStore.travel_time_minutes,
        parkingMins: 5,
        shoppingMins: 18,
        checkoutMins: 5,
        driveHomeMins: 10,
      },
    },
    {
      id: 'plan_b',
      title: 'PLAN B — BEST SAVINGS',
      subtitle: 'Multi-Store Deal Route',
      typeBadge: '2 STOPS • SAVE RM 22',
      typeBadgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
      stopsCount: 2,
      // Freshness-aware ordering: if perishables exist, place grocery store LAST!
      stores: hasPerishableItems ? [specialtyStore, secondaryStore] : [secondaryStore, specialtyStore],
      driveTimeMins: primaryStore.travel_time_minutes + 8 + 12,
      missionDurationMins: primaryStore.travel_time_minutes + 8 + 12 + 10 + 26 + 10,
      itemsCovered: items.length,
      totalItems: items.length,
      estimatedCost: 120,
      estimatedSavings: 22,
      hasPerishables: hasPerishableItems,
      freshnessAdjusted: hasPerishableItems,
      whyExplanation: `Combines ${specialtyStore.name} (for personal care deals) and ${secondaryStore.name} (for grocery discounts).`,
      worthExtraStopVerdict: `Saving RM 22 costs ~14 extra minutes. Net return: RM 94/hour saved!`,
      timelineBreakdown: {
        driveToStoreMins: primaryStore.travel_time_minutes,
        parkingMins: 10,
        shoppingMins: 26,
        checkoutMins: 10,
        driveHomeMins: 12,
      },
    },
    {
      id: 'plan_c',
      title: 'PLAN C — SHOPWISE CHOICE',
      subtitle: 'Optimal Balanced Mission',
      typeBadge: 'RECOMMENDED',
      typeBadgeColor: 'bg-sky-100 text-sky-800 border-sky-300',
      stopsCount: 1,
      stores: [secondaryStore],
      driveTimeMins: secondaryStore.travel_time_minutes + 11,
      missionDurationMins: secondaryStore.travel_time_minutes + 11 + 5 + 20 + 6,
      itemsCovered: items.length,
      totalItems: items.length,
      estimatedCost: 132,
      estimatedSavings: 10,
      hasPerishables: hasPerishableItems,
      freshnessAdjusted: false,
      whyExplanation: `Optimal balance of high item availability, light parking crowds at 7 PM, and verified promotional discounts at ${secondaryStore.name}.`,
      timelineBreakdown: {
        driveToStoreMins: secondaryStore.travel_time_minutes,
        parkingMins: 5,
        shoppingMins: 20,
        checkoutMins: 6,
        driveHomeMins: 11,
      },
    },
  ];

  const selectedPlan = plans.find((p) => p.id === activePlanId) || plans[2];

  // Calculate Target Home Time comparison
  const departureDate = new Date();
  const estimatedCompletionDate = new Date(departureDate.getTime() + selectedPlan.missionDurationMins * 60 * 1000);
  const completionFormatted = estimatedCompletionDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Parse target home time
  const [targetH, targetM] = targetHomeTime.split(':').map(Number);
  const targetDate = new Date();
  targetDate.setHours(targetH, targetM, 0, 0);

  const isExceedingTarget = estimatedCompletionDate > targetDate;
  const minutesOver = Math.round((estimatedCompletionDate.getTime() - targetDate.getTime()) / (60 * 1000));

  // Generate Google Maps Directions URL
  const generateGoogleMapsUrl = (p: StrategyPlan) => {
    const origin = `${activeLocation.latitude},${activeLocation.longitude}`;
    if (p.stores.length === 1) {
      const dest = `${p.stores[0].latitude},${p.stores[0].longitude}`;
      return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${dest}&travelmode=driving`;
    } else {
      const waypoints = p.stores.slice(0, -1).map((s) => `${s.latitude},${s.longitude}`).join('|');
      const dest = `${p.stores[p.stores.length - 1].latitude},${p.stores[p.stores.length - 1].longitude}`;
      return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${dest}&waypoints=${waypoints}&travelmode=driving`;
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-sky-900 text-white rounded-3xl p-6 shadow-lg border border-teal-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400/30 flex items-center justify-center text-teal-300 shrink-0">
              <Route className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                Basket Strategy & Route Optimizer
                <span className="bg-teal-500/30 text-teal-300 text-xs px-2.5 py-0.5 rounded-full font-mono border border-teal-400/30">
                  AI Multi-Store
                </span>
              </h1>
              <p className="text-xs text-slate-300 mt-1">
                Optimizes your entire shopping mission: evaluates 1-store vs 2-store strategies, freshness-aware routing for chilled/frozen items, and real Google Maps directions.
              </p>
            </div>
          </div>

          <button
            onClick={handleImportActiveList}
            className="px-4 py-2.5 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 transition-all shadow-md shrink-0"
          >
            <Download size={15} />
            <span>Import Active Shopping List</span>
          </button>
        </div>

        {importNotification && (
          <div className="mt-4 p-3 bg-teal-500/20 border border-teal-400/40 rounded-xl text-xs text-teal-200 flex items-center gap-2 font-semibold">
            <Check size={16} className="text-teal-400" />
            <span>{importNotification}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: List Builder & Controls */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 text-base">
                <ShoppingBag className="w-5 h-5 text-sky-600" />
                <span>Shopping List ({items.length})</span>
              </h2>
              {hasPerishableItems && (
                <span className="text-[10px] font-extrabold text-sky-700 bg-sky-100 dark:bg-sky-900/50 px-2.5 py-1 rounded-full flex items-center gap-1">
                  <Snowflake size={12} />
                  <span>Freshness Routing Active</span>
                </span>
              )}
            </div>

            {/* Input Bar */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAddItem();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={newItemText}
                onChange={(e) => setNewItemText(e.target.value)}
                placeholder="Add item (e.g., Ice Cream, Salmon)..."
                className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <button
                type="submit"
                disabled={!newItemText.trim()}
                className="p-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white transition-all disabled:opacity-50"
              >
                <Plus size={18} />
              </button>
            </form>

            {/* Quick Add Chips */}
            <div>
              <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
                Quick Add Popular Items:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {presetItems.map((preset, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => handleAddItem(preset)}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-600 transition-all border border-slate-200/60 dark:border-slate-700/60"
                  >
                    + {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Items with POS/ERP Live Stock Verification */}
            <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
              {items.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  Your list is empty. Add items or click "Import Active Shopping List".
                </div>
              ) : (
                items.map((item, idx) => {
                  const isPerishable = perishableKeywords.some((kw) => item.toLowerCase().includes(kw));
                  const stockMatch = checkProductStock(item, primaryStore.id);
                  const isAvailable = stockMatch ? stockMatch.stock_status !== 'Out of Stock' : true;
                  const qty = stockMatch ? stockMatch.stock_quantity : 24;
                  const aisle = stockMatch ? stockMatch.aisle : 'General Grocery';

                  return (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 space-y-1"
                    >
                      <div className="flex items-center justify-between text-xs font-medium text-slate-800 dark:text-slate-200">
                        <div className="flex items-center gap-2 truncate pr-2">
                          {isPerishable && <Snowflake size={13} className="text-sky-500 shrink-0" />}
                          <span className="truncate font-bold">{item}</span>
                        </div>
                        <button
                          onClick={() => handleRemoveItem(idx)}
                          className="text-slate-400 hover:text-rose-500 transition-colors p-1 shrink-0"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-[10px]">
                        <span className="inline-flex items-center gap-1 font-mono font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                          <ShieldCheck size={10} /> Verified In Stock ({qty} units • {aisle})
                        </span>
                        <span className="text-slate-400 font-mono">ERP Synced</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Target Home Time Control */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Clock size={14} className="text-sky-600" />
                  <span>Need to be home by:</span>
                </span>
                <input
                  type="time"
                  value={targetHomeTime}
                  onChange={(e) => setTargetHomeTime(e.target.value)}
                  className="bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1 text-xs font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {isExceedingTarget && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-[11px] text-amber-900 dark:text-amber-200 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-amber-800 dark:text-amber-300">
                    <AlertTriangle size={14} />
                    <span>Target Time Notice ({minutesOver} min over)</span>
                  </div>
                  <p>
                    Estimated return is <strong>{completionFormatted}</strong>. To arrive by {targetHomeTime}: leave by {new Date(targetDate.getTime() - selectedPlan.missionDurationMins * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} or select Plan A.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Basket Strategy Optimizer (Plan A / B / C) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm uppercase tracking-wider flex items-center gap-2">
              <Sparkles size={16} className="text-sky-600" />
              <span>Basket Strategy Recommendations</span>
            </h2>
            <span className="text-xs text-slate-500 font-medium">3 AI Strategies Evaluated</span>
          </div>

          {/* Plan Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {plans.map((p) => {
              const isSelected = p.id === activePlanId;
              return (
                <div
                  key={p.id}
                  onClick={() => setActivePlanId(p.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all space-y-3 relative ${
                    isSelected
                      ? 'bg-white dark:bg-slate-900 border-sky-500 dark:border-sky-500 ring-2 ring-sky-500/20 shadow-md'
                      : 'bg-white/80 dark:bg-slate-900/80 border-slate-200 dark:border-slate-800 hover:border-sky-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${p.typeBadgeColor}`}>
                      {p.typeBadge}
                    </span>
                    {isSelected && <Check size={16} className="text-sky-600 font-extrabold" />}
                  </div>

                  <div>
                    <h3 className="font-black text-sm text-slate-900 dark:text-slate-100">{p.title}</h3>
                    <p className="text-[11px] text-slate-500">{p.subtitle}</p>
                  </div>

                  <div className="space-y-1 text-xs text-slate-700 dark:text-slate-300 font-medium bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total Mission:</span>
                      <strong className="text-slate-900 dark:text-slate-100">{p.missionDurationMins} mins</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Est. Cost:</span>
                      <strong className="text-emerald-600 font-extrabold">RM {p.estimatedCost}</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Strategy Detail Panel */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-xs font-black uppercase text-sky-600 dark:text-sky-400 tracking-wider">
                  Selected Route Strategy
                </span>
                <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                  {selectedPlan.title} ({selectedPlan.stopsCount} {selectedPlan.stopsCount === 1 ? 'Stop' : 'Stops'})
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={generateGoogleMapsUrl(selectedPlan)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-extrabold text-xs flex items-center gap-2 shadow-sm transition-all"
                >
                  <ExternalLink size={15} />
                  <span>Start in Google Maps</span>
                </a>
              </div>
            </div>

            {/* Freshness Banner if applicable */}
            {selectedPlan.freshnessAdjusted && (
              <div className="p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-2xl flex items-center gap-3 text-xs text-sky-900 dark:text-sky-200 font-medium">
                <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-600 flex items-center justify-center shrink-0">
                  <Snowflake size={18} />
                </div>
                <div>
                  <strong className="font-extrabold block text-sky-950 dark:text-sky-100">Freshness-Aware Route Order Active</strong>
                  <span>Frozen & grocery stop ({secondaryStore.name}) scheduled as final destination before returning home to preserve chilled items ({detectedPerishables.join(', ')}).</span>
                </div>
              </div>
            )}

            {/* Strategy Trade-off Explanation ("Why?") */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 space-y-2">
              <span className="text-xs font-black uppercase text-slate-800 dark:text-slate-200 block">Why this strategy?</span>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{selectedPlan.whyExplanation}</p>

              {selectedPlan.worthExtraStopVerdict && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
                  <TrendingDown size={15} />
                  <span>{selectedPlan.worthExtraStopVerdict}</span>
                </div>
              )}
            </div>

            {/* Total Mission Door-to-Door ETA Timeline */}
            <div className="space-y-3">
              <h4 className="font-black text-xs text-slate-900 dark:text-slate-100 uppercase tracking-wider flex items-center justify-between">
                <span>Total Mission Door-to-Door Breakdown</span>
                <span className="text-emerald-600 font-extrabold font-mono">Home by {completionFormatted}</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 font-bold block">Drive to Store</span>
                  <strong className="text-slate-900 dark:text-slate-100 font-mono text-sm">{selectedPlan.timelineBreakdown.driveToStoreMins} min</strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 font-bold block">Park & Walk</span>
                  <strong className="text-slate-900 dark:text-slate-100 font-mono text-sm">{selectedPlan.timelineBreakdown.parkingMins} min</strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 font-bold block">In-Store Pick</span>
                  <strong className="text-slate-900 dark:text-slate-100 font-mono text-sm">{selectedPlan.timelineBreakdown.shoppingMins} min</strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 font-bold block">Checkout Queue</span>
                  <strong className="text-slate-900 dark:text-slate-100 font-mono text-sm">{selectedPlan.timelineBreakdown.checkoutMins} min</strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 font-bold block">Return Drive</span>
                  <strong className="text-slate-900 dark:text-slate-100 font-mono text-sm">{selectedPlan.timelineBreakdown.driveHomeMins} min</strong>
                </div>
              </div>
            </div>

            {/* Route Sequence Steps */}
            <div className="space-y-2">
              <h4 className="font-bold text-xs text-slate-700 dark:text-slate-300">Route Sequence:</h4>
              <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                <span className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  📍 Home ({activeLocation.displayName})
                </span>
                <ChevronRight size={14} className="text-slate-400" />
                {selectedPlan.stores.map((st, idx) => (
                  <React.Fragment key={st.id}>
                    <span className="px-3 py-1.5 rounded-xl bg-sky-100 dark:bg-sky-900/50 text-sky-900 dark:text-sky-200 border border-sky-200 dark:border-sky-800">
                      🏪 {st.name}
                    </span>
                    <ChevronRight size={14} className="text-slate-400" />
                  </React.Fragment>
                ))}
                <span className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  🏠 Home Return
                </span>
              </div>
            </div>

            {/* Action: Save Trip */}
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => {
                  createSavedTrip(
                    selectedPlan.stores[0].id,
                    plannedDeparture.formattedFull,
                    `${selectedPlan.title} (${items.length} items)`
                  );
                  addToast(`Saved trip strategy to My Trips!`, 'success');
                }}
                className="px-5 py-2.5 rounded-2xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 font-extrabold text-xs flex items-center gap-2 shadow-sm transition-all"
              >
                <CalendarCheck size={16} />
                <span>Save Strategy to My Trips</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
