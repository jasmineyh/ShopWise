import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  CalendarCheck2,
  CheckCircle2,
  XCircle,
  Clock,
  MapPin,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Edit3,
  Trash2,
  Calendar,
} from 'lucide-react';
import { SavedTrip, TripStatus } from '../types';

export const TripsPage: React.FC = () => {
  const {
    savedTrips,
    stores,
    updateTripStatus,
    rescheduleTrip,
    setActiveTab,
    navigateToStoreDetails,
    goBack,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<TripStatus | 'All'>('All');
  const [rescheduleTripId, setRescheduleTripId] = useState<string | null>(null);
  const [newTimeInput, setNewTimeInput] = useState<string>('');

  const filteredTrips = savedTrips.filter((t) =>
    activeFilter === 'All' ? true : t.status === activeFilter
  );

  const plannedCount = savedTrips.filter((t) => t.status === 'Planned').length;
  const completedCount = savedTrips.filter((t) => t.status === 'Completed').length;
  const cancelledCount = savedTrips.filter((t) => t.status === 'Cancelled').length;

  const handleRescheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rescheduleTripId && newTimeInput.trim()) {
      rescheduleTrip(rescheduleTripId, newTimeInput);
      setRescheduleTripId(null);
      setNewTimeInput('');
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <div className="flex items-start gap-4">
          <button
            onClick={goBack}
            className="p-2 mt-1 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shrink-0"
          >
            <ArrowLeft size={20} className="text-slate-600 dark:text-slate-300" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-sky-600 dark:text-sky-400 text-xs font-bold uppercase tracking-wider mb-1">
              <CalendarCheck2 size={16} />
              <span>Trip Itinerary Manager</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-slate-100">My Planned Trips</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Track, complete, or reschedule your scheduled shopping runs.
            </p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(['All', 'Planned', 'Completed', 'Cancelled'] as const).map((st) => {
            const count =
              st === 'All'
                ? savedTrips.length
                : st === 'Planned'
                ? plannedCount
                : st === 'Completed'
                ? completedCount
                : cancelledCount;

            const isSelected = activeFilter === st;

            return (
              <button
                key={st}
                onClick={() => setActiveFilter(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                {st} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Trips List */}
      {filteredTrips.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-10 text-center max-w-md mx-auto shadow-sm space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex items-center justify-center mx-auto">
            <Calendar size={32} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">No Trips Saved Yet</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {activeFilter === 'All'
                ? 'Use "Find My Best Store" on the dashboard to plan your first smart trip!'
                : `No trips currently marked as ${activeFilter}.`}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('dashboard')}
            className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all inline-flex items-center gap-2"
          >
            <Sparkles size={14} />
            <span>Find a Store</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredTrips.map((trip) => {
            const store = stores.find((s) => s.id === trip.store_id);
            const storeName = store ? store.name : 'Saved Location';
            const storeImage = store ? store.image : 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=300&q=80';
            const storeCategory = store ? store.category : 'Supermarket';
            const storeDistance = store ? `${store.distance_km} km away` : '';

            let statusColor = 'bg-sky-100 text-sky-800 border-sky-300 dark:bg-sky-950 dark:text-sky-300';
            if (trip.status === 'Completed') {
              statusColor = 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300';
            } else if (trip.status === 'Cancelled') {
              statusColor = 'bg-slate-100 text-slate-600 border-slate-300 dark:bg-slate-800 dark:text-slate-400';
            }

            return (
              <div
                key={trip.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  {/* Top Store Info Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={storeImage}
                        alt={storeName}
                        className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-slate-200 dark:border-slate-800"
                      />
                      <div>
                        <h4 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm line-clamp-1">
                          {storeName}
                        </h4>
                        <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                          <MapPin size={12} className="text-sky-500 shrink-0" />
                          <span>{storeCategory}{storeDistance ? ` • ${storeDistance}` : ''}</span>
                        </p>
                      </div>
                    </div>

                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-bold border ${statusColor}`}
                    >
                      {trip.status}
                    </span>
                  </div>

                  {/* Planned Time & Notes */}
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-200">
                      <Clock size={14} className="text-sky-600" />
                      <span>Planned Time: {trip.planned_time}</span>
                    </div>
                    {trip.notes && (
                      <p className="text-slate-600 dark:text-slate-400 italic">
                        "{trip.notes}"
                      </p>
                    )}
                  </div>

                  {/* Conditions at Planning */}
                  {trip.snapshot_at_planning && (
                    <div className="flex flex-wrap items-center gap-2 text-[11px] font-medium text-slate-500">
                      <span>Conditions logged:</span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40">
                        Weather: {trip.snapshot_at_planning.weather}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-sky-50 text-sky-700 dark:bg-sky-950/40">
                        Traffic: {trip.snapshot_at_planning.traffic}
                      </span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <button
                    onClick={() => navigateToStoreDetails(store.id)}
                    className="text-xs font-semibold text-sky-600 dark:text-sky-400 hover:underline inline-flex items-center gap-1"
                  >
                    <span>Store Details</span>
                    <ArrowRight size={12} />
                  </button>

                  <div className="flex items-center gap-1.5">
                    {trip.status === 'Planned' && (
                      <>
                        <button
                          onClick={() => updateTripStatus(trip.id, 'Completed')}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center gap-1"
                          title="Mark as Completed"
                        >
                          <CheckCircle2 size={12} />
                          <span>Complete</span>
                        </button>

                        <button
                          onClick={() => setRescheduleTripId(trip.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs transition-colors flex items-center gap-1"
                          title="Reschedule trip"
                        >
                          <Edit3 size={12} />
                          <span>Reschedule</span>
                        </button>

                        <button
                          onClick={() => updateTripStatus(trip.id, 'Cancelled')}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 dark:bg-rose-950/40 text-xs font-bold transition-colors flex items-center gap-1"
                          title="Cancel trip"
                        >
                          <XCircle size={12} />
                          <span>Cancel</span>
                        </button>
                      </>
                    )}

                    {trip.status !== 'Planned' && (
                      <button
                        onClick={() => updateTripStatus(trip.id, 'Planned')}
                        className="px-3 py-1.5 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold text-xs transition-colors"
                      >
                        Re-open Trip
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Reschedule Modal */}
      {rescheduleTripId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">Reschedule Trip</h3>
            <form onSubmit={handleRescheduleSubmit} className="space-y-3">
              <input
                type="text"
                placeholder="e.g. Tomorrow at 3:00 PM"
                value={newTimeInput}
                onChange={(e) => setNewTimeInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                autoFocus
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRescheduleTripId(null)}
                  className="px-3 py-1.5 rounded-lg border text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-sky-600 text-white font-bold text-xs"
                >
                  Save Time
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
