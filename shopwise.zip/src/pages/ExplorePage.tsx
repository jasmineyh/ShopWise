import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Search, Map as MapIcon, List, AlertTriangle, Sparkles, Zap, DollarSign, Users, Building2, Clock, Layers, ChevronUp, ChevronDown } from 'lucide-react';
import { StoreCategory, ConditionSnapshot } from '../types';
import { StoreCard } from '../components/StoreCard';
import { InteractiveMap } from '../components/InteractiveMap';
import { TimeSelectorModal } from '../components/TimeSelectorModal';
import { calculateSafetyScore } from '../utils/recommendationEngine';

export const ExplorePage: React.FC = () => {
  const {
    stores,
    snapshots,
    searchQuery,
    setSearchQuery,
    navigateToStoreDetails,
    selectedCompareIds,
    toggleCompareStore,
    activeLocation,
    plannedDeparture,
    setPlannedDeparturePreset,
    decisionPriority,
    setDecisionPriority,
    recommendation,
    setActiveTab
  } = useApp();

  const [viewMode, setViewMode] = useState<'split' | 'map' | 'list'>('split');
  const [selectedCategory, setSelectedCategory] = useState<StoreCategory | 'All'>('All');
  const [quickFilter, setQuickFilter] = useState<'all' | 'low_traffic' | 'low_crowd' | 'deals' | 'open_now'>('all');
  const [isTimeModalOpen, setIsTimeModalOpen] = useState(false);
  const [mobileSheetState, setMobileSheetState] = useState<'collapsed' | 'half' | 'full'>('half');
  const [selectedZoneStoreIds, setSelectedZoneStoreIds] = useState<string[] | null>(null);

  // Intent Options
  const intentOptions: Array<{ id: typeof decisionPriority; label: string; icon: React.ReactNode }> = [
    { id: 'balanced', label: 'Balanced', icon: <Sparkles size={14} /> },
    { id: 'fastest', label: 'Fastest', icon: <Zap size={14} /> },
    { id: 'cheapest', label: 'Cheapest', icon: <DollarSign size={14} /> },
    { id: 'crowd', label: 'Quietest', icon: <Users size={14} /> },
    { id: 'one_stop', label: 'One-stop', icon: <Building2 size={14} /> },
  ];

  // Smart Shopping Zone Calculation (clusters within 2.5 km of each other)
  const smartZoneStores = stores.slice(0, 3);
  const zoneName = `${stores[0]?.address.split(',')[0] || activeLocation.displayName} Shopping Cluster`;

  // Filter & Rank Stores
  const processedStores = stores
    .filter((s) => {
      const matchesCategory = selectedCategory === 'All' || s.category === selectedCategory;
      const matchesSearch =
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.address.toLowerCase().includes(searchQuery.toLowerCase());

      const snap = snapshots[s.id];
      let matchesFilter = true;
      if (quickFilter === 'low_traffic') matchesFilter = snap?.traffic_level === 'Light';
      else if (quickFilter === 'low_crowd') matchesFilter = snap?.crowd_density === 'Low';
      else if (quickFilter === 'deals') matchesFilter = Boolean(snap?.active_promotions && snap.active_promotions.length > 0);
      else if (quickFilter === 'open_now') matchesFilter = s.openNow !== false;

      if (selectedZoneStoreIds) {
        matchesFilter = matchesFilter && selectedZoneStoreIds.includes(s.id);
      }

      return matchesCategory && matchesSearch && matchesFilter;
    })
    .map((store) => {
      const snap = snapshots[store.id] || {
        store_id: store.id,
        weather_status: 'Clear',
        flood_risk: 'Low',
        traffic_level: 'Light',
        crowd_density: 'Low',
        air_quality_index: 40,
        parking_availability_percent: 70,
        active_promotions: [],
        last_updated: new Date().toISOString(),
      };
      const { score } = calculateSafetyScore(store, snap, decisionPriority);
      return { store, snap, score };
    })
    .sort((a, b) => b.score - a.score);

  const filteredStores = processedStores.map((item) => item.store);

  // Time Presets
  const timePresets = [
    { id: 'now', label: 'NOW' },
    { id: 'in_1_hour', label: '+1 PM / +1h' },
    { id: 'in_2_hours', label: '+2h' },
    { id: 'evening', label: '7 PM' },
    { id: 'night', label: '9 PM' },
  ] as const;

  const totalDeals = (Object.values(snapshots) as ConditionSnapshot[]).reduce(
    (acc, snap) => acc + (snap.active_promotions?.length || 0),
    0
  );
  const strongChoicesCount = processedStores.filter((p) => p.score >= 80).length;

  return (
    <div className="space-y-4 pb-20 flex flex-col min-h-[calc(100vh-8rem)]">
      {/* 1. Area Intelligence Summary Strip */}
      <div className="p-3.5 bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white rounded-2xl border border-slate-800 shadow-md flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-extrabold text-slate-100">{activeLocation.displayName}</span>
          <span className="text-slate-500">•</span>
          <span className="text-sky-300 font-semibold">{plannedDeparture.formattedFull}</span>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-slate-300 font-medium">
          <span><strong>{stores.length}</strong> stores nearby</span>
          <span>•</span>
          <span className="text-emerald-400 font-bold"><strong>{strongChoicesCount}</strong> strong choices</span>
          <span>•</span>
          <span>Traffic: <strong className="text-amber-300">{snapshots[stores[0]?.id]?.traffic_level || 'Moderate'}</strong></span>
          <span>•</span>
          <span className="text-teal-300"><strong>{totalDeals}</strong> verified deals</span>
        </div>
      </div>

      {/* 2. Departure Time Travel Controls Bar */}
      <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 shrink-0">
          <Clock size={16} className="text-sky-600" />
          <span>Departure Time Travel:</span>
        </div>

        {/* Time Preset Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto scrollbar-hide">
          {timePresets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => setPlannedDeparturePreset(preset.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all ${
                plannedDeparture.preset === preset.id
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {preset.label}
            </button>
          ))}
          <button
            onClick={() => setIsTimeModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold whitespace-nowrap transition-all border border-slate-200 dark:border-slate-700"
          >
            Custom...
          </button>
        </div>
      </div>

      {/* 3. Explore by Intent ("What matters most?") */}
      <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles size={14} className="text-sky-600" />
            <span>What matters most today?</span>
          </span>
          <span className="text-[11px] text-slate-500">Recalculates ShopWise scores live</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {intentOptions.map((opt) => {
            const isActive = decisionPriority === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => setDecisionPriority(opt.id)}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 border ${
                  isActive
                    ? 'bg-gradient-to-r from-sky-600 to-teal-600 text-white border-sky-500 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-sky-300'
                }`}
              >
                {opt.icon}
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. Smart Shopping Zone Banner */}
      {smartZoneStores.length >= 2 && (
        <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-sky-950 text-white rounded-2xl p-4 border border-teal-800/60 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-teal-400 text-xs font-black uppercase tracking-wider">
              <Building2 size={14} />
              <span>SMART SHOPPING ZONE</span>
            </div>
            <h3 className="font-extrabold text-sm sm:text-base text-white">
              {zoneName} ({smartZoneStores.length} stores within 1.2 km)
            </h3>
            <p className="text-xs text-slate-300">
              Good match for your shopping needs • Traffic at {plannedDeparture.formattedFull}: <strong className="text-teal-300">Light</strong> • Est. multi-stop mission: <strong className="text-sky-300">48 min</strong>
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                if (selectedZoneStoreIds) setSelectedZoneStoreIds(null);
                else setSelectedZoneStoreIds(smartZoneStores.map((s) => s.id));
              }}
              className="px-3.5 py-2 rounded-xl bg-teal-800/80 hover:bg-teal-700 text-teal-100 font-bold text-xs border border-teal-600 transition-colors"
            >
              {selectedZoneStoreIds ? 'Show All Stores' : 'Explore Zone'}
            </button>
            <button
              onClick={() => {
                setActiveTab('plan');
                sessionStorage.setItem('shopwise_plan_subtab', 'route');
                window.dispatchEvent(new CustomEvent('shopwise_navigate_plan_subtab', { detail: 'route' }));
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-400 hover:to-teal-400 text-white font-extrabold text-xs shadow-sm transition-all"
            >
              Plan This Zone
            </button>
          </div>
        </div>
      )}

      {/* Search Bar & View Mode Controls */}
      <div className="flex flex-col md:flex-row items-center gap-3">
        <div className="relative w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search stores by name, category, or address..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl shrink-0">
          <button
            onClick={() => setViewMode('split')}
            className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              viewMode === 'split' ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-400 shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Layers size={14} /> Split
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              viewMode === 'map' ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-400 shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <MapIcon size={14} /> Map
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              viewMode === 'list' ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-400 shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <List size={14} /> List
          </button>
        </div>
      </div>

      {/* Main Responsive Layout (Desktop 65% Interactive Map / 35% Results) */}
      {viewMode === 'split' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 min-h-[550px]">
          {/* Map Column (65%) */}
          <div className="lg:col-span-7 h-[550px] lg:h-[calc(100vh-14rem)] min-h-[500px] sticky top-20 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm">
            <InteractiveMap stores={filteredStores} height="100%" recommendedStoreId={recommendation?.recommended_store_id} />
          </div>

          {/* Smart Results Column (35%) */}
          <div className="lg:col-span-5 h-[550px] lg:h-[calc(100vh-14rem)] overflow-y-auto space-y-4 pr-1">
            {filteredStores.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6">
                <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm">No stores match intent or filters</h4>
                <p className="text-xs text-slate-500 mt-1">Try selecting "Balanced" intent or clearing your search filter.</p>
              </div>
            ) : (
              filteredStores.map((store) => (
                <StoreCard
                  key={store.id}
                  store={store}
                  snapshot={snapshots[store.id]}
                  isCompared={(selectedCompareIds || []).includes(store.id)}
                  onToggleCompare={() => toggleCompareStore(store.id)}
                  onViewDetails={() => navigateToStoreDetails(store.id)}
                  isRecommended={store.id === recommendation?.recommended_store_id}
                />
              ))
            )}
          </div>
        </div>
      ) : viewMode === 'map' ? (
        <div className="flex-1 min-h-[600px] h-[650px] lg:h-[calc(100vh-14rem)] rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm relative">
          <InteractiveMap stores={filteredStores} height="100%" recommendedStoreId={recommendation?.recommended_store_id} />

          {/* Mobile Bottom Sheet Drawer */}
          <div
            className="md:hidden absolute bottom-0 left-0 right-0 bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 shadow-2xl transition-all z-20 overflow-hidden"
            style={{ height: mobileSheetState === 'collapsed' ? '48px' : mobileSheetState === 'half' ? '45%' : '80%' }}
          >
            <div 
              onClick={() => setMobileSheetState(mobileSheetState === 'collapsed' ? 'half' : mobileSheetState === 'half' ? 'full' : 'collapsed')}
              className="p-2.5 bg-slate-50 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between cursor-pointer select-none"
            >
              <div className="w-12 h-1 bg-slate-300 dark:bg-slate-600 rounded-full mx-auto" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                {filteredStores.length} stores nearby {mobileSheetState === 'collapsed' ? <ChevronUp size={14}/> : <ChevronDown size={14}/>}
              </span>
            </div>
            <div className="p-3 overflow-y-auto h-[calc(100%-48px)] space-y-3">
              {filteredStores.map((store) => (
                <StoreCard
                  key={store.id}
                  store={store}
                  snapshot={snapshots[store.id]}
                  isCompared={(selectedCompareIds || []).includes(store.id)}
                  onToggleCompare={() => toggleCompareStore(store.id)}
                  onViewDetails={() => navigateToStoreDetails(store.id)}
                  isRecommended={store.id === recommendation?.recommended_store_id}
                />
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto pt-2">
          {filteredStores.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6">
              <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
              <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm">No stores match intent or filters</h4>
              <p className="text-xs text-slate-500 mt-1">Try selecting "Balanced" intent or clearing your search filter.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredStores.map((store) => (
                <StoreCard
                  key={store.id}
                  store={store}
                  snapshot={snapshots[store.id]}
                  isCompared={(selectedCompareIds || []).includes(store.id)}
                  onToggleCompare={() => toggleCompareStore(store.id)}
                  onViewDetails={() => navigateToStoreDetails(store.id)}
                  isRecommended={store.id === recommendation?.recommended_store_id}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Time Selector Modal */}
      <TimeSelectorModal isOpen={isTimeModalOpen} onClose={() => setIsTimeModalOpen(false)} />
    </div>
  );
};

