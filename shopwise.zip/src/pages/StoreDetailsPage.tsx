import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  Clock,
  Phone,
  Calendar,
  Bell,
  ShieldAlert,
  Car,
  Users,
  Sun,
  ParkingCircle,
  Wind,
  Tag,
  ArrowLeft,
  Sparkles,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Star,
} from 'lucide-react';
import {
  FloodRiskBadge,
  TrafficBadge,
  CrowdBadge,
  WeatherIcon,
  ParkingBar,
  PriceIndexDisplay,
} from '../components/ConditionBadges';
import { StoreMap } from '../components/StoreMap';
import { InteractiveMap } from '../components/InteractiveMap';
import { TripPlannerModal } from '../components/TripPlannerModal';
import { LiveIoTTelemetryCard } from '../components/LiveIoTTelemetryCard';
import { LiveProductStockChecker } from '../components/LiveProductStockChecker';
import { calculateSafetyScore } from '../utils/recommendationEngine';

export const StoreDetailsPage: React.FC = () => {
  const {
    stores,
    snapshots,
    activeStoreId,
    setActiveTab,
    navigateToStoreDetails,
    alerts,
    toggleStoreAlert,
    userProfile,
    goBack,
    toggleFavoriteStore,
    hourlyForecasts,
    communityReports,
    addCommunityReport,
    upvoteCommunityReport,
    getStoreProducts,
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportType, setReportType] = useState<'All Clear' | 'Heavy Crowds' | 'Minor Flooding' | 'Parking Full'>('All Clear');
  const [reportNote, setReportNote] = useState('');

  const store = stores.find((s) => s.id === activeStoreId) || stores[0];

  if (!store) {
    return (
      <div className="p-8 text-center space-y-4 max-w-md mx-auto my-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Store Details Unavailable</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">Select a store from Explore or Home to view detailed live conditions.</p>
        <button
          onClick={goBack}
          className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs transition-colors"
        >
          Go Back
        </button>
      </div>
    );
  }

  const snap = snapshots[store.id] || {
    store_id: store.id,
    weather_status: 'Clear',
    flood_risk: 'Low',
    traffic_level: 'Light',
    crowd_density: 'Low',
    air_quality_index: 40,
    parking_availability_percent: 70,
    active_promotions: [],
    last_updated: new Date().toISOString(),
  };

  const { score, advantages, warnings } = calculateSafetyScore(store, snap);

  // Check if store alert monitoring is enabled
  const isAlertSet = alerts.some((a) => a.store_id === store.id && a.condition_type === 'flood');
  const isFavorite = userProfile.favorite_stores?.includes(store.id);

  // Nearby alternatives (2 stores closest in distance)
  const nearbyAlternatives = stores
    .filter((s) => s.id !== store.id)
    .sort((a, b) => a.distance_km - b.distance_km)
    .slice(0, 2);

  return (
    <div className="space-y-6 pb-20">
      {/* Navigation Back Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={goBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 bg-white dark:bg-slate-900 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 transition-colors shadow-2xs"
        >
          <ArrowLeft size={16} />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Favorite Toggle */}
          <button
            onClick={() => toggleFavoriteStore(store.id)}
            className={`inline-flex items-center justify-center p-2 rounded-xl border transition-all shadow-xs ${
              isFavorite
                ? 'bg-yellow-50 border-yellow-200 text-yellow-500 dark:bg-yellow-500/10 dark:border-yellow-500/30 dark:text-yellow-400'
                : 'bg-white dark:bg-slate-900 text-slate-400 dark:text-slate-500 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Star size={16} fill={isFavorite ? 'currentColor' : 'none'} />
          </button>
          
          {/* Set Alert Toggle */}
          <button
            onClick={() => toggleStoreAlert(store.id)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all border shadow-xs ${
              isAlertSet
                ? 'bg-rose-600 text-white border-rose-600 hover:bg-rose-500'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Bell size={14} className={isAlertSet ? 'animate-bounce' : ''} />
            <span>{isAlertSet ? 'Alert Active (Monitoring High Risk)' : 'Set Alert Monitoring'}</span>
          </button>
        </div>
      </div>

      {/* Store Banner Hero */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white shadow-xl border border-slate-800">
        <div className="h-64 sm:h-80 w-full relative">
          <img
            src={store.image}
            alt={store.name}
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Top Floating Badges */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={goBack}
                className="p-1.5 rounded-full bg-slate-900/80 backdrop-blur-md text-white border border-white/20 hover:bg-white/20 transition-colors"
              >
                <ArrowLeft size={16} />
              </button>
              <span className="px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-md text-white font-bold text-xs border border-white/20">
                {store.category}
              </span>
            </div>

            <div className="px-3.5 py-1.5 rounded-full bg-emerald-600 text-white font-black font-mono text-xs shadow-md flex items-center gap-1.5">
              <Sparkles size={14} />
              <span>Safety & Convenience Score: {score}/100</span>
            </div>
          </div>

          {/* Hero Bottom Info */}
          <div className="absolute bottom-6 left-6 right-6 space-y-2">
            <h1 className="text-2xl sm:text-3xl font-black text-white">{store.name}</h1>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 font-medium">
              <span className="flex items-center gap-1">
                <MapPin size={14} className="text-sky-400" />
                {store.address} ({store.distance_km} km away)
              </span>
              <span className="flex items-center gap-1">
                <Clock size={14} className="text-teal-400" />
                {store.operating_hours}
              </span>
              <PriceIndexDisplay index={store.average_price_index} />
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Live Condition Breakdown & Map */}
        <div className="lg:col-span-2 space-y-6">
          {/* Live IoT & Radar Sensor Telemetry Card */}
          <LiveIoTTelemetryCard iotSensors={snap.iot_sensors} storeName={store.name} />

          {/* Live ERP Product Availability & Stock Checker */}
          <LiveProductStockChecker products={getStoreProducts(store.id)} storeName={store.name} />

          {/* Live Condition Breakdown Matrix */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Sparkles size={18} className="text-sky-600" />
                <span>Live Condition Snapshot</span>
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                Updated: {new Date(snap.last_updated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {/* Flood Risk */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <ShieldAlert size={16} className="text-rose-500" />
                  <span>Flood Risk</span>
                </div>
                <div className="pt-1">
                  <FloodRiskBadge risk={snap.flood_risk} size="lg" />
                </div>
              </div>

              {/* Traffic */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <Car size={16} className="text-sky-500" />
                  <span>Traffic Level</span>
                </div>
                <div className="pt-1">
                  <TrafficBadge traffic={snap.traffic_level} size="lg" />
                </div>
              </div>

              {/* Crowd Density */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <Users size={16} className="text-teal-500" />
                  <span>Crowd Level</span>
                </div>
                <div className="pt-1">
                  <CrowdBadge crowd={snap.crowd_density} size="lg" />
                </div>
              </div>

              {/* Weather */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <Sun size={16} className="text-amber-500" />
                  <span>Weather</span>
                </div>
                <div className="pt-1 flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100 text-sm">
                  <WeatherIcon status={snap.weather_status} />
                  <span>{snap.weather_status}</span>
                </div>
              </div>

              {/* Air Quality */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <Wind size={16} className="text-slate-500" />
                  <span>Air Quality</span>
                </div>
                <div className="pt-1 font-mono font-bold text-slate-900 dark:text-slate-100 text-sm">
                  AQI {snap.air_quality_index} ({snap.air_quality_index <= 50 ? 'Good' : 'Moderate'})
                </div>
              </div>

              {/* Parking Capacity */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <ParkingCircle size={16} className="text-indigo-500" />
                  <span>Parking Bays</span>
                </div>
                <div className="pt-1 font-mono font-bold text-slate-900 dark:text-slate-100 text-sm">
                  {store.parking_capacity} ({store.parking_type})
                </div>
              </div>
            </div>

            {/* Parking Bar */}
            <div className="pt-2">
              <div className="text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                Live Parking Availability Gauge
              </div>
              <ParkingBar percent={snap.parking_availability_percent} />
            </div>

            {/* Advantages & Warnings */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {advantages.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 space-y-1.5">
                  <div className="text-xs font-extrabold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 size={14} className="text-emerald-600" />
                    <span>Key Advantages</span>
                  </div>
                  <ul className="text-xs text-emerald-800 dark:text-emerald-300 space-y-1 list-disc list-inside">
                    {advantages.map((adv, idx) => (
                      <li key={idx}>{adv}</li>
                    ))}
                  </ul>
                </div>
              )}

              {warnings.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 space-y-1.5">
                  <div className="text-xs font-extrabold text-rose-900 dark:text-rose-300 flex items-center gap-1.5">
                    <AlertTriangle size={14} className="text-rose-600" />
                    <span>Risk Alerts & Warnings</span>
                  </div>
                  <ul className="text-xs text-rose-800 dark:text-rose-300 space-y-1 list-disc list-inside">
                    {warnings.map((warn, idx) => (
                      <li key={idx}>{warn}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Smart Time Forecast (12 hours) */}
            <div className="pt-2">
              <h4 className="text-xs font-bold text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2">
                <Clock size={14} /> Smart Time Forecast (Next 12 Hours)
              </h4>
              <div className="flex gap-2 overflow-x-auto pb-2 -mx-2 px-2 scrollbar-hide">
                {hourlyForecasts
                  .filter((hf) => hf.store_id === store.id)
                  .map((forecast, idx, arr) => {
                    const isBest = forecast.predicted_safety_score === Math.max(...arr.map(a => a.predicted_safety_score));
                    return (
                      <div
                        key={idx}
                        className={`flex-shrink-0 w-24 p-2.5 rounded-xl border flex flex-col items-center gap-1.5 text-center ${
                          isBest
                            ? 'bg-emerald-50 border-emerald-200 dark:bg-emerald-900/20 dark:border-emerald-800'
                            : 'bg-slate-50 border-slate-100 dark:bg-slate-800 dark:border-slate-700'
                        }`}
                      >
                        <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase">
                          {idx === 0 ? 'Now' : `+${idx}h`}
                        </div>
                        {isBest && (
                          <div className="text-[8px] font-black uppercase text-emerald-600 bg-emerald-100 px-1.5 rounded-sm">
                            Best Time
                          </div>
                        )}
                        <div className={`font-mono text-xs font-bold ${isBest ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300'}`}>
                          {forecast.predicted_safety_score}/100
                        </div>
                        <div className="flex gap-1 mt-1">
                          <Users size={12} className={forecast.predicted_crowd_density === 'Low' ? 'text-emerald-500' : forecast.predicted_crowd_density === 'Medium' ? 'text-amber-500' : 'text-rose-500'} />
                          <Car size={12} className={forecast.predicted_traffic_level === 'Light' ? 'text-emerald-500' : forecast.predicted_traffic_level === 'Moderate' ? 'text-amber-500' : 'text-rose-500'} />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* Community Condition Reports */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-2">
                  <Users size={14} /> Community Condition Reports
                </h4>
                <button
                  onClick={() => setIsReportModalOpen(true)}
                  className="text-[10px] font-bold text-sky-600 bg-sky-50 dark:bg-sky-950/40 px-2 py-1 rounded border border-sky-200 dark:border-sky-800 hover:bg-sky-100 transition-colors"
                >
                  Report Current Conditions
                </button>
              </div>
              <div className="space-y-2">
                {communityReports.filter(r => r.store_id === store.id).length === 0 ? (
                  <div className="text-xs text-slate-400 italic py-2">No recent community reports for this store. Be the first!</div>
                ) : (
                  communityReports.filter(r => r.store_id === store.id).slice(0, 3).map(report => (
                    <div key={report.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 text-xs">
                       <div className="flex justify-between items-start mb-1">
                          <span className="font-bold text-slate-700 dark:text-slate-300">{report.report_type}</span>
                          <span className="text-[10px] text-slate-400">Just now</span>
                       </div>
                       {report.note && <p className="text-slate-500 mb-2">{report.note}</p>}
                       <button onClick={() => upvoteCommunityReport(report.id)} className="text-[10px] flex items-center gap-1 text-slate-500 hover:text-sky-600 transition-colors">
                          <CheckCircle2 size={12} /> {report.upvotes} Helpful
                       </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Active Promotions list */}
            {snap.active_promotions.length > 0 && (
              <div className="p-4 rounded-2xl bg-sky-50/80 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800 space-y-2">
                <div className="text-xs font-extrabold text-sky-900 dark:text-sky-300 flex items-center gap-2">
                  <Tag size={16} className="text-sky-600" />
                  <span>Active In-Store Promotions</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {snap.active_promotions.map((promo, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-sky-100 dark:border-sky-900 text-xs font-medium text-slate-800 dark:text-slate-200"
                    >
                      🎁 {promo}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Interactive Map */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-3">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <MapPin size={18} className="text-sky-600" />
              <span>Location & Real-Time Route Map</span>
            </h3>
            <InteractiveMap stores={[store, ...nearbyAlternatives]} selectedStoreId={store.id} height="350px" />
          </div>
        </div>

        {/* Right Column: Trip Planner Action & Nearby Alternatives */}
        <div className="space-y-6">
          {/* Plan Trip Card */}
          <div className="bg-gradient-to-br from-slate-900 via-sky-950 to-slate-900 text-white rounded-3xl p-6 shadow-lg border border-slate-800 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
              <Calendar size={24} />
            </div>

            <div>
              <h3 className="text-lg font-bold text-white">Plan Your Trip Right Now</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Schedule your travel window. We will save this trip and monitor live conditions for updates.
              </p>
            </div>

            <button
              onClick={() => setIsModalOpen(true)}
              className="w-full py-3.5 px-4 rounded-2xl bg-sky-500 hover:bg-sky-400 text-white font-extrabold text-xs shadow-lg shadow-sky-500/30 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles size={16} />
              <span>Plan My Trip Now</span>
            </button>
          </div>

          {/* Nearby Alternatives Section */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">
              Nearby Alternatives
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Stores within a similar distance with live status comparison:
            </p>

            <div className="space-y-3">
              {nearbyAlternatives.map((alt) => {
                const altSnap = snapshots[alt.id];
                const { score: altScore } = calculateSafetyScore(alt, altSnap);

                return (
                  <div
                    key={alt.id}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-sky-500 transition-all space-y-2"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={alt.image}
                        alt={alt.name}
                        className="w-12 h-12 rounded-xl object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                          {alt.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {alt.category} • {alt.distance_km} km away
                        </div>
                      </div>
                      <div className="text-right shrink-0 font-mono font-bold text-xs text-emerald-600">
                        {altScore}/100
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-1 text-[11px] text-slate-600 dark:text-slate-400 font-medium">
                        <ShieldAlert size={12} className="text-amber-500" />
                        <span>Flood: {altSnap?.flood_risk || 'Low'}</span>
                      </div>

                      <button
                        onClick={() => navigateToStoreDetails(alt.id)}
                        className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-sky-600 text-white font-semibold text-[11px] transition-colors"
                      >
                        Switch to This Store
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Trip Planner Modal */}
      {isModalOpen && (
        <TripPlannerModal
          store={store}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      )}

      {/* Community Report Modal */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Users className="text-sky-600" size={18} />
              <span>Report Conditions for {store.name}</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-1">
                  Condition Status
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['All Clear', 'Heavy Crowds', 'Minor Flooding', 'Parking Full'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setReportType(type)}
                      className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all ${
                        reportType === type
                          ? 'bg-sky-50 dark:bg-sky-950/60 border-sky-500 text-sky-700 dark:text-sky-300'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-1">
                  Note / Observation (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g., Short lines at checkout, road clear"
                  value={reportNote}
                  onChange={(e) => setReportNote(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setIsReportModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  addCommunityReport({
                    user_id: userProfile.id,
                    store_id: store.id,
                    report_type: reportType,
                    note: reportNote || `${reportType} reported by shopper.`,
                  });
                  setIsReportModalOpen(false);
                  setReportNote('');
                }}
                className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors shadow-md shadow-sky-600/20"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
