import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, TrendingUp, Clock, MapPin, Award, CheckCircle } from 'lucide-react';

export const InsightsPage: React.FC = () => {
  const { goBack, userProfile } = useApp();
  const { points } = userProfile;

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-fade-in">
      <div className="flex items-center gap-4">
        <button
          onClick={goBack}
          className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft size={20} className="text-slate-600 dark:text-slate-300" />
        </button>
        <h1 className="text-2xl font-black tracking-tight text-slate-900 dark:text-slate-100">
          Smart Shopper Insights
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-sky-100 dark:bg-sky-900/40 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
            <CheckCircle size={24} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Trips Optimized</h3>
            <div className="text-3xl font-black text-slate-900 dark:text-slate-100 mt-1">{points.estimated_trips_optimized}</div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-900/40 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
            <Clock size={24} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Time Saved</h3>
            <div className="text-3xl font-black text-slate-900 dark:text-slate-100 mt-1">{points.estimated_time_saved_minutes} min</div>
            <p className="text-xs text-slate-500 mt-1">by avoiding traffic & crowds</p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 text-lg">
            <Award className="text-sky-500" /> Smart Shopper Badges
          </h2>
        </div>
        <div className="p-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 text-center">
             <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-500 flex items-center justify-center mb-3">
               <Award size={24} />
             </div>
             <div className="font-bold text-sm text-slate-800 dark:text-slate-200">5 Smart Trips</div>
             <div className="text-[10px] text-slate-500 mt-1">Completed!</div>
          </div>
          <div className="flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 text-center">
             <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-500 flex items-center justify-center mb-3">
               <MapPin size={24} />
             </div>
             <div className="font-bold text-sm text-slate-800 dark:text-slate-200">Flood-Safe Streak</div>
             <div className="text-[10px] text-slate-500 mt-1">Avoided 3 high-risk zones</div>
          </div>
          <div className="flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 text-center opacity-50">
             <div className="w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-500 flex items-center justify-center mb-3">
               <TrendingUp size={24} />
             </div>
             <div className="font-bold text-sm text-slate-800 dark:text-slate-200">Off-Peak Master</div>
             <div className="text-[10px] text-slate-500 mt-1">Locked</div>
          </div>
          <div className="flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 text-center opacity-50">
             <div className="w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-500 flex items-center justify-center mb-3">
               <Award size={24} />
             </div>
             <div className="font-bold text-sm text-slate-800 dark:text-slate-200">Local Guide</div>
             <div className="text-[10px] text-slate-500 mt-1">Locked</div>
          </div>
        </div>
      </div>
    </div>
  );
};
