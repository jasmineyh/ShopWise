import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Columns3,
  CheckCircle2,
  ShieldAlert,
  Car,
  Users,
  Sun,
  ParkingCircle,
  Wind,
  Tag,
  DollarSign,
  Plus,
  Trash2,
  Sparkles,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import {
  FloodRiskBadge,
  TrafficBadge,
  CrowdBadge,
  WeatherIcon,
  PriceIndexDisplay,
} from '../components/ConditionBadges';
import { calculateSafetyScore } from '../utils/recommendationEngine';
import { TripPlannerModal } from '../components/TripPlannerModal';

export const ComparePage: React.FC = () => {
  const {
    stores,
    snapshots,
    selectedCompareIds,
    toggleCompareStore,
    clearCompare,
    setActiveTab,
    navigateToStoreDetails,
    goBack,
  } = useApp();

  const [selectedModalStoreId, setSelectedModalStoreId] = useState<string | null>(null);

  const selectedStores = stores.filter((s) => (selectedCompareIds || []).includes(s.id));

  if (selectedStores.length < 2) {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-4">
          <button
            onClick={goBack}
            className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-600 dark:text-slate-300" />
          </button>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 text-center max-w-xl mx-auto shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-teal-100 dark:bg-teal-950 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto mb-4">
            <Columns3 size={28} />
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 mb-2">
            Compare Side-by-Side
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-6">
            Select 2 to 3 stores from the Dashboard to compare their live conditions (flood risk, traffic, crowds, parking, AQI, price index) in a side-by-side matrix with automated best-value highlights!
          </p>

          <div className="space-y-3 max-w-md mx-auto text-left mb-6">
            <div className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Select Stores to Compare ({(selectedCompareIds || []).length}/3):</span>
            </div>
            <div className="grid grid-cols-1 gap-2 max-h-72 overflow-y-auto pr-1">
              {stores.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2 text-center">Loading stores in your active area...</p>
              ) : (
                stores.map((s) => {
                  const isSelected = (selectedCompareIds || []).includes(s.id);
                  return (
                    <button
                      key={s.id}
                      onClick={() => toggleCompareStore(s.id)}
                      className={`p-3 rounded-xl border flex items-center justify-between text-xs font-semibold transition-all ${
                        isSelected
                          ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 text-sky-800 dark:text-sky-200 ring-1 ring-sky-500'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img src={s.image} alt="" className="w-8 h-8 rounded-lg object-cover shrink-0" />
                        <div className="min-w-0 text-left">
                          <div className="font-bold text-xs truncate">{s.name}</div>
                          <div className="text-[10px] text-slate-400">{s.category} · {s.distance_km} km away</div>
                        </div>
                      </div>
                      {isSelected ? (
                        <span className="text-[10px] font-bold bg-sky-600 text-white px-2 py-0.5 rounded-md">Selected</span>
                      ) : (
                        <Plus size={16} className="text-sky-600 shrink-0" />
                      )}
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <button
            onClick={() => setActiveTab('dashboard')}
            className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors shadow-xs inline-flex items-center gap-2"
          >
            <span>Return to Dashboard</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    );
  }

  // Calculate scores for selected stores
  const evaluatedMap = selectedStores.map((s) => {
    const snap = snapshots[s.id] || {
      store_id: s.id,
      weather_status: 'Clear',
      flood_risk: 'Low',
      traffic_level: 'Light',
      crowd_density: 'Low',
      air_quality_index: 40,
      parking_availability_percent: 70,
      active_promotions: [],
      last_updated: new Date().toISOString(),
    };
    const { score } = calculateSafetyScore(s, snap);
    return { store: s, snapshot: snap, score };
  });

  // Determine row winners
  const bestScore = Math.max(...evaluatedMap.map((m) => m.score));
  const bestParking = Math.max(...evaluatedMap.map((m) => m.snapshot.parking_availability_percent));
  const bestPriceIndex = Math.min(...evaluatedMap.map((m) => m.store.average_price_index));
  const minDistance = Math.min(...evaluatedMap.map((m) => m.store.distance_km));
  const bestAqi = Math.min(...evaluatedMap.map((m) => m.snapshot.air_quality_index));

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <div className="flex items-start gap-4">
          <button
            onClick={goBack}
            className="p-2 mt-1 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shrink-0"
          >
            <ArrowLeft size={20} className="text-slate-600 dark:text-slate-300" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-teal-600 dark:text-teal-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Columns3 size={16} />
              <span>Side-By-Side Comparison</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-slate-100">
              Comparing {selectedStores.length} Stores
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Best values in each row are highlighted in emerald green.
            </p>
          </div>
        </div>

        <button
          onClick={clearCompare}
          className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 dark:bg-slate-800 dark:hover:bg-rose-950/40 text-xs font-bold transition-colors border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <Trash2 size={14} />
          <span>Clear Selection</span>
        </button>
      </div>

      {/* Quick Store Selector Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs font-bold text-slate-700 dark:text-slate-300">
          <span>Manage Compared Stores ({selectedStores.length}/3 selected):</span>
          {selectedStores.length < 3 && (
            <span className="text-sky-600 dark:text-sky-400 font-semibold text-[11px]">
              + Click any store below to add it to your 3-way comparison
            </span>
          )}
        </div>
        <div className="flex flex-wrap gap-2 pt-1">
          {stores.map((s) => {
            const isSelected = (selectedCompareIds || []).includes(s.id);
            return (
              <button
                key={s.id}
                onClick={() => toggleCompareStore(s.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border cursor-pointer ${
                  isSelected
                    ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                <span>{s.name}</span>
                {isSelected ? (
                  <CheckCircle2 size={13} className="text-white shrink-0" />
                ) : (
                  <Plus size={13} className="text-slate-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Side-by-side Matrix Table */}
      <div className="overflow-x-auto rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-md">
        <table className="w-full text-left border-collapse min-w-[700px]">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50">
              <th className="p-4 w-48 text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Condition Factor
              </th>
              {evaluatedMap.map(({ store }) => (
                <th key={store.id} className="p-4 text-slate-900 dark:text-slate-100 min-w-[220px]">
                  <div className="flex flex-col gap-2">
                    <img
                      src={store.image}
                      alt={store.name}
                      className="w-full h-28 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                    />
                    <div>
                      <div className="font-extrabold text-sm line-clamp-1">{store.name}</div>
                      <div className="text-xs text-slate-500 font-medium">{store.category}</div>
                    </div>
                  </div>
                </th>
              ))}
              {selectedStores.length < 3 && (
                <th className="p-4 text-slate-900 dark:text-slate-100 min-w-[220px] bg-slate-100/40 dark:bg-slate-800/20 border-l border-dashed border-slate-200 dark:border-slate-800">
                  <div className="flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-dashed border-sky-300 dark:border-sky-800/60 bg-sky-50/50 dark:bg-sky-950/20 text-center h-full">
                    <div className="w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900 text-sky-600 dark:text-sky-300 flex items-center justify-center font-bold mb-1.5">
                      <Plus size={18} />
                    </div>
                    <div className="text-xs font-extrabold text-sky-800 dark:text-sky-300">
                      Add 3rd Store
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Click a store pill above to compare 3 stores side-by-side
                    </p>
                  </div>
                </th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {/* Row 1: Safety & Convenience Score */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Sparkles size={16} className="text-sky-500" />
                <span>Overall Score</span>
              </td>
              {evaluatedMap.map(({ store, score }) => {
                const isBest = score === bestScore;
                return (
                  <td
                    key={store.id}
                    className={`p-4 font-mono font-bold text-sm ${
                      isBest
                        ? 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-black'
                        : 'text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{score} / 100</span>
                      {isBest && (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-extrabold uppercase">
                          Highest
                        </span>
                      )}
                    </div>
                  </td>
                );
              })}
              {selectedStores.length < 3 && (
                <td className="p-4 text-center text-slate-400 bg-slate-50/20 dark:bg-slate-900/20 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">
                  Select 3rd store
                </td>
              )}
            </tr>

            {/* Row 2: Distance */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300">Distance</td>
              {evaluatedMap.map(({ store }) => {
                const isClosest = store.distance_km === minDistance;
                return (
                  <td
                    key={store.id}
                    className={`p-4 font-semibold ${
                      isClosest
                        ? 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {store.distance_km} km away {isClosest ? ' (Closest)' : ''}
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 3: Flood Risk */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <ShieldAlert size={16} className="text-rose-500" />
                <span>Flood Risk</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => {
                const isSafest = snapshot.flood_risk === 'Low';
                return (
                  <td
                    key={store.id}
                    className={`p-4 ${
                      isSafest ? 'bg-emerald-50/80 dark:bg-emerald-950/40' : ''
                    }`}
                  >
                    <FloodRiskBadge risk={snapshot.flood_risk} />
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 4: Traffic Level */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Car size={16} className="text-sky-500" />
                <span>Traffic Level</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => {
                const isLightest = snapshot.traffic_level === 'Light';
                return (
                  <td
                    key={store.id}
                    className={`p-4 ${
                      isLightest ? 'bg-emerald-50/80 dark:bg-emerald-950/40' : ''
                    }`}
                  >
                    <TrafficBadge traffic={snapshot.traffic_level} />
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 5: Crowd Density */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Users size={16} className="text-teal-500" />
                <span>Crowd Density</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => {
                const isLowest = snapshot.crowd_density === 'Low';
                return (
                  <td
                    key={store.id}
                    className={`p-4 ${
                      isLowest ? 'bg-emerald-50/80 dark:bg-emerald-950/40' : ''
                    }`}
                  >
                    <CrowdBadge crowd={snapshot.crowd_density} />
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 6: Weather */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Sun size={16} className="text-amber-500" />
                <span>Weather Status</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => (
                <td key={store.id} className="p-4">
                  <div className="flex items-center gap-2 font-semibold">
                    <WeatherIcon status={snapshot.weather_status} />
                    <span>{snapshot.weather_status}</span>
                  </div>
                </td>
              ))}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 7: Parking Availability */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <ParkingCircle size={16} className="text-indigo-500" />
                <span>Parking Free %</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => {
                const isHighest = snapshot.parking_availability_percent === bestParking;
                return (
                  <td
                    key={store.id}
                    className={`p-4 font-mono font-bold text-sm ${
                      isHighest
                        ? 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-black'
                        : 'text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    {snapshot.parking_availability_percent}% Free ({store.parking_type})
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 8: Air Quality (AQI) */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Wind size={16} className="text-slate-500" />
                <span>Air Quality (AQI)</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => {
                const isBest = snapshot.air_quality_index === bestAqi;
                return (
                  <td
                    key={store.id}
                    className={`p-4 font-mono font-semibold ${
                      isBest ? 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800' : ''
                    }`}
                  >
                    AQI {snapshot.air_quality_index} ({snapshot.air_quality_index <= 50 ? 'Good' : 'Moderate'})
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 9: Average Price Index */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <DollarSign size={16} className="text-emerald-600" />
                <span>Price Index</span>
              </td>
              {evaluatedMap.map(({ store }) => {
                const isLowestPrice = store.average_price_index === bestPriceIndex;
                return (
                  <td
                    key={store.id}
                    className={`p-4 ${
                      isLowestPrice ? 'bg-emerald-50/80 dark:bg-emerald-950/40' : ''
                    }`}
                  >
                    <PriceIndexDisplay index={store.average_price_index} />
                  </td>
                );
              })}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 10: Active Promotions */}
            <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
              <td className="p-4 font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Tag size={16} className="text-sky-600" />
                <span>Active Promotions</span>
              </td>
              {evaluatedMap.map(({ store, snapshot }) => (
                <td key={store.id} className="p-4">
                  {snapshot.active_promotions.length > 0 ? (
                    <ul className="space-y-1 text-[11px] text-sky-800 dark:text-sky-300 font-medium list-disc list-inside">
                      {snapshot.active_promotions.map((p, idx) => (
                        <li key={idx}>{p}</li>
                      ))}
                    </ul>
                  ) : (
                    <span className="text-slate-400 italic">No active promotions</span>
                  )}
                </td>
              ))}
              {selectedStores.length < 3 && <td className="p-4 text-center text-slate-400 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] italic">—</td>}
            </tr>

            {/* Row 11: Action Row "Choose This Store" */}
            <tr className="bg-slate-50 dark:bg-slate-800/50">
              <td className="p-4 font-extrabold text-slate-900 dark:text-slate-100">Action</td>
              {evaluatedMap.map(({ store }) => (
                <td key={store.id} className="p-4">
                  <button
                    onClick={() => setSelectedModalStoreId(store.id)}
                    className="w-full py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs transition-colors shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 size={14} />
                    <span>Choose This Store</span>
                  </button>
                </td>
              ))}
              {selectedStores.length < 3 && (
                <td className="p-4 text-center bg-slate-100/30 dark:bg-slate-800/20 border-l border-dashed border-slate-200 dark:border-slate-800 text-[11px] text-slate-400 italic">
                  Select 3rd store above
                </td>
              )}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Trip Planner Modal */}
      {selectedModalStoreId && (
        <TripPlannerModal
          store={stores.find((s) => s.id === selectedModalStoreId)!}
          isOpen={!!selectedModalStoreId}
          onClose={() => setSelectedModalStoreId(null)}
        />
      )}
    </div>
  );
};
