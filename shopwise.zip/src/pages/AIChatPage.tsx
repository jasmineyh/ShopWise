import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Bot,
  User,
  Send,
  Sparkles,
  RefreshCw,
  ShoppingBag,
  ShieldAlert,
  MapPin,
  TrendingUp,
  Lightbulb,
  ArrowLeft
} from 'lucide-react';
import { ChatMessage } from '../types';

export const AIChatPage: React.FC = () => {
  const { stores, snapshots, userProfile, shoppingLists, shoppingListItems, goBack } = useApp();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      text: `Hello ${userProfile?.name || 'there'}! I'm your **ShopWise AI Copilot**. 

I monitor real-time flood risks, traffic conditions, price indices, parking availability, and active promotions across all nearby shopping destinations.

How can I assist your trip today? You can ask me questions like:
- *"Which store is safest to visit right now without flood risk?"*
- *"Where should I shop today to complete my Weekly Groceries list?"*
- *"Are there any active sales or discounts nearby?"*`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.sender === 'user' ? 'user' : 'assistant',
            content: m.text,
          })),
          stores,
          snapshots,
          userProfile,
          shoppingLists,
          shoppingListItems
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const replyText = data.reply || 'Here is what I found based on live store data...';

        const assistantMsg: ChatMessage = {
          id: 'msg_' + (Date.now() + 1),
          sender: 'assistant',
          text: replyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setMessages((prev) => [...prev, assistantMsg]);
      } else {
        const errData = await response.json().catch(() => ({}));
        const assistantMsg: ChatMessage = {
          id: 'msg_' + (Date.now() + 1),
          sender: 'assistant',
          text: errData.reply || 'I am currently having trouble reaching the AI server. Please check your network connection.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      }
    } catch (err) {
      console.error('Chat error:', err);
      const assistantMsg: ChatMessage = {
        id: 'msg_' + (Date.now() + 1),
        sender: 'assistant',
        text: 'Sorry, I ran into an error generating a reply. Please try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const samplePrompts = [
    'Which store is safest right now considering flood risk?',
    'Compare Apex Hypermarket vs Metro Grand Galleria.',
    'Where can I find cheap groceries with easy parking?',
    'Which store has active promotions or deals today?',
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-sky-900 via-slate-900 to-teal-900 text-white rounded-2xl p-5 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-sky-800/40">
        <div className="flex items-center gap-3">
          <button
            onClick={goBack}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors shrink-0"
          >
            <ArrowLeft size={20} className="text-white" />
          </button>
          <div className="w-12 h-12 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300 shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2">
              ShopWise AI Copilot
              <span className="bg-sky-500/30 text-sky-300 text-xs px-2.5 py-0.5 rounded-full font-mono border border-sky-400/30">
                Gemini Powered
              </span>
            </h1>
            <p className="text-xs text-slate-300 mt-0.5">
              Ask any question about store conditions, optimal travel timing, deals, and flood safety.
            </p>
          </div>
        </div>

        <button
          onClick={() =>
            setMessages([
              {
                id: 'msg_reset',
                sender: 'assistant',
                text: 'Chat history cleared. How can I assist your next shopping trip?',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ])
          }
          className="text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 transition-all border border-white/10 self-end sm:self-center shrink-0"
        >
          <RefreshCw size={13} />
          <span>Clear Chat</span>
        </button>
      </div>

      {/* Suggested Prompt Chips */}
      <div className="flex flex-wrap items-center gap-2 px-1">
        <span className="text-xs font-semibold text-slate-400 flex items-center gap-1">
          <Lightbulb size={13} className="text-amber-500" />
          Quick Ask:
        </span>
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(p)}
            className="text-xs px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-sky-500 text-slate-700 dark:text-slate-300 hover:text-sky-600 transition-all shadow-sm"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Main Chat Thread Container */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm flex flex-col h-[520px] overflow-hidden">
        {/* Messages Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[88%] ${isUser ? 'ml-auto flex-row-reverse' : ''}`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-white font-bold text-xs ${
                    isUser
                      ? 'bg-sky-600'
                      : 'bg-gradient-to-tr from-sky-600 to-teal-600 shadow-md shadow-sky-600/20'
                  }`}
                >
                  {isUser ? <User size={16} /> : <Bot size={16} />}
                </div>

                {/* Message Bubble */}
                <div className="space-y-1">
                  <div
                    className={`p-3.5 rounded-2xl text-sm leading-relaxed ${
                      isUser
                        ? 'bg-sky-600 text-white rounded-tr-none'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-200/60 dark:border-slate-700/60'
                    }`}
                  >
                    {/* Render message with bold text formatting */}
                    {msg.text.split('\n').map((line, lIdx) => (
                      <p key={lIdx} className={lIdx > 0 ? 'mt-2' : ''}>
                        {line.split('**').map((part, pIdx) =>
                          pIdx % 2 === 1 ? (
                            <strong key={pIdx} className="font-semibold text-sky-900 dark:text-sky-300">
                              {part}
                            </strong>
                          ) : (
                            part
                          )
                        )}
                      </p>
                    ))}
                  </div>

                  <span
                    className={`text-[10px] text-slate-400 px-1 block ${
                      isUser ? 'text-right' : 'text-left'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex gap-3 max-w-[80%]">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-600 to-teal-600 flex items-center justify-center text-white shrink-0">
                <Bot size={16} />
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-tl-none flex items-center gap-2 border border-slate-200 dark:border-slate-700">
                <Sparkles size={16} className="animate-spin text-sky-500" />
                <span className="text-xs font-medium">Analyzing real-time store conditions...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Form Bar */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about store conditions, route safety, sales..."
              className="flex-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500 placeholder-slate-400"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-sky-600/20 shrink-0"
            >
              <span>Send</span>
              <Send size={15} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
