import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  ArrowRight,
  Bell,
  ShieldAlert,
  Car,
  Users,
  Sun,
  CheckCheck,
  Clock,
  Heart,
  ChevronDown,
  ChevronUp,
  Info,
  Building2,
  Navigation,
  Compass
} from 'lucide-react';
import { StoreCard } from '../components/StoreCard';
import { TripPlannerModal } from '../components/TripPlannerModal';
import { BestTimeForecastWidget } from '../components/BestTimeForecastWidget';
import { HomeQuickActions } from '../components/HomeQuickActions';
import { TimeSelectorModal } from '../components/TimeSelectorModal';
import { DecisionPrioritySelector } from '../components/DecisionPrioritySelector';
import { TimeMachineWidget } from '../components/TimeMachineWidget';
import { WorthTheDetourWidget } from '../components/WorthTheDetourWidget';
import { TripEtaBreakdown } from '../components/TripEtaBreakdown';
import { getScoreCategory } from '../utils/recommendationEngine';

export const HomePage: React.FC = () => {
  const {
    userProfile,
    stores,
    snapshots,
    recommendation,
    isEvaluating,
    evaluateBestStore,
    setActiveTab,
    navigateToStoreDetails,
    alerts,
    markAlertRead,
    markAllAlertsRead,
    plannedDeparture,
    activeLocation,
    decisionPriority
  } = useApp();

  const [selectedModalStoreId, setSelectedModalStoreId] = useState<string | null>(null);
  const [showAllAlerts, setShowAllAlerts] = useState(false);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [isTimeModalOpen, setIsTimeModalOpen] = useState(false);

  // Recommended Store Object
  const recommendedStore = stores.find(
    (s) => s.id === recommendation?.recommended_store_id
  ) || stores[0];

  const favoriteStores = stores.filter((s) => (userProfile?.favorite_stores || []).includes(s.id));

  const sortedAlerts = [...alerts].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  const unreadCount = alerts.filter((a) => !a.is_read).length;

  const scoreInfo = getScoreCategory(recommendation?.safety_score || 88);

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* 1. Hero Headline + Spatial & Time Context */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-slate-800 space-y-4">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-20 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-sky-400 text-xs font-bold uppercase tracking-wider">
            <span className="flex items-center gap-1 bg-sky-950/80 px-2.5 py-1 rounded-full border border-sky-800/60">
              <MapPin size={12} className="text-sky-400" /> {activeLocation?.displayName || userProfile.home_address}
            </span>
            <span className="text-slate-600">•</span>
            <button
              onClick={() => setIsTimeModalOpen(true)}
              className="flex items-center gap-1.5 text-amber-300 bg-amber-950/60 hover:bg-amber-900/60 px-2.5 py-1 rounded-full border border-amber-800/60 text-xs font-bold transition-colors cursor-pointer"
            >
              <Clock size={12} className="text-amber-400" />
              <span>Departure: {plannedDeparture.formattedFull}</span>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pt-1">
            <div>
              <h1 className="font-serif-display text-3xl sm:text-4xl md:text-5xl font-normal tracking-tight text-white leading-tight">
                Where should you shop today?
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
                ShopWise calculates real-time traffic, store crowd density, flood risks & promotions to find your smartest shopping destination.
              </p>
            </div>

            {/* Recalculate AI Button */}
            <button
              onClick={evaluateBestStore}
              disabled={isEvaluating}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-sky-500 via-teal-500 to-sky-400 hover:from-sky-400 hover:to-teal-400 text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-sky-500/25 transition-all active:scale-[0.98] flex items-center justify-center gap-2 shrink-0 border border-white/20 disabled:opacity-50"
            >
              <Sparkles className={`w-4 h-4 ${isEvaluating ? 'animate-spin' : ''}`} />
              <span>{isEvaluating ? 'Evaluating Live Sensors...' : 'Find My Best Store'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Top Decision Cockpit (ShopWise Choice Card) */}
      {recommendation && recommendedStore && (
        <div className="bg-gradient-to-br from-white via-sky-50/40 to-teal-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-sky-950/20 border-2 border-sky-500/60 rounded-3xl p-6 shadow-md relative overflow-hidden space-y-4">
          {/* Header Row */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-sky-100 dark:border-sky-900/50 pb-3">
            <div className="flex items-center gap-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-600 text-white text-xs font-extrabold uppercase tracking-wider shadow-xs">
                <Sparkles size={14} />
                <span>SHOPWISE CHOICE</span>
              </div>
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 hidden sm:inline">
                Target Departure: <strong className="text-slate-800 dark:text-slate-200">{plannedDeparture.formattedFull}</strong>
              </span>
            </div>

            {/* ShopWise Score Badge */}
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold shadow-xs border ${scoreInfo.bgClass}`}>
              <ShieldCheck size={14} className={scoreInfo.colorClass} />
              <span className={scoreInfo.colorClass}>
                ShopWise Score: <strong>{recommendation.safety_score}/100</strong> ({scoreInfo.label})
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
            {/* Store Information & Key Advantages */}
            <div className="lg:col-span-2 space-y-3">
              <div>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-100 flex flex-wrap items-center gap-2">
                  <span>Go to {recommendedStore.name}</span>
                </h2>
                <div className="flex flex-wrap items-center gap-3 text-xs font-semibold text-slate-600 dark:text-slate-300 mt-1">
                  <span className="flex items-center gap-1"><Navigation size={13} className="text-sky-600" /> {recommendedStore.distance_km} km away</span>
                  <span>•</span>
                  <span className="flex items-center gap-1"><Clock size={13} className="text-teal-600" /> ~{recommendedStore.travel_time_minutes || Math.round(recommendedStore.distance_km * 3)} mins drive</span>
                  <span>•</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-bold">Open now ({recommendedStore.operating_hours})</span>
                </div>
              </div>

              {/* Reason Summary */}
              <div className="space-y-2">
                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/90 border border-sky-200 dark:border-sky-900/60 text-slate-800 dark:text-slate-200 text-xs sm:text-sm font-semibold leading-relaxed shadow-2xs">
                  {recommendation.reason_summary}
                </div>

                {recommendation.advantages.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2">
                    {recommendation.advantages.map((adv, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-xs font-semibold border border-emerald-200 dark:border-emerald-800"
                      >
                        <CheckCircle2 size={12} className="text-emerald-600 dark:text-emerald-400 shrink-0" />
                        {adv}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Actions & Store Snippet Card */}
            <div className="flex flex-col justify-between bg-white dark:bg-slate-800/70 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={recommendedStore.image}
                  alt={recommendedStore.name}
                  className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                />
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {recommendedStore.category}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {recommendedStore.address}
                  </div>
                  <div className="text-[11px] font-semibold text-sky-600 dark:text-sky-400 mt-0.5">
                    {recommendedStore.parking_capacity} parking bays ({recommendedStore.parking_type})
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                <button
                  onClick={() => setSelectedModalStoreId(recommendedStore.id)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Calendar size={14} />
                  <span>Plan This Trip</span>
                </button>
                <button
                  onClick={() => navigateToStoreDetails(recommendedStore.id)}
                  className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-700 dark:hover:bg-slate-600 font-bold text-xs transition-colors flex items-center justify-center gap-1"
                >
                  <span>See Why</span>
                  <ArrowRight size={12} />
                </button>
              </div>
            </div>
          </div>

          {/* Expandable Trade-Off Analysis */}
          <div className="pt-2 border-t border-sky-100 dark:border-sky-900/40 flex items-center justify-between">
            <button
              onClick={() => setShowAnalysis(!showAnalysis)}
              className="text-xs font-bold text-sky-700 dark:text-sky-300 hover:underline flex items-center gap-1.5 transition-colors"
            >
              <Info size={14} />
              <span>{showAnalysis ? 'Hide AI Trade-off Analysis' : 'Why? See Deeper AI Trade-off Analysis'}</span>
              {showAnalysis ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
          </div>

          {showAnalysis && (
            <div className="p-4 bg-sky-50/80 dark:bg-sky-950/40 rounded-2xl border border-sky-200 dark:border-sky-800 text-xs text-slate-700 dark:text-slate-300 space-y-2 animate-in fade-in duration-200">
              <div className="font-bold text-sky-900 dark:text-sky-200 flex items-center gap-1.5">
                <Sparkles size={14} className="text-sky-600" />
                <span>Multi-Factor AI Trade-off Breakdown:</span>
              </div>
              <p className="leading-relaxed">
                {recommendation.tradeoff_analysis ||
                  `Evaluated flood risks, traffic congestion, aisle crowds, parking availability, and active deals across all nearby options for your planned departure (${plannedDeparture.formattedFull}). ${recommendedStore.name} provides the lowest travel friction and lowest expected queue delay.`}
              </p>
            </div>
          )}
        </div>
      )}

      {/* 3. Decision Priority Selector ("What matters most today?") */}
      <DecisionPrioritySelector />

      {/* 4. ShopWise Time Machine (Interactive Timeline & Forecasts) */}
      <TimeMachineWidget />

      {/* 5. "Worth the Detour?" Feature Widget */}
      <WorthTheDetourWidget />

      {/* 6. Total Shopping Journey ETA Breakdown */}
      <TripEtaBreakdown />

      {/* 7. Quick Actions Shortcuts ("Plan Your Shopping") */}
      <HomeQuickActions onOpenBestTimeModal={() => setIsTimeModalOpen(true)} />

      {/* 8. Suggested Nearby Stores Section */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
              Suggested Nearby Stores
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Evaluated for live conditions & travel time</p>
          </div>
          <button
            onClick={() => setActiveTab('explore')}
            className="text-xs text-sky-600 dark:text-sky-400 font-bold hover:underline flex items-center gap-1"
          >
            Explore Map <ArrowRight size={12} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stores.slice(0, 3).map((store) => (
            <StoreCard
              key={store.id}
              store={store}
              snapshot={snapshots[store.id]}
              showCompare={false}
              onViewDetails={() => navigateToStoreDetails(store.id)}
              isRecommended={store.id === recommendation?.recommended_store_id}
            />
          ))}
        </div>
      </div>

      {/* 9. Favorite Stores Section */}
      {favoriteStores.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Heart size={18} className="text-rose-500 fill-rose-500" />
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
              Your Favorite Stores
            </h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {favoriteStores.map((store) => (
              <StoreCard
                key={store.id}
                store={store}
                snapshot={snapshots[store.id]}
                showCompare={false}
                onViewDetails={() => navigateToStoreDetails(store.id)}
                isRecommended={store.id === recommendation?.recommended_store_id}
              />
            ))}
          </div>
        </div>
      )}

      {/* 10. Real-Time Risk Alerts (At the Bottom) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
              <Bell size={20} />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
                Live Area Alerts
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Real-time sensor feed on flood risks, road jams & crowds</p>
            </div>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllAlertsRead}
              className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 transition-colors flex items-center gap-1.5 shrink-0"
            >
              <CheckCheck size={16} className="text-emerald-500" />
              <span>Mark All as Read</span>
            </button>
          )}
        </div>

        {sortedAlerts.length === 0 ? (
          <div className="text-center py-6 text-slate-500 text-sm">No active alerts in your area. All clear!</div>
        ) : (
          <div className="space-y-3">
            {sortedAlerts.slice(0, showAllAlerts ? sortedAlerts.length : 3).map((alert) => {
              const store = stores.find((s) => s.id === alert.store_id);

              let icon = <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />;
              if (alert.condition_type === 'traffic') {
                icon = <Car className="w-5 h-5 text-sky-600 shrink-0" />;
              } else if (alert.condition_type === 'crowd') {
                icon = <Users className="w-5 h-5 text-amber-600 shrink-0" />;
              } else if (alert.condition_type === 'weather') {
                icon = <Sun className="w-5 h-5 text-indigo-600 shrink-0" />;
              }

              return (
                <div
                  key={alert.id}
                  onClick={() => {
                    markAlertRead(alert.id);
                    if (store) navigateToStoreDetails(store.id);
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-4 ${
                    !alert.is_read
                      ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className={`p-2.5 rounded-xl shrink-0 ${
                    !alert.is_read ? 'bg-white dark:bg-rose-950 border border-rose-100 dark:border-rose-900' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
                  }`}>
                    {icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <h4 className={`text-sm font-bold truncate ${!alert.is_read ? 'text-slate-900 dark:text-slate-100' : 'text-slate-700 dark:text-slate-300'}`}>
                          {store ? store.name : 'Area Alert'}
                        </h4>
                        {!alert.is_read && (
                          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                        )}
                      </div>
                      <span className="text-[10px] font-semibold text-slate-400 whitespace-nowrap">
                        {new Date(alert.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className={`text-xs leading-relaxed ${!alert.is_read ? 'text-slate-700 dark:text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                      {alert.message}
                    </p>
                  </div>
                </div>
              );
            })}
            {!showAllAlerts && sortedAlerts.length > 3 && (
              <div className="text-center pt-2">
                <button
                  onClick={() => setShowAllAlerts(true)}
                  className="text-xs text-sky-600 dark:text-sky-400 font-bold hover:underline"
                >
                  View {sortedAlerts.length - 3} more area alerts
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Trip Planner Modal */}
      {selectedModalStoreId && (
        <TripPlannerModal
          store={stores.find((s) => s.id === selectedModalStoreId)!}
          isOpen={!!selectedModalStoreId}
          onClose={() => setSelectedModalStoreId(null)}
        />
      )}

      {/* Time Selector Modal */}
      <TimeSelectorModal
        isOpen={isTimeModalOpen}
        onClose={() => setIsTimeModalOpen(false)}
      />
    </div>
  );
};
