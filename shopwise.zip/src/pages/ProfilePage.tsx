import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserProfile, StoreCategory } from '../types';
import {
  User,
  MapPin,
  Bell,
  Check,
  Save,
  ShieldCheck,
  Tag,
  Sparkles,
  ArrowLeft,
  Globe,
  Moon,
  Star,
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { userProfile, updateUserProfile, goBack, savedLocations, addSavedLocation, removeSavedLocation } = useApp();

  const [formData, setFormData] = useState<UserProfile>(userProfile);

  const categoriesList: StoreCategory[] = [
    'Mall',
    'Supermarket',
    'Hypermarket',
    'Pharmacy',
    'Department Store',
    'Electronics',
  ];

  const handleCategoryToggle = (cat: StoreCategory) => {
    setFormData((prev) => {
      const cats = prev?.preferred_categories || [];
      const exists = cats.includes(cat);
      const updated = exists
        ? cats.filter((c) => c !== cat)
        : [...cats, cat];
      return { ...prev, preferred_categories: updated };
    });
  };

  const handleNotificationToggle = (
    key: keyof UserProfile['notification_preferences']
  ) => {
    setFormData((prev) => ({
      ...prev,
      notification_preferences: {
        ...prev.notification_preferences,
        [key]: !prev.notification_preferences[key],
      },
    }));
  };

  const handlePreferenceChange = (
    key: keyof UserProfile['preferences'],
    value: string
  ) => {
    setFormData((prev) => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [key]: value,
      },
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile(formData);
  };

  return (
    <div className="space-y-6 pb-20 max-w-3xl mx-auto">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <div className="flex items-center gap-4">
          <button
            onClick={goBack}
            className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shrink-0"
          >
            <ArrowLeft size={20} className="text-slate-600 dark:text-slate-300" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-sky-600 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-sky-600/20">
              {formData.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-slate-100">{formData.name}</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">{formData.email}</p>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Personal Details & Home Location */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <User size={18} className="text-sky-600" />
            <span>Personal & Home Location Settings</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                Home Base Address (Used for distance calculation)
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-sky-600 w-4 h-4" />
                <input
                  type="text"
                  value={formData.home_address}
                  onChange={(e) => setFormData({ ...formData, home_address: e.target.value })}
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Saved Locations */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <MapPin size={18} className="text-sky-600" />
            <span>Saved Locations</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage your saved locations for quick routing and planning.
          </p>
          <div className="space-y-2">
            {savedLocations.length === 0 ? (
              <p className="text-xs text-slate-500 italic">No saved locations.</p>
            ) : (
              savedLocations.map(loc => (
                <div key={loc.id} className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800">
                  <div>
                    <div className="font-bold text-sm text-slate-900 dark:text-slate-100">{loc.label}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{loc.address}</div>
                  </div>
                  <button onClick={() => removeSavedLocation(loc.id)} className="text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 p-2 rounded-lg">
                    Remove
                  </button>
                </div>
              ))
            )}
            <button
              onClick={() => {
                const label = prompt('Enter a label (e.g. Work):');
                if (label) {
                  const address = prompt('Enter address:');
                  if (address) {
                    addSavedLocation({ user_id: userProfile.id, label, address, latitude: 0, longitude: 0 });
                  }
                }
              }}
              className="mt-2 px-4 py-2 rounded-xl bg-sky-50 dark:bg-sky-900/20 text-sky-700 dark:text-sky-300 font-bold text-xs hover:bg-sky-100 dark:hover:bg-sky-900/40 transition-colors"
            >
              + Add New Location
            </button>
          </div>
        </div>

        {/* Preferred Categories */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-3">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Tag size={18} className="text-teal-600" />
            <span>Preferred Store Categories</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Select the types of stores you visit most frequently.
          </p>

          <div className="flex flex-wrap gap-2 pt-1">
            {categoriesList.map((cat) => {
              const isSelected = (formData?.preferred_categories || []).includes(cat);
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => handleCategoryToggle(cat)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  {isSelected && <Check size={14} />}
                  <span>{cat}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* App Settings */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Sparkles size={18} className="text-indigo-500" />
            <span>App Settings</span>
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200">
                <Globe size={16} className="text-slate-500" />
                Language
              </div>
              <select
                value={formData.preferences?.language || 'English'}
                onChange={(e) => handlePreferenceChange('language', e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <option value="English">English</option>
                <option value="Bahasa Malaysia">Bahasa Malaysia</option>
                <option value="Mandarin">Mandarin</option>
              </select>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200">
                <Moon size={16} className="text-slate-500" />
                Dark Mode
              </div>
              <select
                value={formData.preferences?.theme || 'system'}
                onChange={(e) => handlePreferenceChange('theme', e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <option value="system">System Default</option>
                <option value="light">Light Mode</option>
                <option value="dark">Dark Mode</option>
              </select>
            </div>
          </div>
        </div>

        {/* Notification Preferences Toggles */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Bell size={18} className="text-amber-500" />
            <span>Notification & Alert Toggles</span>
          </h3>

          <div className="space-y-3 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            <div className="pt-2 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900 dark:text-slate-100">Flash Flood Risk Alerts</div>
                <div className="text-slate-500">Notify immediately if flood risk rises to High on shopping routes.</div>
              </div>
              <input
                type="checkbox"
                checked={formData.notification_preferences.flood_alerts}
                onChange={() => handleNotificationToggle('flood_alerts')}
                className="w-5 h-5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer"
              />
            </div>

            <div className="pt-3 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900 dark:text-slate-100">Traffic Gridlock Alerts</div>
                <div className="text-slate-500">Notify when major traffic congestion (+20 min delay) develops.</div>
              </div>
              <input
                type="checkbox"
                checked={formData.notification_preferences.traffic_alerts}
                onChange={() => handleNotificationToggle('traffic_alerts')}
                className="w-5 h-5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer"
              />
            </div>

            <div className="pt-3 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900 dark:text-slate-100">High Crowd Density Alerts</div>
                <div className="text-slate-500">Notify if parking or checkout queue crowds spike.</div>
              </div>
              <input
                type="checkbox"
                checked={formData.notification_preferences.crowd_alerts}
                onChange={() => handleNotificationToggle('crowd_alerts')}
                className="w-5 h-5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer"
              />
            </div>

            <div className="pt-3 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900 dark:text-slate-100">Promotions & Discount Alerts</div>
                <div className="text-slate-500">Receive notifications for exclusive weekend flash sales.</div>
              </div>
              <input
                type="checkbox"
                checked={formData.notification_preferences.promotion_alerts}
                onChange={() => handleNotificationToggle('promotion_alerts')}
                className="w-5 h-5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Submit Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-extrabold text-xs shadow-lg shadow-sky-600/20 transition-all flex items-center gap-2"
          >
            <Save size={16} />
            <span>Save Preferences</span>
          </button>
        </div>
      </form>
    </div>
  );
};
