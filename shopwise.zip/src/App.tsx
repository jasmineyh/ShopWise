import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { ToastContainer } from './components/ToastContainer';
import { HomePage } from './pages/HomePage';
import { ExplorePage } from './pages/ExplorePage';
import { PlanPage } from './pages/PlanPage';
import { StoreDetailsPage } from './pages/StoreDetailsPage';
import { ProfilePage } from './pages/ProfilePage';
import { AIChatPage } from './pages/AIChatPage';
import { InsightsPage } from './pages/InsightsPage';
import { OnboardingOverlay } from './components/OnboardingOverlay';
import { FloatingAssistant } from './components/FloatingAssistant';
import { CompareTray } from './components/CompareTray';

const AppContent: React.FC = () => {
  const { activeTab, userProfile } = useApp();

  useEffect(() => {
    const theme = userProfile.preferences?.theme || 'system';
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }
  }, [userProfile.preferences?.theme]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white relative">
      <OnboardingOverlay />
      <Header />
      <ToastContainer />

      <div className="flex-1 flex max-w-7xl w-full mx-auto relative">
        <Navigation />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-full overflow-x-hidden relative">
          {activeTab === 'home' && <HomePage />}
          {activeTab === 'explore' && <ExplorePage />}
          {activeTab === 'plan' && <PlanPage />}
          {activeTab === 'assistant' && <AIChatPage />}
          {activeTab === 'store_details' && <StoreDetailsPage />}
          {activeTab === 'profile' && <ProfilePage />}
          {activeTab === 'insights' && <InsightsPage />}
        </main>
      </div>
      <CompareTray />
      <FloatingAssistant />
    </div>
  );
};


export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
