import { ActiveLocation, Store } from '../types';

export interface LocationSuggestion {
  placeId: string;
  displayName: string;
  formattedAddress: string;
  latitude?: number;
  longitude?: number;
  city?: string;
  country?: string;
}

// Calculate Haversine distance in kilometers
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return Math.round(distance * 10) / 10; // Round to 1 decimal place
}

// Search locations with autocomplete
export async function searchLocationsAutocomplete(
  query: string,
  latitude?: number,
  longitude?: number
): Promise<{ suggestions: LocationSuggestion[]; error?: string }> {
  if (!query || query.trim().length < 2) return { suggestions: [] };

  try {
    let url = `/api/places/autocomplete?query=${encodeURIComponent(query)}`;
    if (latitude !== undefined && longitude !== undefined) {
      url += `&latitude=${latitude}&longitude=${longitude}`;
    }
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      if (data.suggestions) {
        return { suggestions: data.suggestions };
      }
    } else {
      const errData = await res.json().catch(() => ({}));
      return { suggestions: [], error: errData.error || 'Unable to search locations right now.' };
    }
  } catch (err) {
    console.warn('Error fetching autocomplete suggestions:', err);
  }

  return { suggestions: [], error: 'Unable to search locations right now.' };
}

// Fetch Place Details for exact lat/lng and location components
export async function fetchPlaceDetails(placeId: string): Promise<ActiveLocation | null> {
  if (!placeId) return null;
  try {
    const res = await fetch(`/api/places/details?placeId=${encodeURIComponent(placeId)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.location) {
        return data.location;
      }
    }
  } catch (err) {
    console.warn('Error fetching place details:', err);
  }
  return null;
}

// Fetch nearby supermarkets for active location
export async function fetchNearbySupermarkets(
  location: ActiveLocation,
  radiusKm: number = 5,
  query?: string,
  categoryFilter?: string
): Promise<Store[]> {
  try {
    const res = await fetch('/api/places/nearby', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        latitude: location.latitude,
        longitude: location.longitude,
        radiusMeters: radiusKm * 1000,
        query,
        categoryFilter
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.stores && Array.isArray(data.stores)) {
        return data.stores;
      }
    }
  } catch (err) {
    console.warn('Error fetching nearby stores:', err);
  }

  return [];
}

// Reverse geocode lat/lng to readable location
export async function reverseGeocode(
  lat: number,
  lng: number
): Promise<ActiveLocation> {
  try {
    const res = await fetch(`/api/places/geocode?lat=${lat}&lng=${lng}`);
    if (res.ok) {
      const data = await res.json();
      if (data.location) {
        return data.location;
      }
    }
  } catch (err) {
    console.warn('Error in reverse geocode:', err);
  }

  return {
    displayName: 'Current Location',
    formattedAddress: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
    latitude: lat,
    longitude: lng
  };
}

// Compute driving route / time between points
export async function computeRoute(
  origin: { latitude: number; longitude: number },
  destination: { latitude: number; longitude: number }
): Promise<{ distanceKm: number; durationMinutes: number }> {
  try {
    const res = await fetch('/api/routes/compute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ origin, destination })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.distanceKm !== undefined) {
        return {
          distanceKm: data.distanceKm,
          durationMinutes: data.durationMinutes || Math.round(data.distanceKm * 2.5)
        };
      }
    }
  } catch (err) {
    console.warn('Error computing route:', err);
  }

  const distanceKm = calculateHaversineDistance(
    origin.latitude,
    origin.longitude,
    destination.latitude,
    destination.longitude
  );
  return {
    distanceKm,
    durationMinutes: Math.max(3, Math.round(distanceKm * 2.5))
  };
}
