import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Clock, Calendar, Check, ChevronLeft, ChevronRight, Sparkles, TrendingDown, TrendingUp, Sun, Moon, Zap } from 'lucide-react';
import { DeparturePreset } from '../types';

interface ScrollingTimePickerProps {
  onApply?: () => void;
  compact?: boolean;
}

export const ScrollingTimePicker: React.FC<ScrollingTimePickerProps> = ({ onApply, compact = false }) => {
  const { plannedDeparture, setPlannedDeparturePreset } = useApp();

  // Selected date mode: 'today' | 'tomorrow' | 'custom'
  const initialDate = new Date(plannedDeparture.targetDate);
  const [selectedDay, setSelectedDay] = useState<'today' | 'tomorrow' | 'custom'>(() => {
    const now = new Date();
    const target = new Date(plannedDeparture.targetDate);
    if (target.toDateString() === now.toDateString()) return 'today';
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    if (target.toDateString() === tomorrow.toDateString()) return 'tomorrow';
    return 'custom';
  });

  const [customDateStr, setCustomDateStr] = useState<string>(() => {
    const d = new Date(plannedDeparture.targetDate);
    return d.toISOString().split('T')[0];
  });

  // Hour (1-12), Minute (0-55 step 5), Period ('AM' | 'PM')
  const getInitialHour12 = (d: Date) => {
    const h = d.getHours();
    if (h === 0) return 12;
    if (h > 12) return h - 12;
    return h;
  };

  const getInitialPeriod = (d: Date): 'AM' | 'PM' => {
    return d.getHours() >= 12 ? 'PM' : 'AM';
  };

  const getNearest5Min = (d: Date) => {
    const mins = d.getMinutes();
    return Math.round(mins / 5) * 5 % 60;
  };

  const [selectedHour, setSelectedHour] = useState<number>(getInitialHour12(initialDate));
  const [selectedMinute, setSelectedMinute] = useState<number>(getNearest5Min(initialDate));
  const [selectedPeriod, setSelectedPeriod] = useState<'AM' | 'PM'>(getInitialPeriod(initialDate));

  const hourRef = useRef<HTMLDivElement>(null);
  const minuteRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  const hoursList = [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
  const minutesList = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];

  // Helper to construct a Date object from current picker selections
  const buildTargetDate = (
    dayMode: 'today' | 'tomorrow' | 'custom',
    h12: number,
    m: number,
    period: 'AM' | 'PM',
    cDateStr: string
  ): Date => {
    let base = new Date();
    if (dayMode === 'tomorrow') {
      base.setDate(base.getDate() + 1);
    } else if (dayMode === 'custom' && cDateStr) {
      const parts = cDateStr.split('-').map(Number);
      if (parts.length === 3) {
        base = new Date(parts[0], parts[1] - 1, parts[2]);
      }
    }

    let hours24 = h12;
    if (period === 'PM' && h12 < 12) hours24 += 12;
    if (period === 'AM' && h12 === 12) hours24 = 0;

    base.setHours(hours24, m, 0, 0);
    return base;
  };

  // Live apply
  const applyTimeSelection = (
    dayMode: 'today' | 'tomorrow' | 'custom',
    h12: number,
    m: number,
    period: 'AM' | 'PM',
    cDateStr: string
  ) => {
    const targetDate = buildTargetDate(dayMode, h12, m, period, cDateStr);
    
    // Determine if fits a standard preset or custom
    const now = new Date();
    const diffMins = Math.round((targetDate.getTime() - now.getTime()) / 60000);

    if (Math.abs(diffMins) <= 3) {
      setPlannedDeparturePreset('now');
    } else if (Math.abs(diffMins - 30) <= 3) {
      setPlannedDeparturePreset('in_30m');
    } else if (Math.abs(diffMins - 60) <= 5) {
      setPlannedDeparturePreset('in_1h');
    } else {
      setPlannedDeparturePreset('custom', targetDate);
    }

    if (onApply) onApply();
  };

  // Scroll time wheel centering
  const scrollToSelected = () => {
    if (hourRef.current) {
      const activeEl = hourRef.current.querySelector('[data-selected="true"]');
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
      }
    }
    if (minuteRef.current) {
      const activeEl = minuteRef.current.querySelector('[data-selected="true"]');
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
      }
    }
  };

  useEffect(() => {
    scrollToSelected();
  }, [selectedHour, selectedMinute, selectedPeriod, selectedDay]);

  // Scroll timeline horizontally
  const scrollTimeline = (direction: 'left' | 'right') => {
    if (timelineRef.current) {
      const amount = direction === 'left' ? -220 : 220;
      timelineRef.current.scrollBy({ left: amount, behavior: 'smooth' });
    }
  };

  // Generate 24 continuous hourly/half-hourly time slots starting from 7 AM to 11 PM
  const generateTimelineSlots = () => {
    const slots = [];
    const now = new Date();
    const startHour = 7;
    const endHour = 22; // 10 PM

    for (let h = startHour; h <= endHour; h++) {
      for (const m of [0, 30]) {
        const slotDate = new Date();
        if (selectedDay === 'tomorrow') {
          slotDate.setDate(slotDate.getDate() + 1);
        }
        slotDate.setHours(h, m, 0, 0);

        const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
        const period = h >= 12 ? 'PM' : 'AM';
        const timeStr = `${h12}:${m === 0 ? '00' : m} ${period}`;

        // Predict crowd & traffic based on hour
        let traffic: 'Light' | 'Moderate' | 'Heavy' = 'Light';
        let crowd: 'Low' | 'Medium' | 'High' = 'Low';
        let deltaMins = 0;

        if ((h >= 8 && h <= 9) || (h >= 17 && h <= 19)) {
          traffic = 'Heavy';
          crowd = 'High';
          deltaMins = +12;
        } else if (h >= 12 && h <= 14) {
          traffic = 'Moderate';
          crowd = 'Medium';
          deltaMins = +4;
        } else if (h >= 19 && h <= 21) {
          traffic = 'Light';
          crowd = 'Low';
          deltaMins = -10;
        } else {
          traffic = 'Light';
          crowd = 'Low';
          deltaMins = -5;
        }

        const isCurrentlySelected =
          plannedDeparture.targetDate.getHours() === h &&
          Math.abs(plannedDeparture.targetDate.getMinutes() - m) < 15 &&
          ((selectedDay === 'today' && slotDate.toDateString() === now.toDateString()) ||
            (selectedDay === 'tomorrow' && slotDate.toDateString() !== now.toDateString()));

        slots.push({
          date: slotDate,
          hour24: h,
          hour12: h12,
          minute: m,
          period: period as 'AM' | 'PM',
          timeStr,
          traffic,
          crowd,
          deltaMins,
          isSelected: isCurrentlySelected,
          isBest: h === 19 && m === 30, // 7:30 PM best window highlight
        });
      }
    }
    return slots;
  };

  const timelineSlots = generateTimelineSlots();

  return (
    <div className="space-y-4">
      {/* 1. Day & Date Quick Selector Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-100 dark:bg-slate-800/80 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-1 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => {
              setSelectedDay('today');
              applyTimeSelection('today', selectedHour, selectedMinute, selectedPeriod, customDateStr);
            }}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              selectedDay === 'today'
                ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-xs border border-slate-200 dark:border-slate-700'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Today
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedDay('tomorrow');
              applyTimeSelection('tomorrow', selectedHour, selectedMinute, selectedPeriod, customDateStr);
            }}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              selectedDay === 'tomorrow'
                ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-xs border border-slate-200 dark:border-slate-700'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Tomorrow
          </button>
          <button
            type="button"
            onClick={() => setSelectedDay('custom')}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 ${
              selectedDay === 'custom'
                ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-xs border border-slate-200 dark:border-slate-700'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Calendar size={13} />
            <span>Pick Date</span>
          </button>
        </div>

        {selectedDay === 'custom' && (
          <input
            type="date"
            value={customDateStr}
            onChange={(e) => {
              setCustomDateStr(e.target.value);
              applyTimeSelection('custom', selectedHour, selectedMinute, selectedPeriod, e.target.value);
            }}
            className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-2.5 py-1 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        )}
      </div>

      {/* 2. Interactive Horizontal Scrolling Timeline Bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 px-1">
          <span className="flex items-center gap-1.5">
            <Clock size={13} className="text-sky-600 dark:text-sky-400" />
            <span>Scroll Time Slots</span>
          </span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => scrollTimeline('left')}
              className="p-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
              title="Scroll left"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              type="button"
              onClick={() => scrollTimeline('right')}
              className="p-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
              title="Scroll right"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        <div
          ref={timelineRef}
          className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 scrollbar-thin scrollbar-thumb-sky-500/30 scroll-smooth snap-x"
          style={{ scrollSnapType: 'x mandatory' }}
        >
          {timelineSlots.map((slot, index) => (
            <button
              key={index}
              type="button"
              onClick={() => {
                setSelectedHour(slot.hour12);
                setSelectedMinute(slot.minute);
                setSelectedPeriod(slot.period);
                applyTimeSelection(selectedDay, slot.hour12, slot.minute, slot.period, customDateStr);
              }}
              className={`snap-center shrink-0 p-3 rounded-2xl border text-left transition-all min-w-[110px] relative flex flex-col justify-between ${
                slot.isSelected
                  ? 'bg-gradient-to-tr from-sky-600 to-teal-600 text-white border-sky-400 shadow-md shadow-sky-500/30 ring-2 ring-sky-300'
                  : 'bg-white dark:bg-slate-800/80 hover:bg-sky-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700'
              }`}
            >
              {slot.isBest && (
                <span className="absolute -top-2 right-1.5 text-[8px] font-black bg-amber-400 text-slate-950 px-1.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                  Optimal
                </span>
              )}

              <div>
                <div className="text-xs font-black tracking-tight flex items-center justify-between">
                  <span>{slot.timeStr}</span>
                  {slot.isSelected && <Check size={12} className="text-white" />}
                </div>
                <div className={`text-[10px] font-medium mt-0.5 ${slot.isSelected ? 'text-sky-100' : 'text-slate-500 dark:text-slate-400'}`}>
                  {slot.crowd} crowd
                </div>
              </div>

              <div className="mt-2 pt-1.5 border-t border-slate-200/40 dark:border-slate-700/60 flex items-center justify-between text-[10px]">
                <span className={`font-semibold ${
                  slot.isSelected
                    ? 'text-white'
                    : slot.traffic === 'Light'
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : slot.traffic === 'Moderate'
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}>
                  {slot.traffic}
                </span>

                <span className={`font-bold ${
                  slot.deltaMins < 0
                    ? slot.isSelected ? 'text-emerald-200' : 'text-emerald-600 dark:text-emerald-400'
                    : slot.isSelected ? 'text-rose-200' : 'text-rose-600 dark:text-rose-400'
                }`}>
                  {slot.deltaMins < 0 ? `${slot.deltaMins}m` : slot.deltaMins > 0 ? `+${slot.deltaMins}m` : '0m'}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 3. Scrolling Hour & Minute Drum / Roller Picker Wheels */}
      <div className="p-4 bg-slate-50 dark:bg-slate-900/90 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <Zap size={13} className="text-amber-500" />
            <span>Precise Scrolling Time Drum</span>
          </label>
          <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => {
                setSelectedPeriod('AM');
                applyTimeSelection(selectedDay, selectedHour, selectedMinute, 'AM', customDateStr);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                selectedPeriod === 'AM'
                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Sun size={11} /> AM
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedPeriod('PM');
                applyTimeSelection(selectedDay, selectedHour, selectedMinute, 'PM', customDateStr);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                selectedPeriod === 'PM'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Moon size={11} /> PM
            </button>
          </div>
        </div>

        {/* Scrollable Hours & Minutes Wheel Grid */}
        <div className="grid grid-cols-2 gap-4">
          {/* Hours Scroll Wheel */}
          <div className="space-y-1">
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 text-center">HOUR</div>
            <div
              ref={hourRef}
              className="h-32 overflow-y-auto rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-2 scrollbar-thin scrollbar-thumb-sky-500/30 flex flex-col items-center gap-1 shadow-inner"
            >
              {hoursList.map((h) => {
                const isSelected = selectedHour === h;
                return (
                  <button
                    key={h}
                    type="button"
                    data-selected={isSelected}
                    onClick={() => {
                      setSelectedHour(h);
                      applyTimeSelection(selectedDay, h, selectedMinute, selectedPeriod, customDateStr);
                    }}
                    className={`w-full py-1.5 rounded-lg text-center font-mono font-bold text-sm transition-all ${
                      isSelected
                        ? 'bg-sky-600 text-white shadow-xs scale-105'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                    }`}
                  >
                    {String(h).padStart(2, '0')}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Minutes Scroll Wheel */}
          <div className="space-y-1">
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 text-center">MINUTE</div>
            <div
              ref={minuteRef}
              className="h-32 overflow-y-auto rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-2 scrollbar-thin scrollbar-thumb-sky-500/30 flex flex-col items-center gap-1 shadow-inner"
            >
              {minutesList.map((m) => {
                const isSelected = selectedMinute === m;
                return (
                  <button
                    key={m}
                    type="button"
                    data-selected={isSelected}
                    onClick={() => {
                      setSelectedMinute(m);
                      applyTimeSelection(selectedDay, selectedHour, m, selectedPeriod, customDateStr);
                    }}
                    className={`w-full py-1.5 rounded-lg text-center font-mono font-bold text-sm transition-all ${
                      isSelected
                        ? 'bg-sky-600 text-white shadow-xs scale-105'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                    }`}
                  >
                    :{String(m).padStart(2, '0')}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Selected Departure Summary Strip */}
        <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800/80 flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-600 dark:text-slate-300">Selected Departure:</span>
          <span className="font-black text-sky-700 dark:text-sky-300 text-sm">
            {plannedDeparture.formattedFull}
          </span>
        </div>
      </div>
    </div>
  );
};
