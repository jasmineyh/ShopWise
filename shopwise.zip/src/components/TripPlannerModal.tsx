import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Store } from '../types';
import { Calendar, Clock, Sparkles, X, CheckCircle2 } from 'lucide-react';

interface TripPlannerModalProps {
  store: Store;
  isOpen: boolean;
  onClose: () => void;
}

export const TripPlannerModal: React.FC<TripPlannerModalProps> = ({ store, isOpen, onClose }) => {
  const { createSavedTrip } = useApp();
  const [selectedTimeOption, setSelectedTimeOption] = useState<string>('Now');
  const [customTime, setCustomTime] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  if (!isOpen || !store) return null;

  const timeOptions = [
    { label: 'Now', desc: 'Depart immediately' },
    { label: 'In 1 hour', desc: 'Recommended low-traffic window' },
    { label: 'Later today (6:00 PM)', desc: 'After work peak hour' },
    { label: 'Tomorrow morning (10:00 AM)', desc: 'Fresh morning store opening' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalTime = selectedTimeOption === 'Custom' ? customTime || 'Later today' : selectedTimeOption;
    createSavedTrip(store.id, finalTime, notes || `Shopping trip to ${store.name}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl max-w-lg w-full p-6 relative overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0 font-bold">
              <Calendar size={20} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Plan Trip to {store.name}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {store.category} • {store.distance_km} km away
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Time Picker Options */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              Select Planned Time
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {timeOptions.map((opt) => {
                const isSelected = selectedTimeOption === opt.label;
                return (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => setSelectedTimeOption(opt.label)}
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-sky-600 bg-sky-50/60 dark:bg-sky-950/40 text-sky-900 dark:text-sky-100 ring-2 ring-sky-500/20'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full font-bold text-xs">
                      <span>{opt.label}</span>
                      {isSelected && <CheckCircle2 size={14} className="text-sky-600 dark:text-sky-400" />}
                    </div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">{opt.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Time Optional */}
          <div>
            <button
              type="button"
              onClick={() => setSelectedTimeOption('Custom')}
              className="text-xs font-semibold text-sky-600 hover:underline mb-1 inline-block"
            >
              + Or specify custom time
            </button>
            {selectedTimeOption === 'Custom' && (
              <input
                type="text"
                placeholder="e.g. Saturday at 2:30 PM"
                value={customTime}
                onChange={(e) => setCustomTime(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
              Shopping List / Notes (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Fresh organic vegetables, milk, pharmacy vitamins..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all shadow-md shadow-sky-600/20 flex items-center gap-1.5"
            >
              <Sparkles size={14} />
              <span>Confirm & Save Trip</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
