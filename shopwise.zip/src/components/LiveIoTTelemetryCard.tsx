import React from 'react';
import { Radio, Users, Gauge, Clock, Eye, ParkingCircle, Activity, ShieldCheck } from 'lucide-react';
import { IoTSensorData } from '../types';

interface LiveIoTTelemetryCardProps {
  iotSensors?: IoTSensorData;
  storeName?: string;
  compact?: boolean;
}

export const LiveIoTTelemetryCard: React.FC<LiveIoTTelemetryCardProps> = ({
  iotSensors,
  storeName = 'Store',
  compact = false,
}) => {
  if (!iotSensors) {
    return (
      <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 italic">
        📡 Live IoT Telemetry sensor synchronizing...
      </div>
    );
  }

  if (compact) {
    return (
      <div className="p-3 rounded-2xl bg-slate-900 text-white border border-slate-800 space-y-2 shadow-xs">
        <div className="flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-1.5 font-bold text-sky-400">
            <Radio size={14} className="animate-pulse text-emerald-400" />
            <span>Live IoT Sensor Feed</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Ping {iotSensors.last_sensor_ping_sec}s ago</span>
        </div>
        <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
          <div className="bg-slate-800/80 p-1.5 rounded-lg text-center">
            <div className="text-[9px] text-slate-400 uppercase font-sans">Occupancy</div>
            <div className="font-bold text-emerald-400">{iotSensors.live_occupancy_count}/{iotSensors.max_capacity}</div>
          </div>
          <div className="bg-slate-800/80 p-1.5 rounded-lg text-center">
            <div className="text-[9px] text-slate-400 uppercase font-sans">Checkout Queue</div>
            <div className="font-bold text-sky-400">{iotSensors.checkout_wait_minutes} min wait</div>
          </div>
          <div className="bg-slate-800/80 p-1.5 rounded-lg text-center">
            <div className="text-[9px] text-slate-400 uppercase font-sans">Road Speed</div>
            <div className="font-bold text-amber-400">{iotSensors.road_sensor_speed_kmh} km/h</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950 text-white border border-slate-800 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </div>
          <div>
            <h4 className="font-extrabold text-sm text-slate-100 flex items-center gap-1.5">
              <span>Real-Time IoT & Computer Vision Sensor Telemetry</span>
            </h4>
            <p className="text-[10px] text-slate-400 font-medium">
              Live overhead radar, queue sensors, and road speed flow counters for {storeName}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
            <Activity size={12} /> {iotSensors.sensor_status}
          </span>
          <span className="text-[10px] font-mono text-slate-400">
            Last ping: {iotSensors.last_sensor_ping_sec}s ago
          </span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Live Occupancy */}
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
            <Users size={12} className="text-emerald-400" />
            <span>Indoor Occupancy</span>
          </div>
          <div className="text-sm font-extrabold font-mono text-emerald-400">
            {iotSensors.live_occupancy_count} <span className="text-[10px] text-slate-400 font-normal">/ {iotSensors.max_capacity}</span>
          </div>
          <div className="text-[10px] text-slate-400 font-medium">
            {iotSensors.occupancy_percent}% capacity filled
          </div>
        </div>

        {/* CV Queue Wait */}
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
            <Eye size={12} className="text-sky-400" />
            <span>Checkout Queue (AI CV)</span>
          </div>
          <div className="text-sm font-extrabold font-mono text-sky-400">
            {iotSensors.checkout_wait_minutes} min <span className="text-[10px] text-slate-400 font-normal">est. wait</span>
          </div>
          <div className="text-[10px] text-slate-400 font-medium">
            Density: <span className="font-bold text-slate-200">{iotSensors.camera_cv_density}</span>
          </div>
        </div>

        {/* Road Sensor Speed */}
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
            <Gauge size={12} className="text-amber-400" />
            <span>Road Flow Speed</span>
          </div>
          <div className="text-sm font-extrabold font-mono text-amber-400">
            {iotSensors.road_sensor_speed_kmh} km/h
          </div>
          <div className="text-[10px] text-slate-400 font-medium">
            Flow: {iotSensors.traffic_flow_rate_cars_per_min} cars/min
          </div>
        </div>

        {/* Parking Bays Sensor */}
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
          <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
            <ParkingCircle size={12} className="text-teal-400" />
            <span>Ultrasonic Parking</span>
          </div>
          <div className="text-sm font-extrabold font-mono text-teal-400">
            {iotSensors.parking_sensor_free_bays} <span className="text-[10px] text-slate-400 font-normal">free bays</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
            <ShieldCheck size={10} /> Sensor Calibrated
          </div>
        </div>
      </div>
    </div>
  );
};
