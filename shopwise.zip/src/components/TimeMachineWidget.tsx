import React, { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeparturePreset } from '../types';
import { Clock, Sparkles, TrendingDown, TrendingUp, Check, ChevronRight, ChevronLeft, Calendar } from 'lucide-react';

export const TimeMachineWidget: React.FC = () => {
  const { plannedDeparture, setPlannedDeparturePreset } = useApp();
  const timelineRef = useRef<HTMLDivElement>(null);
  const [selectedDayTab, setSelectedDayTab] = useState<'today' | 'tomorrow'>('today');

  const scrollTimeline = (direction: 'left' | 'right') => {
    if (timelineRef.current) {
      const scrollAmount = direction === 'left' ? -260 : 260;
      timelineRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const presets: { id: DeparturePreset; label: string; timeStr: string; traffic: string; crowd: string; deltaMins: number; isBest?: boolean }[] = [
    { id: 'now', label: 'Go Now', timeStr: 'Live Sensor', traffic: 'Moderate', crowd: 'Busy', deltaMins: 0 },
    { id: 'in_30m', label: 'In 30m', timeStr: '+30 mins', traffic: 'Heavy', crowd: 'Peak', deltaMins: +8 },
    { id: 'in_1h', label: 'In 1h', timeStr: '+1 hour', traffic: 'Light', crowd: 'Moderate', deltaMins: -5 },
    { id: 'this_afternoon', label: 'Afternoon', timeStr: '3:00 PM', traffic: 'Moderate', crowd: 'Moderate', deltaMins: -3 },
    { id: 'this_evening', label: 'Evening', timeStr: '6:30 PM', traffic: 'Light', crowd: 'Low', deltaMins: -11, isBest: true },
    { id: 'tomorrow_morning', label: 'Tomorrow AM', timeStr: '10:00 AM', traffic: 'Light', crowd: 'Very Low', deltaMins: -14 },
  ];

  // Generate continuous timeline slots from 7:00 AM to 10:00 PM
  const generateHourlySlots = () => {
    const slots = [];
    const now = new Date();
    const isTomorrowSelected = selectedDayTab === 'tomorrow';

    for (let h = 7; h <= 22; h++) {
      for (const m of [0, 30]) {
        const slotDate = new Date();
        if (isTomorrowSelected) {
          slotDate.setDate(slotDate.getDate() + 1);
        }
        slotDate.setHours(h, m, 0, 0);

        const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
        const period = h >= 12 ? 'PM' : 'AM';
        const timeStr = `${h12}:${m === 0 ? '00' : m} ${period}`;

        let traffic: 'Light' | 'Moderate' | 'Heavy' = 'Light';
        let crowd: 'Low' | 'Medium' | 'High' = 'Low';
        let deltaMins = 0;

        if ((h >= 8 && h <= 9) || (h >= 17 && h <= 19)) {
          traffic = 'Heavy';
          crowd = 'High';
          deltaMins = +12;
        } else if (h >= 12 && h <= 14) {
          traffic = 'Moderate';
          crowd = 'Medium';
          deltaMins = +4;
        } else if (h >= 19 && h <= 21) {
          traffic = 'Light';
          crowd = 'Low';
          deltaMins = -11;
        } else {
          traffic = 'Light';
          crowd = 'Low';
          deltaMins = -5;
        }

        const isCurrentlyActive =
          plannedDeparture.targetDate.getHours() === h &&
          Math.abs(plannedDeparture.targetDate.getMinutes() - m) < 15 &&
          ((!isTomorrowSelected && slotDate.toDateString() === now.toDateString()) ||
            (isTomorrowSelected && slotDate.toDateString() !== now.toDateString()));

        slots.push({
          date: slotDate,
          hour24: h,
          hour12: h12,
          minute: m,
          period,
          timeStr,
          traffic,
          crowd,
          deltaMins,
          isSelected: isCurrentlyActive,
          isBest: h === 19 && m === 30,
        });
      }
    }
    return slots;
  };

  const timelineSlots = generateHourlySlots();

  return (
    <div className="bg-gradient-to-br from-slate-900 via-sky-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl border border-slate-800 space-y-4 relative overflow-hidden">
      <div className="absolute top-0 right-0 -mr-12 -mt-12 w-48 h-48 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold tracking-tight text-white flex items-center gap-1.5">
                <span>ShopWise Time Machine</span>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Interactive Scrolling Timeline
                </span>
              </h3>
            </div>
            <p className="text-xs text-slate-300">
              Scroll continuous time slots to simulate real-time traffic, crowd density, and route ETAs
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-800/90 px-3 py-1.5 rounded-xl border border-slate-700/80 text-xs text-slate-200 font-semibold self-start sm:self-auto shrink-0">
          <span>Active Departure:</span>
          <span className="text-amber-300 font-bold">{plannedDeparture.formattedFull}</span>
        </div>
      </div>

      {/* 1. Quick Presets Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 relative z-10">
        {presets.map((slot) => {
          const isSelected = plannedDeparture.preset === slot.id;
          const isSavings = slot.deltaMins < 0;

          return (
            <button
              key={slot.id}
              onClick={() => setPlannedDeparturePreset(slot.id)}
              className={`p-2.5 rounded-2xl border text-left transition-all relative flex flex-col justify-between ${
                isSelected
                  ? 'bg-gradient-to-b from-sky-500 to-sky-600 text-white border-sky-400 shadow-md shadow-sky-500/30 ring-2 ring-white/50'
                  : 'bg-slate-800/60 hover:bg-slate-800 text-slate-200 border-slate-700/80 hover:border-slate-600'
              }`}
            >
              {slot.isBest && (
                <span className="absolute -top-2 right-2 text-[8px] font-black bg-emerald-500 text-slate-950 px-1.5 py-0.5 rounded-full shadow-xs uppercase tracking-wider">
                  Optimal
                </span>
              )}

              <div>
                <div className="flex items-center justify-between text-xs font-bold mb-0.5">
                  <span className={isSelected ? 'text-white' : 'text-slate-100'}>{slot.label}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-white shrink-0" />}
                </div>
                <div className={`text-[10px] font-mono ${isSelected ? 'text-sky-100' : 'text-slate-400'}`}>
                  {slot.timeStr}
                </div>
              </div>

              <div className="mt-1.5 pt-1.5 border-t border-white/10 flex items-center justify-between text-[10px]">
                <span className={`font-semibold ${
                  slot.traffic === 'Light' ? 'text-emerald-400' : slot.traffic === 'Moderate' ? 'text-amber-300' : 'text-rose-400'
                }`}>
                  {slot.traffic}
                </span>

                <span className={`font-bold ${
                  isSavings ? 'text-emerald-300' : slot.deltaMins === 0 ? 'text-slate-300' : 'text-rose-300'
                }`}>
                  {isSavings ? `${slot.deltaMins}m` : slot.deltaMins === 0 ? 'Base' : `+${slot.deltaMins}m`}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* 2. Continuous Horizontal Scrolling Time Bar */}
      <div className="space-y-2 relative z-10 pt-2 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Calendar size={13} className="text-sky-400" />
              <span>Scroll Continuous Time Wheel:</span>
            </span>
            <div className="flex items-center gap-1 bg-slate-800 p-0.5 rounded-lg border border-slate-700">
              <button
                type="button"
                onClick={() => setSelectedDayTab('today')}
                className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-colors ${
                  selectedDayTab === 'today' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Today
              </button>
              <button
                type="button"
                onClick={() => setSelectedDayTab('tomorrow')}
                className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-colors ${
                  selectedDayTab === 'tomorrow' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Tomorrow
              </button>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => scrollTimeline('left')}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Scroll left"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              type="button"
              onClick={() => scrollTimeline('right')}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Scroll right"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Scroll Container */}
        <div
          ref={timelineRef}
          className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 scrollbar-thin scrollbar-thumb-sky-500/40 scroll-smooth snap-x"
        >
          {timelineSlots.map((slot, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setPlannedDeparturePreset('custom', slot.date)}
              className={`snap-center shrink-0 p-3 rounded-2xl border text-left transition-all min-w-[115px] relative flex flex-col justify-between ${
                slot.isSelected
                  ? 'bg-gradient-to-tr from-sky-500 via-teal-500 to-sky-600 text-white border-white shadow-lg shadow-sky-500/30 ring-2 ring-white/60 scale-102'
                  : 'bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border-slate-700/80 hover:border-slate-500'
              }`}
            >
              {slot.isBest && (
                <span className="absolute -top-2 right-2 text-[8px] font-black bg-amber-400 text-slate-950 px-1.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                  Optimal
                </span>
              )}

              <div>
                <div className="text-xs font-black tracking-tight flex items-center justify-between">
                  <span>{slot.timeStr}</span>
                  {slot.isSelected && <Check size={12} className="text-white" />}
                </div>
                <div className={`text-[10px] mt-0.5 font-medium ${slot.isSelected ? 'text-sky-100' : 'text-slate-400'}`}>
                  {slot.crowd} crowd
                </div>
              </div>

              <div className="mt-2 pt-1.5 border-t border-white/10 flex items-center justify-between text-[10px]">
                <span className={`font-bold ${
                  slot.traffic === 'Light' ? 'text-emerald-400' : slot.traffic === 'Moderate' ? 'text-amber-300' : 'text-rose-400'
                }`}>
                  {slot.traffic}
                </span>

                <span className={`font-bold ${
                  slot.deltaMins < 0 ? 'text-emerald-300' : slot.deltaMins > 0 ? 'text-rose-300' : 'text-slate-300'
                }`}>
                  {slot.deltaMins < 0 ? `${slot.deltaMins}m` : slot.deltaMins > 0 ? `+${slot.deltaMins}m` : '0m'}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Recommendation Banner */}
      <div className="p-3.5 bg-slate-800/90 rounded-2xl border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs relative z-10">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <span className="font-extrabold text-amber-300">ShopWise AI Window Tip: </span>
            <span className="text-slate-200 font-medium">
              Departing at <strong className="text-white">7:30 PM</strong> cuts queue waits by 65% and driving traffic by ~11 mins.
            </span>
          </div>
        </div>
        <button
          onClick={() => {
            const tonight730 = new Date();
            tonight730.setHours(19, 30, 0, 0);
            if (new Date().getHours() >= 20) tonight730.setDate(tonight730.getDate() + 1);
            setPlannedDeparturePreset('custom', tonight730);
          }}
          className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition-colors shrink-0 flex items-center justify-center gap-1 shadow-xs"
        >
          <span>Set to 7:30 PM</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

