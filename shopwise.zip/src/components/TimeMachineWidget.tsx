import React from 'react';
import { useApp } from '../context/AppContext';
import { DeparturePreset } from '../types';
import { Clock, Sparkles, TrendingDown, TrendingUp, Check, ChevronRight } from 'lucide-react';

export const TimeMachineWidget: React.FC = () => {
  const { plannedDeparture, setPlannedDeparturePreset } = useApp();

  const slots: { id: DeparturePreset; label: string; timeStr: string; traffic: string; crowd: string; deltaMins: number; isBest?: boolean }[] = [
    { id: 'now', label: 'Go Now', timeStr: 'Now', traffic: 'Moderate', crowd: 'Busy', deltaMins: 0 },
    { id: 'in_30m', label: 'In 30m', timeStr: '+30 mins', traffic: 'Heavy', crowd: 'Peak', deltaMins: +8 },
    { id: 'in_1h', label: 'In 1h', timeStr: '+1 hour', traffic: 'Light', crowd: 'Moderate', deltaMins: -5 },
    { id: 'this_afternoon', label: 'Afternoon', timeStr: '3:00 PM', traffic: 'Moderate', crowd: 'Moderate', deltaMins: -3 },
    { id: 'this_evening', label: 'Evening', timeStr: '6:30 PM', traffic: 'Light', crowd: 'Low', deltaMins: -11, isBest: true },
    { id: 'tomorrow_morning', label: 'Tomorrow AM', timeStr: '10:00 AM', traffic: 'Light', crowd: 'Very Low', deltaMins: -14 },
  ];

  return (
    <div className="bg-gradient-to-br from-slate-900 via-sky-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl border border-slate-800 space-y-4 relative overflow-hidden">
      <div className="absolute top-0 right-0 -mr-12 -mt-12 w-48 h-48 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold tracking-tight text-white flex items-center gap-1.5">
                <span>ShopWise Time Machine</span>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Predictive ETA
                </span>
              </h3>
            </div>
            <p className="text-xs text-slate-300">
              Select planned departure time to simulate traffic & crowd shifts
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700/60 text-xs text-slate-200 font-semibold self-start sm:self-auto">
          <span>Active:</span>
          <span className="text-amber-300 font-bold">{plannedDeparture.formattedFull}</span>
        </div>
      </div>

      {/* Slots Grid / Timeline */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 relative z-10">
        {slots.map((slot) => {
          const isSelected = plannedDeparture.preset === slot.id;
          const isSavings = slot.deltaMins < 0;

          return (
            <button
              key={slot.id}
              onClick={() => setPlannedDeparturePreset(slot.id)}
              className={`p-3 rounded-2xl border text-left transition-all relative flex flex-col justify-between ${
                isSelected
                  ? 'bg-gradient-to-b from-sky-500 to-sky-600 text-white border-sky-400 shadow-lg shadow-sky-500/30 ring-2 ring-white/50'
                  : 'bg-slate-800/60 hover:bg-slate-800 text-slate-200 border-slate-700/80 hover:border-slate-600'
              }`}
            >
              {slot.isBest && (
                <span className="absolute -top-2 right-2 text-[9px] font-black bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full shadow-xs uppercase tracking-wider">
                  Best Window
                </span>
              )}

              <div>
                <div className="flex items-center justify-between text-xs font-bold mb-1">
                  <span className={isSelected ? 'text-white' : 'text-slate-100'}>{slot.label}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-white shrink-0" />}
                </div>
                <div className={`text-[11px] font-mono ${isSelected ? 'text-sky-100' : 'text-slate-400'}`}>
                  {slot.timeStr}
                </div>
              </div>

              <div className="mt-2 pt-2 border-t border-white/10 space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className={isSelected ? 'text-sky-100' : 'text-slate-400'}>Traffic:</span>
                  <span className={`font-semibold ${
                    slot.traffic === 'Light' ? 'text-emerald-400' : slot.traffic === 'Moderate' ? 'text-amber-300' : 'text-rose-400'
                  }`}>
                    {slot.traffic}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[10px]">
                  <span className={isSelected ? 'text-sky-100' : 'text-slate-400'}>ETA Impact:</span>
                  <span className={`font-bold flex items-center ${
                    isSavings ? 'text-emerald-300' : slot.deltaMins === 0 ? 'text-slate-300' : 'text-rose-300'
                  }`}>
                    {isSavings ? (
                      <><TrendingDown className="w-3 h-3 mr-0.5 inline" /> {Math.abs(slot.deltaMins)}m saved</>
                    ) : slot.deltaMins === 0 ? (
                      'Baseline'
                    ) : (
                      <><TrendingUp className="w-3 h-3 mr-0.5 inline" /> +{slot.deltaMins}m delay</>
                    )}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Go Now or Later Banner */}
      <div className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs relative z-10">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <span className="font-extrabold text-amber-300">ShopWise ETA Recommendation: </span>
            <span className="text-slate-200 font-medium">
              Departing at <strong className="text-white">6:30 PM</strong> reduces journey travel time by ~11 mins and queue waits by 65%.
            </span>
          </div>
        </div>
        <button
          onClick={() => setPlannedDeparturePreset('this_evening')}
          className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition-colors shrink-0 flex items-center justify-center gap-1"
        >
          <span>Use 6:30 PM</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
