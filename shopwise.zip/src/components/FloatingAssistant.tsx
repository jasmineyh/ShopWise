import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bot, X, Send, Sparkles, Loader2 } from 'lucide-react';
import { ChatMessage } from '../types';

export const FloatingAssistant: React.FC = () => {
  const { userProfile, activeTab, setActiveTab } = useApp();
  
  if (activeTab === 'assistant') return null;

  return (
    <button
      onClick={() => setActiveTab('assistant')}
      className="fixed bottom-24 right-4 sm:bottom-6 sm:right-6 z-[90] p-4 bg-sky-600 hover:bg-sky-500 text-white rounded-full shadow-2xl transition-transform hover:scale-110 active:scale-95 animate-bounce-slight"
      aria-label="Open AI Assistant"
    >
      <div className="absolute -top-1 -right-1 w-3 h-3 bg-rose-500 rounded-full border-2 border-white dark:border-slate-900 animate-pulse" />
      <Bot size={28} />
    </button>
  );
};
