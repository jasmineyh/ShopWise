import React from 'react';
import {
  ShieldAlert,
  Car,
  Users,
  Sun,
  CloudRain,
  CloudLightning,
  Wind,
  ParkingCircle,
  Tag,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  FloodRisk,
  TrafficLevel,
  CrowdDensity,
  WeatherStatus,
} from '../types';

interface BadgeProps {
  size?: 'sm' | 'md' | 'lg';
}

export const FloodRiskBadge: React.FC<{ risk: FloodRisk } & BadgeProps> = ({ risk, size = 'md' }) => {
  const styles = {
    Low: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    Medium: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    High: 'bg-rose-50 text-rose-700 border-rose-300 animate-pulse dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800',
  };

  const iconSizes = { sm: 12, md: 14, lg: 16 };
  const textSizes = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs font-semibold px-2.5 py-1',
    lg: 'text-sm font-semibold px-3 py-1.5',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border shadow-2xs transition-all ${styles[risk]} ${textSizes[size]}`}
    >
      <ShieldAlert size={iconSizes[size]} className={risk === 'High' ? 'text-rose-600 dark:text-rose-400' : ''} />
      <span>Flood: {risk}</span>
    </span>
  );
};

export const TrafficBadge: React.FC<{ traffic: TrafficLevel } & BadgeProps> = ({ traffic, size = 'md' }) => {
  const styles = {
    Light: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    Moderate: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    Heavy: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
  };

  const iconSizes = { sm: 12, md: 14, lg: 16 };
  const textSizes = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs font-semibold px-2.5 py-1',
    lg: 'text-sm font-semibold px-3 py-1.5',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border shadow-2xs ${styles[traffic]} ${textSizes[size]}`}
    >
      <Car size={iconSizes[size]} />
      <span>Traffic: {traffic}</span>
    </span>
  );
};

export const CrowdBadge: React.FC<{ crowd: CrowdDensity } & BadgeProps> = ({ crowd, size = 'md' }) => {
  const styles = {
    Low: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    Medium: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    High: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
  };

  const iconSizes = { sm: 12, md: 14, lg: 16 };
  const textSizes = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs font-semibold px-2.5 py-1',
    lg: 'text-sm font-semibold px-3 py-1.5',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border shadow-2xs ${styles[crowd]} ${textSizes[size]}`}
    >
      <Users size={iconSizes[size]} />
      <span>Crowd: {crowd}</span>
    </span>
  );
};

export const WeatherIcon: React.FC<{ status: WeatherStatus; className?: string }> = ({
  status,
  className = 'w-5 h-5',
}) => {
  if (status === 'Clear') {
    return <Sun className={`text-amber-500 ${className}`} />;
  }
  if (status === 'Rain') {
    return <CloudRain className={`text-sky-500 ${className}`} />;
  }
  return <CloudLightning className={`text-indigo-600 dark:text-indigo-400 ${className}`} />;
};

export const ParkingBar: React.FC<{ percent: number }> = ({ percent }) => {
  let color = 'bg-emerald-500';
  let textColor = 'text-emerald-700 dark:text-emerald-400';
  if (percent < 30) {
    color = 'bg-rose-500';
    textColor = 'text-rose-700 dark:text-rose-400';
  } else if (percent < 60) {
    color = 'bg-amber-500';
    textColor = 'text-amber-700 dark:text-amber-400';
  }

  return (
    <div className="flex items-center gap-2 w-full">
      <ParkingCircle className="w-4 h-4 text-slate-500 shrink-0" />
      <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${color}`}
          style={{ width: `${percent}%` }}
        />
      </div>
      <span className={`text-xs font-semibold font-mono ${textColor} shrink-0`}>
        {percent}% Free
      </span>
    </div>
  );
};

export const PriceIndexDisplay: React.FC<{ index: number }> = ({ index }) => {
  return (
    <span className="font-mono text-xs font-semibold text-slate-600 dark:text-slate-300" title={`Average Price Index: ${index}/5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className={i < index ? 'text-slate-900 dark:text-slate-100 font-bold' : 'text-slate-300 dark:text-slate-700'}>
          $
        </span>
      ))}
    </span>
  );
};
