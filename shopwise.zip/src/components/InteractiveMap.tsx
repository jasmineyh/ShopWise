import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useApp } from '../context/AppContext';
import { Store, ConditionSnapshot } from '../types';
import { Navigation, Car, Bus, Footprints, ExternalLink, RefreshCw, MapPin } from 'lucide-react';
import { computeRoute } from '../services/mapsService';
import { calculateSafetyScore } from '../utils/recommendationEngine';

interface InteractiveMapProps {
  stores: Store[];
  selectedStoreId?: string | null;
  onSelectStore?: (storeId: string) => void;
  height?: string;
  recommendedStoreId?: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  stores,
  selectedStoreId,
  onSelectStore,
  height = '500px',
  recommendedStoreId,
}) => {
  const {
    activeLocation,
    snapshots,
    navigateToStoreDetails,
    decisionPriority = 'balanced',
    recommendation,
    toggleCompareStore,
    addToast,
  } = useApp();

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const routeLayerRef = useRef<L.Polyline | null>(null);
  const markersRef = useRef<Record<string, L.Marker>>({});

  const [activeMarkerStore, setActiveMarkerStore] = useState<Store | null>(null);
  const [routeStore, setRouteStore] = useState<Store | null>(null);
  const [travelMode, setTravelMode] = useState<'DRIVE' | 'TRANSIT' | 'WALK'>('DRIVE');
  const [routeDetails, setRouteDetails] = useState<{ distanceKm: number; durationMinutes: number } | null>(null);
  const [isComputingRoute, setIsComputingRoute] = useState(false);

  // Sync selectedStoreId prop
  useEffect(() => {
    if (selectedStoreId) {
      const match = stores.find((s) => s.id === selectedStoreId);
      if (match) {
        setActiveMarkerStore(match);
        setRouteStore(match);
      }
    }
  }, [selectedStoreId, stores]);

  // Handle route calculation
  useEffect(() => {
    if (!routeStore) {
      setRouteDetails(null);
      if (routeLayerRef.current && mapInstanceRef.current) {
        mapInstanceRef.current.removeLayer(routeLayerRef.current);
        routeLayerRef.current = null;
      }
      return;
    }

    const getRoute = async () => {
      setIsComputingRoute(true);
      const res = await computeRoute(
        { latitude: activeLocation.latitude, longitude: activeLocation.longitude },
        { latitude: routeStore.latitude, longitude: routeStore.longitude }
      );
      setRouteDetails(res);
      setIsComputingRoute(false);

      // Draw Polyline in Leaflet
      if (mapInstanceRef.current) {
        if (routeLayerRef.current) {
          mapInstanceRef.current.removeLayer(routeLayerRef.current);
        }

        const latLngs: L.LatLngExpression[] = [
          [activeLocation.latitude, activeLocation.longitude],
          [routeStore.latitude, routeStore.longitude],
        ];

        const polyline = L.polyline(latLngs, {
          color: '#0284c7',
          weight: 5,
          opacity: 0.85,
          dashArray: travelMode === 'WALK' ? '8, 8' : undefined,
        }).addTo(mapInstanceRef.current);

        routeLayerRef.current = polyline;

        const bounds = L.latLngBounds(latLngs);
        mapInstanceRef.current.fitBounds(bounds, { padding: [50, 50] });
      }
    };

    getRoute();
  }, [routeStore, activeLocation, travelMode]);

  // Main Leaflet Map Initialization & Markers Update
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize Map if not existing
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [activeLocation.latitude, activeLocation.longitude],
        zoom: 13,
        zoomControl: true,
        scrollWheelZoom: true,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Invalidate size to ensure 100% canvas tile coverage without gray boxes
    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    // Clear previous markers
    Object.values(markersRef.current).forEach((m) => map.removeLayer(m));
    markersRef.current = {};

    const bounds: L.LatLngExpression[] = [];

    // User Active Location Marker
    const userIcon = L.divIcon({
      className: 'custom-user-pin',
      html: `
        <div style="position: relative; width: 36px; height: 36px;">
          <div style="position: absolute; inset: -4px; border-radius: 50%; background: rgba(2, 132, 199, 0.4); animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
          <div style="position: relative; width: 36px; height: 36px; border-radius: 50%; background: #0284c7; border: 3px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
            📍
          </div>
        </div>
      `,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    });

    const userMarker = L.marker([activeLocation.latitude, activeLocation.longitude], { icon: userIcon }).addTo(map);
    userMarker.bindPopup(`<b>Your Location</b><br/>${activeLocation.displayName}`);
    bounds.push([activeLocation.latitude, activeLocation.longitude]);

    // Store Markers
    stores.forEach((store) => {
      const snap = snapshots[store.id] || {
        store_id: store.id,
        weather_status: 'Clear',
        flood_risk: 'Low',
        traffic_level: 'Light',
        crowd_density: 'Low',
        air_quality_index: 40,
        parking_availability_percent: 70,
        active_promotions: [],
        last_updated: new Date().toISOString(),
      };

      const { score, advantages } = calculateSafetyScore(store, snap, decisionPriority);
      const isRecommended = store.id === (recommendedStoreId || recommendation?.recommended_store_id);
      const isSelected = activeMarkerStore?.id === store.id;

      const badgeColor = score >= 85 ? '#10b981' : score >= 75 ? '#0284c7' : score >= 65 ? '#f59e0b' : '#ef4444';
      const borderColor = isRecommended ? '#f59e0b' : isSelected ? '#38bdf8' : '#ffffff';

      const storeIcon = L.divIcon({
        className: 'custom-store-pin',
        html: `
          <div style="position: relative; display: flex; flex-direction: column; align-items: center; cursor: pointer; transition: transform 0.2s;">
            <div style="background: #0f172a; color: white; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 8px; border: 1px solid ${borderColor}; box-shadow: 0 2px 6px rgba(0,0,0,0.3); white-space: nowrap; margin-bottom: 2px; display: flex; align-items: center; gap: 3px;">
              <span>${store.name}</span>
              <span style="color: ${badgeColor}; font-weight: 900;">${score}</span>
              ${isRecommended ? '<span style="color: #f59e0b;">★</span>' : ''}
            </div>
            <div style="width: ${isRecommended ? '38px' : '32px'}; height: ${isRecommended ? '38px' : '32px'}; border-radius: 50%; background: ${badgeColor}; border: 3px solid ${borderColor}; box-shadow: 0 4px 12px rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 12px;">
              🏬
            </div>
          </div>
        `,
        iconSize: [120, 60],
        iconAnchor: [60, 55],
      });

      const marker = L.marker([store.latitude, store.longitude], { icon: storeIcon }).addTo(map);

      // Create Interactive Popup Element
      const popupContent = document.createElement('div');
      popupContent.style.minWidth = '220px';
      popupContent.style.fontFamily = 'system-ui, sans-serif';

      popupContent.innerHTML = `
        <div style="padding: 4px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <span style="font-size: 10px; font-weight: 900; text-transform: uppercase; padding: 2px 8px; border-radius: 9999px; background: #0f172a; color: white;">
              ${store.category}
            </span>
            <span style="font-size: 11px; font-weight: 900; padding: 2px 8px; border-radius: 9999px; background: #e0f2fe; color: #075985;">
              SHOPWISE ${score} ${isRecommended ? '★ BEST' : ''}
            </span>
          </div>

          <h4 style="font-weight: 800; font-size: 14px; color: #0f172a; margin: 4px 0 2px 0; line-height: 1.2;">${store.name}</h4>
          <p style="font-size: 11px; color: #64748b; margin: 0 0 8px 0;">${store.address}</p>

          <div style="display: flex; gap: 8px; font-size: 11px; font-weight: 700; color: #334155; background: #f1f5f9; padding: 6px 8px; border-radius: 8px; margin-bottom: 8px;">
            <span>🚗 ${store.travel_time_minutes} min</span>
            <span>•</span>
            <span>📍 ${store.distance_km} km</span>
            <span>•</span>
            <span style="color: #047857; font-weight: 800;">Open</span>
          </div>

          <div style="padding: 6px 8px; background: #f0f9ff; border-radius: 8px; border: 1px solid #bae6fd; font-size: 11px; color: #0369a1; margin-bottom: 10px;">
            <strong>Why here?</strong> ${advantages[0] || 'Optimized traffic & checkout queue'}
          </div>

          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px;">
            <button id="pop-details-${store.id}" style="padding: 6px 2px; background: #0f172a; color: white; font-size: 11px; font-weight: 800; border-radius: 6px; border: none; cursor: pointer;">Details</button>
            <button id="pop-compare-${store.id}" style="padding: 6px 2px; background: #f1f5f9; color: #0f172a; font-size: 11px; font-weight: 800; border-radius: 6px; border: 1px solid #cbd5e1; cursor: pointer;">Compare</button>
            <button id="pop-route-${store.id}" style="padding: 6px 2px; background: #0284c7; color: white; font-size: 11px; font-weight: 800; border-radius: 6px; border: none; cursor: pointer;">Route</button>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);

      marker.on('popupopen', () => {
        setTimeout(() => {
          const btnDetails = document.getElementById(`pop-details-${store.id}`);
          const btnCompare = document.getElementById(`pop-compare-${store.id}`);
          const btnRoute = document.getElementById(`pop-route-${store.id}`);

          if (btnDetails) {
            btnDetails.onclick = () => {
              if (navigateToStoreDetails) navigateToStoreDetails(store.id);
            };
          }
          if (btnCompare) {
            btnCompare.onclick = () => {
              toggleCompareStore(store.id);
              addToast(`Added ${store.name} to comparison`, 'info');
            };
          }
          if (btnRoute) {
            btnRoute.onclick = () => {
              setRouteStore(store);
              setActiveMarkerStore(store);
              if (onSelectStore) onSelectStore(store.id);
            };
          }
        }, 50);
      });

      marker.on('click', () => {
        setActiveMarkerStore(store);
        if (onSelectStore) onSelectStore(store.id);
      });

      markersRef.current[store.id] = marker;
      bounds.push([store.latitude, store.longitude]);
    });

    if (bounds.length > 0 && !routeStore) {
      map.fitBounds(bounds as L.LatLngBoundsExpression, { padding: [40, 40] });
    }
  }, [stores, snapshots, activeLocation, decisionPriority, recommendedStoreId, recommendation]);

  // Handle map center panning on activeMarkerStore change
  useEffect(() => {
    if (mapInstanceRef.current && activeMarkerStore) {
      mapInstanceRef.current.flyTo([activeMarkerStore.latitude, activeMarkerStore.longitude], 14, {
        duration: 0.8,
      });
      const marker = markersRef.current[activeMarkerStore.id];
      if (marker && !marker.isPopupOpen()) {
        marker.openPopup();
      }
    }
  }, [activeMarkerStore]);

  const googleMapsUrl = routeStore
    ? `https://www.google.com/maps/dir/?api=1&origin=${activeLocation.latitude},${activeLocation.longitude}&destination=${routeStore.latitude},${routeStore.longitude}&travelmode=${travelMode.toLowerCase()}`
    : activeMarkerStore
    ? `https://www.google.com/maps/dir/?api=1&origin=${activeLocation.latitude},${activeLocation.longitude}&destination=${activeMarkerStore.latitude},${activeMarkerStore.longitude}`
    : `https://www.google.com/maps/search/?api=1&query=${activeLocation.latitude},${activeLocation.longitude}`;

  return (
    <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md bg-slate-900 flex flex-col w-full" style={{ height }}>
      {/* Route Control Header */}
      {routeStore && (
        <div className="p-3 bg-slate-900 border-b border-slate-800 text-white flex flex-wrap items-center justify-between gap-3 z-[400] animate-fadeIn">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <Navigation className="w-4 h-4 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-100 truncate">
                Route to {routeStore.name}
              </div>
              <div className="text-[11px] text-slate-400">
                {isComputingRoute ? (
                  'Calculating route...'
                ) : (
                  <>
                    <span className="text-sky-400 font-bold">{routeDetails?.distanceKm || routeStore.distance_km} km</span> •{' '}
                    <span className="text-emerald-400 font-bold">{routeDetails?.durationMinutes || routeStore.travel_time_minutes} mins</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Travel Mode Selector */}
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setTravelMode('DRIVE')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                travelMode === 'DRIVE' ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Driving"
            >
              <Car className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTravelMode('TRANSIT')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                travelMode === 'TRANSIT' ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Public Transit"
            >
              <Bus className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTravelMode('WALK')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                travelMode === 'WALK' ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Walking"
            >
              <Footprints className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              Open Google Maps <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => {
                setRouteStore(null);
                if (routeLayerRef.current && mapInstanceRef.current) {
                  mapInstanceRef.current.removeLayer(routeLayerRef.current);
                  routeLayerRef.current = null;
                }
              }}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-xs font-bold"
            >
              Clear Route
            </button>
          </div>
        </div>
      )}

      {/* Leaflet Map Canvas Container */}
      <div className="flex-1 w-full h-full relative z-0">
        <div ref={mapContainerRef} className="w-full h-full" />
      </div>
    </div>
  );
};
