import React, { useState, useEffect } from 'react';
import { APIProvider, Map, Marker, InfoWindow, useMap } from '@vis.gl/react-google-maps';
import { useApp } from '../context/AppContext';
import { Store, ActiveLocation } from '../types';
import { MapPin, Navigation, Car, Bus, Footprints, ExternalLink, AlertTriangle, ArrowRight, ShieldCheck, Star, Columns3, Calendar } from 'lucide-react';
import { computeRoute } from '../services/mapsService';
import { calculateSafetyScore } from '../utils/recommendationEngine';

interface InteractiveMapProps {
  stores: Store[];
  selectedStoreId?: string | null;
  onSelectStore?: (storeId: string) => void;
  height?: string;
  recommendedStoreId?: string;
}

const createMarkerIcon = (score: number, isRecommended: boolean) => {
  const color = score >= 85 ? '#10b981' : score >= 75 ? '#0284c7' : score >= 65 ? '#f59e0b' : '#ef4444';
  const stroke = isRecommended ? '#f59e0b' : '#ffffff';
  const width = isRecommended ? 42 : 36;
  const height = isRecommended ? 50 : 44;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 36 44">
    <path d="M18 0 C8.1 0 0 8.1 0 18 C0 31.5 18 44 18 44 C18 44 36 31.5 36 18 C36 8.1 27.9 0 18 0 Z" fill="${color}" stroke="${stroke}" stroke-width="${isRecommended ? 3.5 : 2}"/>
    <circle cx="18" cy="18" r="12" fill="#ffffff"/>
    <text x="18" y="22" font-size="11" font-weight="900" font-family="system-ui, sans-serif" fill="${color}" text-anchor="middle">${score}</text>
  </svg>`;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
};

const RoutePolyline: React.FC<{ origin: ActiveLocation; destination: Store; travelMode: 'DRIVE' | 'TRANSIT' | 'WALK' }> = ({
  origin,
  destination,
  travelMode
}) => {
  const map = useMap();

  useEffect(() => {
    if (!map || typeof google === 'undefined' || !google.maps || typeof google.maps.DirectionsService !== 'function') return;

    const directionsService = new google.maps.DirectionsService();
    const directionsRenderer = new google.maps.DirectionsRenderer({
      map,
      suppressMarkers: true,
      polylineOptions: {
        strokeColor: '#0284c7',
        strokeWeight: 5,
        strokeOpacity: 0.8
      }
    });

    const modeMap = {
      DRIVE: google.maps.TravelMode.DRIVING,
      TRANSIT: google.maps.TravelMode.TRANSIT,
      WALK: google.maps.TravelMode.WALKING
    };

    directionsService.route(
      {
        origin: { lat: origin.latitude, lng: origin.longitude },
        destination: { lat: destination.latitude, lng: destination.longitude },
        travelMode: modeMap[travelMode]
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          directionsRenderer.setDirections(result);
        }
      }
    );

    return () => {
      directionsRenderer.setMap(null);
    };
  }, [map, origin, destination, travelMode]);

  return null;
};

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  stores,
  selectedStoreId,
  onSelectStore,
  height = '500px',
  recommendedStoreId,
}) => {
  const {
    activeLocation,
    snapshots,
    navigateToStoreDetails,
    decisionPriority = 'balanced',
    recommendation,
    toggleCompareStore,
    addToast,
    setActiveTab,
  } = useApp();
  const [activeMarkerStore, setActiveMarkerStore] = useState<Store | null>(null);
  const [routeStore, setRouteStore] = useState<Store | null>(null);
  const [travelMode, setTravelMode] = useState<'DRIVE' | 'TRANSIT' | 'WALK'>('DRIVE');
  const [routeDetails, setRouteDetails] = useState<{ distanceKm: number; durationMinutes: number } | null>(null);
  const [isComputingRoute, setIsComputingRoute] = useState(false);

  const apiKey = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';

  // Handle selectedStoreId prop
  useEffect(() => {
    if (selectedStoreId) {
      const match = stores.find((s) => s.id === selectedStoreId);
      if (match) setActiveMarkerStore(match);
    }
  }, [selectedStoreId, stores]);

  // Handle route computing
  useEffect(() => {
    if (!routeStore) {
      setRouteDetails(null);
      return;
    }

    const getRoute = async () => {
      setIsComputingRoute(true);
      const res = await computeRoute(
        { latitude: activeLocation.latitude, longitude: activeLocation.longitude },
        { latitude: routeStore.latitude, longitude: routeStore.longitude }
      );
      setRouteDetails(res);
      setIsComputingRoute(false);
    };

    getRoute();
  }, [routeStore, activeLocation, travelMode]);

  const mapCenter = routeStore
    ? { lat: (activeLocation.latitude + routeStore.latitude) / 2, lng: (activeLocation.longitude + routeStore.longitude) / 2 }
    : { lat: activeLocation.latitude, lng: activeLocation.longitude };

  const googleMapsUrl = routeStore
    ? `https://www.google.com/maps/dir/?api=1&origin=${activeLocation.latitude},${activeLocation.longitude}&destination=${routeStore.latitude},${routeStore.longitude}&travelmode=${travelMode.toLowerCase()}`
    : `https://www.google.com/maps/search/?api=1&query=${activeLocation.latitude},${activeLocation.longitude}`;

  return (
    <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md bg-slate-900 flex flex-col" style={{ height }}>
      {/* Route Control Bar */}
      {routeStore && (
        <div className="p-3 bg-slate-900 border-b border-slate-800 text-white flex flex-wrap items-center justify-between gap-3 z-10 animate-fadeIn">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <Navigation className="w-4 h-4 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-100 truncate">
                Route to {routeStore.name}
              </div>
              <div className="text-[11px] text-slate-400">
                {isComputingRoute ? (
                  'Calculating route...'
                ) : (
                  <>
                    <span className="text-sky-400 font-bold">{routeDetails?.distanceKm || routeStore.distance_km} km</span> •{' '}
                    <span className="text-emerald-400 font-bold">{routeDetails?.durationMinutes || routeStore.travel_time_minutes} mins</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Travel Mode Toggle */}
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setTravelMode('DRIVE')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                travelMode === 'DRIVE' ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Driving"
            >
              <Car className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTravelMode('TRANSIT')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                travelMode === 'TRANSIT' ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Public Transit"
            >
              <Bus className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTravelMode('WALK')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                travelMode === 'WALK' ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
              title="Walking"
            >
              <Footprints className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              Open in Google Maps <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setRouteStore(null)}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
            >
              Clear
            </button>
          </div>
        </div>
      )}

      {/* Map Canvas */}
      <div className="flex-1 w-full h-full relative">
        {apiKey ? (
          <APIProvider apiKey={apiKey}>
            <Map
              defaultCenter={mapCenter}
              defaultZoom={13}
              gestureHandling="greedy"
              disableDefaultUI={false}
              className="w-full h-full"
              internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            >
              {/* User Active Location Marker */}
              <Marker
                position={{ lat: activeLocation.latitude, lng: activeLocation.longitude }}
                title={`Active Location: ${activeLocation.displayName}`}
              />

              {/* Supermarket Store Markers */}
              {stores.map((store) => {
                const snap = snapshots[store.id] || {
                  store_id: store.id,
                  weather_status: 'Clear',
                  flood_risk: 'Low',
                  traffic_level: 'Light',
                  crowd_density: 'Low',
                  air_quality_index: 40,
                  parking_availability_percent: 70,
                  active_promotions: [],
                  last_updated: new Date().toISOString(),
                };
                const { score } = calculateSafetyScore(store, snap, decisionPriority);
                const isRecommended = store.id === (recommendedStoreId || recommendation?.recommended_store_id);

                return (
                  <Marker
                    key={store.id}
                    position={{ lat: store.latitude, lng: store.longitude }}
                    title={`${store.name} - ShopWise Score: ${score}`}
                    icon={{
                      url: createMarkerIcon(score, isRecommended),
                      scaledSize: typeof google !== 'undefined' && google?.maps && typeof google.maps.Size === 'function' ? new google.maps.Size(isRecommended ? 42 : 36, isRecommended ? 50 : 44) : undefined,
                    }}
                    onClick={() => {
                      setActiveMarkerStore(store);
                      if (onSelectStore) onSelectStore(store.id);
                    }}
                  />
                );
              })}

              {/* Route Polyline when routeStore is active */}
              {routeStore && (
                <RoutePolyline
                  origin={activeLocation}
                  destination={routeStore}
                  travelMode={travelMode}
                />
              )}

              {/* Store Preview Card Info Window */}
              {activeMarkerStore && (() => {
                const snap = snapshots[activeMarkerStore.id] || {
                  store_id: activeMarkerStore.id,
                  weather_status: 'Clear',
                  flood_risk: 'Low',
                  traffic_level: 'Light',
                  crowd_density: 'Low',
                  air_quality_index: 40,
                  parking_availability_percent: 70,
                  active_promotions: [],
                  last_updated: new Date().toISOString(),
                };
                const { score, advantages } = calculateSafetyScore(activeMarkerStore, snap, decisionPriority);
                const isRecommended = activeMarkerStore.id === (recommendedStoreId || recommendation?.recommended_store_id);

                return (
                  <InfoWindow
                    position={{ lat: activeMarkerStore.latitude, lng: activeMarkerStore.longitude }}
                    onCloseClick={() => setActiveMarkerStore(null)}
                  >
                    <div className="p-2 text-slate-900 max-w-xs font-sans space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-900 text-white">
                          {activeMarkerStore.category}
                        </span>
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 text-xs font-black">
                          <ShieldCheck size={13} className="text-sky-600" />
                          <span>SHOPWISE {score}</span>
                          {isRecommended && <span className="text-amber-500 font-bold ml-0.5">★ BEST</span>}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 leading-tight">
                          {activeMarkerStore.name}
                        </h4>
                        <p className="text-[11px] text-slate-500 truncate">
                          {activeMarkerStore.address}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-slate-100 p-2 rounded-xl">
                        <span>{activeMarkerStore.travel_time_minutes} min drive</span>
                        <span>•</span>
                        <span>{activeMarkerStore.distance_km} km</span>
                        <span>•</span>
                        <span className="text-emerald-700 font-extrabold">Open until 10 PM</span>
                      </div>

                      <div className="p-2 bg-sky-50 rounded-xl border border-sky-100 text-[11px] text-sky-900 font-medium">
                        <span className="font-extrabold text-sky-950 block">Why here?</span>
                        <span>{advantages[0] || 'Optimized traffic & quick checkout queue'}</span>
                      </div>

                      <div className="grid grid-cols-3 gap-1 pt-1">
                        <button
                          onClick={() => {
                            if (navigateToStoreDetails) navigateToStoreDetails(activeMarkerStore.id);
                          }}
                          className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-bold rounded-lg transition-colors text-center"
                        >
                          Details
                        </button>
                        <button
                          onClick={() => {
                            toggleCompareStore(activeMarkerStore.id);
                            addToast(`Added ${activeMarkerStore.name} to comparison`, 'info');
                          }}
                          className="py-1.5 px-2 border border-slate-300 hover:bg-slate-100 text-slate-800 text-[11px] font-bold rounded-lg transition-colors text-center"
                        >
                          Compare
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab('plan');
                            sessionStorage.setItem('shopwise_plan_subtab', 'route');
                            window.dispatchEvent(new CustomEvent('shopwise_navigate_plan_subtab', { detail: 'route' }));
                          }}
                          className="py-1.5 px-2 bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold rounded-lg transition-colors text-center"
                        >
                          Plan
                        </button>
                      </div>
                    </div>
                  </InfoWindow>
                );
              })()}
            </Map>
          </APIProvider>
        ) : (
          /* Fallback visual map overlay if API key is initializing */
          <div className="w-full h-full bg-slate-900 relative flex flex-col justify-between p-4">
            <div className="p-3 bg-slate-800/90 border border-slate-700 rounded-xl text-white text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-sky-400" />
                <span>
                  Showing <strong>{stores.length} supermarkets</strong> near {activeLocation.displayName}
                </span>
              </div>
              <span className="text-[10px] bg-sky-500/20 text-sky-300 font-bold px-2 py-0.5 rounded-full">
                Interactive Map
              </span>
            </div>

            {/* Interactive Pins Canvas Overlay */}
            <div className="flex-1 relative my-4 rounded-xl border border-slate-800 bg-slate-950/60 overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />

              {/* User Pin */}
              <div
                className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20 cursor-pointer"
                style={{ top: '50%', left: '50%' }}
              >
                <div className="w-6 h-6 rounded-full bg-sky-500/30 animate-ping absolute inset-0" />
                <div className="w-8 h-8 rounded-full bg-sky-600 border-2 border-white text-white flex items-center justify-center shadow-lg">
                  <MapPin className="w-4 h-4" />
                </div>
              </div>

              {/* Store Pins */}
              {stores.map((s, i) => {
                const top = `${25 + (i * 18) % 60}%`;
                const left = `${15 + (i * 22) % 70}%`;
                const snap = snapshots[s.id];

                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      setActiveMarkerStore(s);
                      setRouteStore(s);
                    }}
                    style={{ top, left }}
                    className="absolute transform -translate-x-1/2 -translate-y-full z-10 group hover:z-30 transition-all"
                  >
                    <div className="px-2 py-1 bg-slate-900 border border-slate-700 text-slate-100 rounded-lg text-[10px] font-bold shadow-md mb-1 whitespace-nowrap opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all flex items-center gap-1">
                      <span>{s.name}</span>
                      <span className="text-sky-400">({s.distance_km}km)</span>
                    </div>
                    <div className="w-7 h-7 rounded-full bg-slate-900 border-2 border-sky-500 text-sky-400 flex items-center justify-center shadow-md group-hover:bg-sky-600 group-hover:text-white transition-colors">
                      <MapPin className="w-3.5 h-3.5" />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Store Footer Details */}
            {activeMarkerStore && (
              <div className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-white flex items-center justify-between gap-3 animate-fadeIn">
                <div>
                  <div className="font-bold text-sm text-sky-400">{activeMarkerStore.name}</div>
                  <div className="text-xs text-slate-300">
                    {activeMarkerStore.distance_km} km away • ~{activeMarkerStore.travel_time_minutes} min drive
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => navigateToStoreDetails(activeMarkerStore.id)}
                    className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold"
                  >
                    View Details
                  </button>
                  <a
                    href={googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    Maps <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
