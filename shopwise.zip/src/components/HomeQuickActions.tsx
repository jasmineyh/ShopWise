import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckSquare, Scale, Route, Clock, ArrowRight } from 'lucide-react';

interface HomeQuickActionsProps {
  onOpenBestTimeModal?: () => void;
}

export const HomeQuickActions: React.FC<HomeQuickActionsProps> = ({ onOpenBestTimeModal }) => {
  const { setActiveTab } = useApp();

  const handleNavigatePlanSubtab = (subtab: 'list' | 'compare' | 'route') => {
    setActiveTab('plan');
    sessionStorage.setItem('shopwise_plan_subtab', subtab);
    window.dispatchEvent(new CustomEvent('shopwise_navigate_plan_subtab', { detail: subtab }));
  };

  const actions = [
    {
      id: 'list',
      title: 'Build Shopping List',
      subtitle: 'Smart list with AI suggestions',
      icon: <CheckSquare className="w-5 h-5 text-sky-600 dark:text-sky-400" />,
      bg: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200/80 dark:border-sky-900/40',
      action: () => handleNavigatePlanSubtab('list'),
    },
    {
      id: 'compare',
      title: 'Compare Stores',
      subtitle: 'Multi-store side-by-side analysis',
      icon: <Scale className="w-5 h-5 text-teal-600 dark:text-teal-400" />,
      bg: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200/80 dark:border-teal-900/40',
      action: () => handleNavigatePlanSubtab('compare'),
    },
    {
      id: 'route',
      title: 'Optimize Route',
      subtitle: 'Multi-stop traffic routing',
      icon: <Route className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />,
      bg: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200/80 dark:border-indigo-900/40',
      action: () => handleNavigatePlanSubtab('route'),
    },
    {
      id: 'time',
      title: 'Find Best Time',
      subtitle: 'Traffic & crowd forecasts',
      icon: <Clock className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200/80 dark:border-amber-900/40',
      action: () => {
        if (onOpenBestTimeModal) onOpenBestTimeModal();
      },
    },
  ];

  return (
    <div className="space-y-2">
      <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">
        Plan Your Shopping
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {actions.map((act) => (
          <button
            key={act.id}
            onClick={act.action}
            className={`p-4 rounded-2xl border text-left transition-all hover:scale-[1.02] active:scale-[0.98] flex flex-col justify-between group ${act.bg}`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-800 shadow-xs group-hover:scale-110 transition-transform">
                {act.icon}
              </div>
              <ArrowRight size={14} className="text-slate-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <div>
              <div className="font-extrabold text-sm text-slate-900 dark:text-slate-100">{act.title}</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{act.subtitle}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
