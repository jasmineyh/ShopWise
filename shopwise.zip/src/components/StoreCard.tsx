import React from 'react';
import { MapPin, Clock, Tag, ExternalLink, Check, Sparkles } from 'lucide-react';
import { Store, ConditionSnapshot } from '../types';
import {
  FloodRiskBadge,
  TrafficBadge,
  CrowdBadge,
  WeatherIcon,
  ParkingBar,
  PriceIndexDisplay,
} from './ConditionBadges';
import { calculateSafetyScore } from '../utils/recommendationEngine';

interface StoreCardProps {
  store: Store;
  snapshot?: ConditionSnapshot;
  isCompared?: boolean;
  onToggleCompare?: () => void;
  onViewDetails: () => void;
  isRecommended?: boolean;
  showCompare?: boolean;
}

export const StoreCard: React.FC<StoreCardProps> = ({
  store,
  snapshot,
  isCompared = false,
  onToggleCompare,
  onViewDetails,
  isRecommended = false,
  showCompare = true,
}) => {
  const defaultSnap: ConditionSnapshot = {
    store_id: store.id,
    weather_status: 'Clear',
    flood_risk: 'Low',
    traffic_level: 'Light',
    crowd_density: 'Low',
    air_quality_index: 40,
    parking_availability_percent: 75,
    active_promotions: [],
    last_updated: new Date().toISOString(),
  };

  const snap = snapshot || defaultSnap;
  const { score } = calculateSafetyScore(store, snap);

  let scoreColor = 'bg-emerald-600 text-white';
  if (score < 55) {
    scoreColor = 'bg-rose-600 text-white';
  } else if (score < 75) {
    scoreColor = 'bg-amber-500 text-white';
  }

  return (
    <div
      className={`group relative bg-white dark:bg-slate-900 border rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 flex flex-col ${
        isRecommended
          ? 'border-sky-500 ring-2 ring-sky-500/20'
          : isCompared
          ? 'border-teal-500 bg-teal-50/20 dark:bg-teal-950/10'
          : 'border-slate-200 dark:border-slate-800'
      }`}
    >
      {/* Image Header */}
      <div className="relative h-44 w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img
          src={store.image}
          alt={store.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-slate-950/20 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          <span className="bg-slate-900/80 backdrop-blur-md text-white text-xs font-medium px-2.5 py-1 rounded-full border border-white/20">
            {store.category}
          </span>
          <div className="flex items-center gap-2">
            <span className="bg-slate-900/80 backdrop-blur-md text-slate-200 text-xs font-semibold px-2.5 py-1 rounded-full border border-white/20 flex items-center gap-1">
              <MapPin size={12} className="text-sky-400" />
              {store.distance_km} km
            </span>
          </div>
        </div>

        {/* Bottom Overlay: Score & Weather */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <WeatherIcon status={snap.weather_status} className="w-5 h-5 drop-shadow-sm" />
            <span className="text-xs font-medium text-slate-200">{snap.weather_status}</span>
          </div>

          <div
            className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono tracking-tight shadow-sm flex items-center gap-1 ${scoreColor}`}
            title="Safety & Convenience Score out of 100"
          >
            <Sparkles size={12} />
            <span>{score}/100</span>
          </div>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base line-clamp-1 group-hover:text-sky-600 transition-colors">
              {store.name}
            </h3>
            <PriceIndexDisplay index={store.average_price_index} />
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 flex items-center gap-1 mb-3">
            <MapPin size={12} className="shrink-0 text-slate-400" />
            <span>{store.address}</span>
          </p>

          {/* Condition Snapshots Row */}
          <div className="flex flex-wrap items-center gap-1.5 mb-3">
            <FloodRiskBadge risk={snap.flood_risk} size="sm" />
            <TrafficBadge traffic={snap.traffic_level} size="sm" />
            <CrowdBadge crowd={snap.crowd_density} size="sm" />
          </div>

          {/* Parking Bar */}
          <div className="mb-3">
            <ParkingBar percent={snap.parking_availability_percent} />
          </div>

          {/* Active Promotions */}
          {snap.active_promotions.length > 0 && (
            <div className="bg-sky-50 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900/40 rounded-lg p-2 flex items-start gap-2 text-xs text-sky-800 dark:text-sky-300">
              <Tag size={14} className="shrink-0 text-sky-600 dark:text-sky-400 mt-0.5" />
              <span className="line-clamp-1 font-medium">
                {snap.active_promotions[0]}
                {snap.active_promotions.length > 1 && (
                  <span className="text-sky-600 dark:text-sky-400 font-semibold ml-1">
                    (+{snap.active_promotions.length - 1} more)
                  </span>
                )}
              </span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
          {/* Compare Checkbox */}
          {showCompare && onToggleCompare ? (
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isCompared}
                onChange={onToggleCompare}
                className="sr-only"
              />
              <div
                className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${
                  isCompared
                    ? 'bg-teal-600 border-teal-600 text-white'
                    : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800'
                }`}
              >
                {isCompared && <Check size={12} strokeWidth={3} />}
              </div>
              <span>Compare</span>
            </label>
          ) : (
            <div />
          )}

          {/* View Details Button */}
          <button
            onClick={onViewDetails}
            className="inline-flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-sky-600 text-white dark:bg-slate-800 dark:hover:bg-sky-600 transition-colors shadow-2xs"
          >
            <span>View Details</span>
            <ExternalLink size={12} />
          </button>
        </div>
      </div>
    </div>
  );
};
