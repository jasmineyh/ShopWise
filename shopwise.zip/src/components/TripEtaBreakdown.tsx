import React from 'react';
import { useApp } from '../context/AppContext';
import { Clock, Car, ParkingSquare, ShoppingBag, CreditCard, Home, ShieldCheck } from 'lucide-react';

export const TripEtaBreakdown: React.FC = () => {
  const { recommendation, stores, plannedDeparture } = useApp();

  const store = stores.find((s) => s.id === recommendation?.recommended_store_id) || stores[0];
  if (!store) return null;

  const driveMins = store.travel_time_minutes || Math.round(store.distance_km * 3) || 12;
  const parkingMins = 5; // Estimated
  const shoppingMins = 24; // Estimated
  const checkoutMins = 7; // Estimated
  const returnDriveMins = Math.round(driveMins * 1.1); // Return traffic factor

  const totalMinutes = driveMins + parkingMins + shoppingMins + checkoutMins + returnDriveMins;

  // Calculate return time string
  const departureDate = new Date(plannedDeparture.timestamp);
  const returnDate = new Date(departureDate.getTime() + totalMinutes * 60 * 1000);
  const returnTimeString = returnDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const steps = [
    { icon: <Car className="w-4 h-4 text-sky-500" />, label: 'Drive There', duration: `${driveMins} mins`, type: 'Live Route' },
    { icon: <ParkingSquare className="w-4 h-4 text-indigo-500" />, label: 'Parking Bay Search', duration: `${parkingMins} mins`, type: 'Estimated' },
    { icon: <ShoppingBag className="w-4 h-4 text-teal-500" />, label: 'In-Store Grocery Shopping', duration: `${shoppingMins} mins`, type: 'Estimated' },
    { icon: <CreditCard className="w-4 h-4 text-amber-500" />, label: 'Checkout Queue', duration: `${checkoutMins} mins`, type: 'Estimated' },
    { icon: <Home className="w-4 h-4 text-emerald-500" />, label: 'Return Journey', duration: `${returnDriveMins} mins`, type: 'Live Route' },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950/80 text-sky-600 dark:text-sky-400">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
              Total Shopping Journey Breakdown
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Full door-to-door timeline prediction for {store.name}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1.5 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-300 self-start sm:self-auto">
          <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>Estimated Home By: <strong className="text-emerald-700 dark:text-emerald-200 text-sm font-black">{returnTimeString}</strong></span>
        </div>
      </div>

      {/* Step Horizontal Timeline */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {steps.map((step, idx) => (
          <div key={idx} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="p-1.5 rounded-lg bg-white dark:bg-slate-700 shadow-2xs">
                {step.icon}
              </div>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                step.type === 'Live Route'
                  ? 'bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 border border-sky-300 dark:border-sky-800'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}>
                {step.type}
              </span>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight">{step.label}</div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-slate-100 font-mono mt-0.5">{step.duration}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between pt-1">
        <span>Total Estimated Duration: <strong className="text-slate-800 dark:text-slate-200 font-bold">{totalMinutes} minutes</strong></span>
        <span className="italic">* Non-route values clearly labeled as Estimated</span>
      </div>
    </div>
  );
};
