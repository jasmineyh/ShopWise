import React, { useState } from 'react';
import { Search, PackageCheck, AlertCircle, ShoppingBag, ShieldCheck, Check, Layers, RefreshCw } from 'lucide-react';
import { StoreProduct } from '../types';

interface LiveProductStockCheckerProps {
  products: StoreProduct[];
  storeName: string;
}

export const LiveProductStockChecker: React.FC<LiveProductStockCheckerProps> = ({ products, storeName }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isSyncing, setIsSyncing] = useState(false);

  const categories = ['All', ...Array.from(new Set(products.map((p) => p.category)))];

  const filtered = products.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.aisle.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handleManualSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
    }, 600);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xs space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <PackageCheck size={20} className="text-emerald-600" />
            <span>Real-Time Product Availability & Inventory (POS / ERP Stream)</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Verified aisle locations and live item stock counts at {storeName}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="inline-flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800">
            <ShieldCheck size={12} className="text-emerald-600" /> POS/ERP Verified
          </span>
          <button
            onClick={handleManualSync}
            disabled={isSyncing}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 transition-colors"
            title="Force ERP Sync"
          >
            <RefreshCw size={14} className={isSyncing ? 'animate-spin text-sky-600' : ''} />
          </button>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search items, categories, or aisles (e.g. Milk, Salmon, Freezer, Aisle 2A)..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide shrink-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Product List Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
        {filtered.length === 0 ? (
          <div className="col-span-full py-8 text-center text-xs text-slate-400 italic">
            No matching items found in live inventory for "{searchTerm}".
          </div>
        ) : (
          filtered.map((item) => {
            const isHigh = item.stock_status === 'High Stock';
            const isIn = item.stock_status === 'In Stock';
            const isLow = item.stock_status === 'Low Stock';
            const isOut = item.stock_status === 'Out of Stock';

            const badgeColor = isHigh || isIn
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
              : isLow
              ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800'
              : 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800';

            return (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-slate-50/60 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex flex-col justify-between gap-2.5 hover:border-emerald-500/50 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h5 className="font-bold text-xs text-slate-900 dark:text-slate-100 line-clamp-1">
                      {item.name}
                    </h5>
                    <span className="font-mono font-bold text-xs text-slate-900 dark:text-slate-100 shrink-0">
                      ${item.price.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    <span className="px-1.5 py-0.5 rounded bg-slate-200/60 dark:bg-slate-700/60 text-[10px]">
                      {item.category}
                    </span>
                    <span>•</span>
                    <span className="font-mono font-semibold text-sky-600 dark:text-sky-400">
                      📍 {item.aisle}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50">
                  <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md border ${badgeColor}`}>
                    {isOut ? <AlertCircle size={10} /> : <Check size={10} />}
                    <span>{item.stock_status}</span>
                    {!isOut && <span className="font-mono">({item.stock_quantity} left)</span>}
                  </span>

                  <span className="text-[9px] font-mono text-slate-400">
                    Updated {item.last_updated_secs_ago}s ago
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
