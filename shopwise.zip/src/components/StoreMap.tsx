import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Store, ConditionSnapshot } from '../types';
import { calculateSafetyScore } from '../utils/recommendationEngine';

interface StoreMapProps {
  stores: Store[];
  snapshots: Record<string, ConditionSnapshot>;
  activeStoreId?: string | null;
  homeLocation?: { lat: number; lng: number; address: string };
  onSelectStore?: (storeId: string) => void;
  height?: string;
}

export const StoreMap: React.FC<StoreMapProps> = ({
  stores,
  snapshots,
  activeStoreId,
  homeLocation = { lat: 3.139, lng: 101.6869, address: 'Home Base' },
  onSelectStore,
  height = 'h-72',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    const defaultLat = homeLocation.lat;
    const defaultLng = homeLocation.lng;

    const map = L.map(mapContainerRef.current, {
      center: [defaultLat, defaultLng],
      zoom: 12,
      zoomControl: true,
      scrollWheelZoom: false,
    });

    mapInstanceRef.current = map;

    // Invalidate size to guarantee smooth canvas tiling
    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    // OpenStreetMap Tile Layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(map);

    const bounds: L.LatLngExpression[] = [];

    // Home Base Pin
    const homeIcon = L.divIcon({
      className: 'custom-home-pin',
      html: `<div style="background-color: #0284c7; color: white; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 4px 8px rgba(0,0,0,0.3); font-weight: bold; font-size: 15px;">🏠</div>`,
      iconSize: [34, 34],
      iconAnchor: [17, 17],
    });

    const homeMarker = L.marker([homeLocation.lat, homeLocation.lng], { icon: homeIcon }).addTo(map);
    homeMarker.bindPopup(`<b>Your Home Base</b><br/>${homeLocation.address}`);
    bounds.push([homeLocation.lat, homeLocation.lng]);

    // Store Pins
    stores.forEach((s) => {
      const snap = snapshots[s.id] || {
        store_id: s.id,
        weather_status: 'Clear',
        flood_risk: 'Low',
        traffic_level: 'Light',
        crowd_density: 'Low',
        air_quality_index: 40,
        parking_availability_percent: 70,
        active_promotions: [],
        last_updated: new Date().toISOString(),
      };

      const { score } = calculateSafetyScore(s, snap);
      const isActive = activeStoreId === s.id;

      let color = '#10b981'; // green
      if (snap.flood_risk === 'High' || snap.traffic_level === 'Heavy' || score < 55) {
        color = '#ef4444'; // red
      } else if (snap.flood_risk === 'Medium' || score < 75) {
        color = '#f59e0b'; // amber
      }

      const storeIcon = L.divIcon({
        className: 'custom-store-pin',
        html: `<div style="background-color: ${color}; color: white; width: ${isActive ? '38px' : '30px'}; height: ${isActive ? '38px' : '30px'}; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid ${isActive ? '#38bdf8' : 'white'}; box-shadow: 0 4px 10px rgba(0,0,0,0.3); font-weight: bold; font-size: ${isActive ? '16px' : '13px'}; cursor: pointer;">🏬</div>`,
        iconSize: [isActive ? 38 : 30, isActive ? 38 : 30],
        iconAnchor: [isActive ? 19 : 15, isActive ? 19 : 15],
      });

      const marker = L.marker([s.latitude, s.longitude], { icon: storeIcon }).addTo(map);

      const popupContent = document.createElement('div');
      popupContent.style.minWidth = '180px';
      popupContent.style.fontFamily = 'system-ui, sans-serif';
      popupContent.innerHTML = `
        <div style="font-weight: 800; font-size: 14px; margin-bottom: 2px; color: #0f172a;">${s.name}</div>
        <div style="font-size: 12px; color: #64748b; margin-bottom: 6px;">${s.category} • ${s.distance_km} km away</div>
        <div style="display: flex; gap: 4px; margin-bottom: 6px; font-size: 11px;">
          <span style="background: ${snap.flood_risk === 'High' ? '#ffe4e6' : '#ecfdf5'}; color: ${snap.flood_risk === 'High' ? '#be123c' : '#047857'}; padding: 2px 6px; border-radius: 4px; font-weight: 600;">Flood: ${snap.flood_risk}</span>
          <span style="background: ${snap.traffic_level === 'Heavy' ? '#ffe4e6' : '#ecfdf5'}; color: ${snap.traffic_level === 'Heavy' ? '#be123c' : '#047857'}; padding: 2px 6px; border-radius: 4px; font-weight: 600;">Traffic: ${snap.traffic_level}</span>
        </div>
        <div style="font-size: 12px; font-weight: 800; color: #0284c7; margin-bottom: 6px;">ShopWise Score: ${score}/100</div>
      `;

      if (onSelectStore) {
        const btn = document.createElement('button');
        btn.innerText = 'Select Store';
        btn.style.width = '100%';
        btn.style.backgroundColor = '#0f172a';
        btn.style.color = 'white';
        btn.style.border = 'none';
        btn.style.padding = '6px 12px';
        btn.style.borderRadius = '6px';
        btn.style.fontSize = '12px';
        btn.style.fontWeight = 'bold';
        btn.style.cursor = 'pointer';
        btn.onclick = () => onSelectStore(s.id);
        popupContent.appendChild(btn);
      }

      marker.bindPopup(popupContent);
      bounds.push([s.latitude, s.longitude]);
    });

    if (bounds.length > 0) {
      map.fitBounds(bounds as L.LatLngBoundsExpression, { padding: [30, 30] });
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [stores, snapshots, activeStoreId, homeLocation, onSelectStore]);

  return (
    <div className={`relative w-full ${height} rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-2xs z-0`}>
      <div ref={mapContainerRef} className="w-full h-full" />
      <div className="absolute top-2 right-2 z-[400] bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-800 text-[11px] font-semibold text-slate-700 dark:text-slate-300 shadow-xs flex items-center gap-2">
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" /> High Score</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" /> Moderate</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" /> Heavy Traffic</span>
      </div>
    </div>
  );
};
