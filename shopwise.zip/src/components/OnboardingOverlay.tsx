import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, Sparkles, Clock, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

const steps = [
  {
    title: 'Welcome to ShopWise 👋',
    description: 'We analyze live weather, flood risk, traffic, and crowds so you always know where and when to shop.',
    icon: <Sparkles className="w-12 h-12 text-sky-500" />,
  },
  {
    title: 'Smart Time Forecasts',
    description: 'Check the 12-hour forecast on any store to find the best time to go, avoiding crowds and bad weather.',
    icon: <Clock className="w-12 h-12 text-emerald-500" />,
  },
  {
    title: 'Community Safety',
    description: 'Earn points and build streaks by reporting live conditions to help other shoppers in your area.',
    icon: <ShieldCheck className="w-12 h-12 text-teal-500" />,
  },
];

export const OnboardingOverlay: React.FC = () => {
  const { userProfile, updateUserProfile } = useApp();
  const [currentStep, setCurrentStep] = useState(0);

  if (userProfile.has_completed_onboarding) {
    return null;
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1);
    } else {
      updateUserProfile({
        ...userProfile,
        has_completed_onboarding: true,
      });
    }
  };

  const step = steps[currentStep];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 max-w-sm w-full shadow-2xl border border-slate-200 dark:border-slate-800 text-center relative overflow-hidden animate-slide-up">
        {/* Background blobs */}
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-sky-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
          <div className="mb-6 p-4 rounded-full bg-slate-50 dark:bg-slate-800 shadow-inner">
            {step.icon}
          </div>
          
          <h2 className="text-2xl font-black text-slate-900 dark:text-slate-100 mb-3">
            {step.title}
          </h2>
          
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-8 leading-relaxed h-16">
            {step.description}
          </p>

          <div className="flex items-center justify-center gap-2 mb-8">
            {steps.map((_, i) => (
              <div
                key={i}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === currentStep
                    ? 'w-6 bg-sky-500'
                    : 'w-2 bg-slate-200 dark:bg-slate-700'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            className="w-full py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-sky-600 dark:hover:bg-sky-500 font-extrabold text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-md"
          >
            {currentStep < steps.length - 1 ? (
              <>
                <span>Next</span>
                <ArrowRight size={16} />
              </>
            ) : (
              <>
                <span>Get Started</span>
                <CheckCircle2 size={16} />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
