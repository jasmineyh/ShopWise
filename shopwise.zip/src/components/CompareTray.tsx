import React from 'react';
import { useApp } from '../context/AppContext';
import { Columns3, X, ArrowRight, Trash2 } from 'lucide-react';

export const CompareTray: React.FC = () => {
  const { stores, selectedCompareIds, toggleCompareStore, clearCompare, setActiveTab } = useApp();

  const compareList = selectedCompareIds || [];

  if (compareList.length === 0) return null;

  const selectedStores = stores.filter((s) => compareList.includes(s.id));

  const handleCompareNow = () => {
    setActiveTab('plan');
    // Save to session or ensure subtab is 'compare'
    sessionStorage.setItem('shopwise_plan_subtab', 'compare');
    // Dispatch custom event to switch Plan page sub-tab to compare
    window.dispatchEvent(new CustomEvent('shopwise_navigate_plan_subtab', { detail: 'compare' }));
  };

  return (
    <div className="fixed bottom-16 lg:bottom-4 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-2xl bg-slate-900/95 dark:bg-slate-900/95 text-white backdrop-blur-md rounded-2xl border border-sky-500/30 shadow-2xl p-3 animate-in slide-in-from-bottom-4 duration-200">
      <div className="flex items-center justify-between gap-3">
        {/* Title & Count */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
            <Columns3 size={16} />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
              <span>Compare Stores</span>
              <span className="text-[10px] font-extrabold bg-sky-500/20 text-sky-300 px-1.5 py-0.2 rounded-md font-mono">
                {compareList.length}/3
              </span>
            </div>
            <p className="text-[10px] text-slate-400 hidden sm:block">Side-by-side traffic, distance & deals</p>
          </div>
        </div>

        {/* Selected Store Badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 max-w-[240px] sm:max-w-xs scrollbar-hide">
          {selectedStores.map((store) => (
            <div
              key={store.id}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-slate-700/80 rounded-xl border border-slate-700 text-xs text-slate-200 shrink-0 font-medium transition-colors"
            >
              <span className="truncate max-w-[90px]">{store.name}</span>
              <button
                onClick={() => toggleCompareStore(store.id)}
                className="text-slate-400 hover:text-rose-400 transition-colors"
                title="Remove"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={clearCompare}
            className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition-colors"
            title="Clear comparison list"
          >
            <Trash2 size={16} />
          </button>
          <button
            onClick={handleCompareNow}
            className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-600/30 flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
          >
            <span>Compare Now</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
