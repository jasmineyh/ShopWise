import React, { useState, useEffect, useRef } from 'react';
import {
  MapPin,
  Search,
  Crosshair,
  X,
  Clock,
  Bookmark,
  Plus,
  Check,
  Loader2,
  AlertCircle,
  RefreshCw,
  ChevronDown,
  Calendar
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { searchLocationsAutocomplete, fetchPlaceDetails, reverseGeocode, LocationSuggestion } from '../services/mapsService';
import { ActiveLocation } from '../types';
import { TimeSelectorModal } from './TimeSelectorModal';

export const LocationBar: React.FC = () => {
  const {
    activeLocation,
    setActiveLocation,
    savedLocations,
    addSavedLocation,
    addToast,
    plannedDeparture
  } = useApp();

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isTimeModalOpen, setIsTimeModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSelectingPlace, setIsSelectingPlace] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [saveLabel, setSaveLabel] = useState('');
  const [showSaveInput, setShowSaveInput] = useState(false);

  const [recentLocations, setRecentLocations] = useState<ActiveLocation[]>(() => {
    const saved = localStorage.getItem('shopwise_recent_locations');
    return saved ? JSON.parse(saved) : [];
  });

  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const activeReqIdRef = useRef<number>(0);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle autocomplete search
  const performSearch = async (query: string) => {
    if (!query.trim() || query.trim().length < 2) {
      setSuggestions([]);
      setSearchError(null);
      setIsLoading(false);
      return;
    }

    console.log('[LocationSearch] requesting autocomplete for query:', query);
    const currentReqId = ++activeReqIdRef.current;
    setIsLoading(true);
    setSearchError(null);

    const result = await searchLocationsAutocomplete(
      query.trim(),
      activeLocation.latitude,
      activeLocation.longitude
    );

    // Ignore response if newer request initiated
    if (currentReqId !== activeReqIdRef.current) return;

    if (result.error) {
      console.error('[LocationSearch] autocomplete error:', result.error);
      setSearchError(result.error);
      setSuggestions([]);
    } else {
      console.log('[LocationSearch] suggestions received:', result.suggestions.length);
      setSuggestions(result.suggestions);
      setSearchError(null);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    console.log('[LocationSearch] query changed:', searchQuery);
    if (!searchQuery.trim() || searchQuery.trim().length < 2) {
      setSuggestions([]);
      setSearchError(null);
      setIsLoading(false);
      return;
    }

    const timer = setTimeout(() => {
      performSearch(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleSelectLocation = (loc: ActiveLocation) => {
    console.log('[LocationSearch] activeLocation updated:', loc);
    setActiveLocation(loc);
    
    // Add to recent locations
    setRecentLocations((prev) => {
      const filtered = prev.filter((item) => item.formattedAddress !== loc.formattedAddress && item.placeId !== loc.placeId);
      const updated = [loc, ...filtered].slice(0, 5);
      localStorage.setItem('shopwise_recent_locations', JSON.stringify(updated));
      return updated;
    });

    setIsDropdownOpen(false);
    setSearchQuery('');
    setSuggestions([]);
  };

  const handleSelectSuggestion = async (sug: LocationSuggestion) => {
    console.log('[LocationSearch] suggestion selected:', sug);
    setIsSelectingPlace(true);
    let details: ActiveLocation | null = null;

    if (sug.placeId) {
      details = await fetchPlaceDetails(sug.placeId);
    }

    if (!details && sug.latitude !== undefined && sug.longitude !== undefined) {
      details = {
        placeId: sug.placeId,
        displayName: sug.displayName,
        formattedAddress: sug.formattedAddress,
        latitude: sug.latitude,
        longitude: sug.longitude,
        city: sug.city,
        country: sug.country
      };
    }

    setIsSelectingPlace(false);

    if (details) {
      handleSelectLocation(details);
    } else {
      addToast('Could not load location details for the selected place.', 'error');
    }
  };

  const handleUseCurrentLocation = () => {
    if (!('geolocation' in navigator)) {
      addToast('Geolocation is not supported by your browser', 'warning');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const loc = await reverseGeocode(lat, lng);
        handleSelectLocation(loc);
        setIsLocating(false);
        addToast('Using your current location', 'success');
      },
      () => {
        setIsLocating(false);
        addToast('Could not access current location. Please search manually.', 'warning');
      },
      { timeout: 8000 }
    );
  };

  const handleSaveCurrentActive = () => {
    if (!saveLabel.trim()) return;
    addSavedLocation({
      label: saveLabel.trim(),
      address: activeLocation.formattedAddress,
      latitude: activeLocation.latitude,
      longitude: activeLocation.longitude
    });
    setSaveLabel('');
    setShowSaveInput(false);
  };

  return (
    <div ref={containerRef} className="px-4 pt-2.5 pb-2 bg-slate-900 text-white relative z-40">
      <div className="max-w-7xl mx-auto relative">
        {/* Main Search Input Bar */}
        <div className="relative flex items-center bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 rounded-2xl transition-all shadow-sm focus-within:ring-2 focus-within:ring-sky-500/80 focus-within:border-sky-500">
          <div className="pl-3.5 pr-2 py-2.5 flex items-center gap-2 pointer-events-none shrink-0 text-sky-400">
            <Search className="w-4 h-4" />
          </div>

          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onFocus={() => setIsDropdownOpen(true)}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              if (!isDropdownOpen) setIsDropdownOpen(true);
            }}
            placeholder={`Search city, area, address or place... (Current: ${activeLocation.displayName})`}
            className="w-full bg-transparent text-sm font-medium text-slate-100 placeholder-slate-400 focus:outline-none py-2.5 pr-28 min-w-0"
          />

          {/* Active location & Departure Time pills */}
          <div className="absolute right-2 flex items-center gap-1.5 shrink-0">
            {searchQuery ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSuggestions([]);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition-colors"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <>
                {/* Departure Time Selector Pill */}
                <button
                  onClick={() => setIsTimeModalOpen(true)}
                  className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-xs font-semibold text-amber-300 border border-amber-500/30 transition-colors shrink-0"
                  title="Change departure date & time"
                >
                  <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate max-w-[120px] lg:max-w-[160px]">
                    {plannedDeparture.formattedFull}
                  </span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {/* Location Selector Pill */}
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-xs font-semibold text-sky-300 border border-slate-600/60 transition-colors shrink-0"
                  title="Change active search location"
                >
                  <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span className="truncate max-w-[100px] sm:max-w-[140px]">
                    {activeLocation.displayName}
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Dropdown Popover Directly Below Search Input Bar */}
        {isDropdownOpen && (
          <div className="absolute left-0 right-0 top-full mt-2 z-50 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden max-h-[80vh] flex flex-col text-slate-100 animate-fadeIn">
            {/* GPS Current Location Quick Button */}
            <div className="p-3 border-b border-slate-800 bg-slate-900/90">
              <button
                onClick={handleUseCurrentLocation}
                disabled={isLocating}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/20 text-sky-300 font-medium text-sm transition-all active:scale-[0.99]"
              >
                <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 shrink-0">
                  {isLocating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Crosshair className="w-4 h-4" />
                  )}
                </div>
                <div className="text-left flex-1 min-w-0">
                  <div className="font-bold text-sky-300 text-xs sm:text-sm">
                    {isLocating ? 'Detecting GPS coordinates...' : '◎ Use My Current Location'}
                  </div>
                  <div className="text-[11px] text-sky-400/80 truncate">
                    Automatically locate supermarkets near you
                  </div>
                </div>
              </button>
            </div>

            {/* Results / Content */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {/* Selecting place details loading state */}
              {isSelectingPlace ? (
                <div className="py-6 text-center text-slate-400 flex items-center justify-center gap-2 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
                  Loading place details...
                </div>
              ) : isLoading ? (
                <div className="py-6 text-center text-slate-400 flex items-center justify-center gap-2 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
                  Searching locations...
                </div>
              ) : searchError ? (
                <div className="py-6 text-center space-y-2">
                  <div className="flex items-center justify-center gap-1.5 text-rose-400 text-sm font-medium">
                    <AlertCircle className="w-4 h-4" />
                    Unable to search locations right now.
                  </div>
                  <button
                    onClick={() => performSearch(searchQuery)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Try again
                  </button>
                </div>
              ) : suggestions.length > 0 ? (
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1">
                    Google Places Search Results
                  </div>
                  {suggestions.map((sug) => (
                    <button
                      key={sug.placeId}
                      onClick={() => handleSelectSuggestion(sug)}
                      className="w-full flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-800 text-left transition-colors border border-transparent hover:border-slate-700/60 group"
                    >
                      <MapPin className="w-4 h-4 text-sky-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
                      <div className="min-w-0 flex-1">
                        <div className="font-bold text-sm text-slate-100 truncate">
                          {sug.displayName}
                        </div>
                        <div className="text-xs text-slate-400 truncate">
                          {sug.formattedAddress}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : searchQuery.trim().length >= 2 ? (
                <div className="py-6 text-center text-slate-400 text-sm font-medium">
                  No matching locations found
                </div>
              ) : null}

              {/* Recent Locations */}
              {recentLocations.length > 0 && !searchQuery && (
                <div className="space-y-1.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1 flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-slate-400" />
                    Recent Locations
                  </div>
                  <div className="space-y-1">
                    {recentLocations.map((loc) => {
                      const isActive = loc.formattedAddress === activeLocation.formattedAddress;
                      return (
                        <button
                          key={loc.formattedAddress}
                          onClick={() => handleSelectLocation(loc)}
                          className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-colors ${
                            isActive
                              ? 'bg-sky-500/15 border border-sky-500/30 text-sky-300'
                              : 'bg-slate-800/40 hover:bg-slate-800 text-slate-200 border border-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <MapPin className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
                            <div className="min-w-0">
                              <div className="font-bold text-xs truncate">{loc.displayName}</div>
                              <div className="text-[10px] text-slate-400 truncate max-w-xs">{loc.formattedAddress}</div>
                            </div>
                          </div>
                          {isActive && <Check className="w-3.5 h-3.5 text-sky-400 shrink-0 ml-2" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Saved User Places */}
              {!searchQuery && (
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <div className="flex items-center justify-between px-1">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Bookmark className="w-3 h-3 text-emerald-400" />
                      Saved Places
                    </div>
                    {!showSaveInput && (
                      <button
                        onClick={() => setShowSaveInput(true)}
                        className="text-xs text-sky-400 hover:text-sky-300 font-medium flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" /> Save Active Location
                      </button>
                    )}
                  </div>

                  {showSaveInput && (
                    <div className="p-2.5 bg-slate-800/80 rounded-xl border border-slate-700 space-y-2">
                      <div className="text-xs text-slate-300 font-medium">
                        Save "{activeLocation.displayName}" as:
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={saveLabel}
                          onChange={(e) => setSaveLabel(e.target.value)}
                          placeholder="e.g. Home, Work, School"
                          className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1 text-xs text-white focus:outline-none focus:border-sky-500"
                        />
                        <button
                          onClick={handleSaveCurrentActive}
                          className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setShowSaveInput(false)}
                          className="px-2 py-1 text-slate-400 hover:text-white text-xs"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}

                  {savedLocations.length > 0 ? (
                    <div className="grid grid-cols-2 gap-2">
                      {savedLocations.map((loc) => (
                        <button
                          key={loc.id}
                          onClick={() => handleSelectLocation({
                            displayName: loc.label,
                            formattedAddress: loc.address,
                            latitude: loc.latitude,
                            longitude: loc.longitude
                          })}
                          className="flex items-center gap-2 p-2 rounded-xl bg-slate-800/50 hover:bg-slate-800 border border-slate-800 text-left transition-colors"
                        >
                          <Bookmark className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <div className="min-w-0">
                            <div className="font-bold text-xs text-slate-200 truncate">{loc.label}</div>
                            <div className="text-[10px] text-slate-400 truncate">{loc.address}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-slate-500 italic px-1">
                      No saved places yet. Save "Home" or "Work" for 1-tap switching.
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <TimeSelectorModal
        isOpen={isTimeModalOpen}
        onClose={() => setIsTimeModalOpen(false)}
      />
    </div>
  );
};
