import React from 'react';
import { useApp } from '../context/AppContext';
import {
  CloudLightning,
  Sun,
  Car,
  X,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { WeatherStatus, FloodRisk, TrafficLevel, CrowdDensity } from '../types';

interface WeatherSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WeatherSimulatorModal: React.FC<WeatherSimulatorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { stores, snapshots, refreshConditions, addToast, evaluateBestStore } = useApp();

  if (!isOpen) return null;

  const handleApplyScenario = async (
    scenarioName: string,
    config: {
      weather: WeatherStatus;
      flood: FloodRisk;
      traffic: TrafficLevel;
      crowd: CrowdDensity;
      affectedStoreId?: string;
    }
  ) => {
    // Modify snapshot state to reflect simulation
    const updatedSnapshots = { ...snapshots };

    Object.keys(updatedSnapshots).forEach((storeId) => {
      if (!config.affectedStoreId || config.affectedStoreId === storeId) {
        updatedSnapshots[storeId] = {
          ...updatedSnapshots[storeId],
          weather_status: config.weather,
          flood_risk: config.flood,
          traffic_level: config.traffic,
          crowd_density: config.crowd,
          last_updated: new Date().toISOString(),
        };
      }
    });

    localStorage.setItem('shopwise_snapshots', JSON.stringify(updatedSnapshots));
    addToast(`Simulated scenario: "${scenarioName}"`, 'warning');
    await refreshConditions();
    await evaluateBestStore();
    onClose();
  };

  const scenarios = [
    {
      title: 'Monsoon Flash Flood Warning',
      description: 'Heavy torrential downpour causing severe flooding near Metro Grand Galleria.',
      icon: <CloudLightning className="w-6 h-6 text-rose-500" />,
      badge: 'High Flood Risk',
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      action: () =>
        handleApplyScenario('Monsoon Flash Flood Warning', {
          weather: 'Storm',
          flood: 'High',
          traffic: 'Heavy',
          crowd: 'Low',
          affectedStoreId: 'store_metro_galleria',
        }),
    },
    {
      title: 'Peak Rush Hour Gridlock',
      description: 'Heavy evening commuter traffic surrounding main central highway shopping districts.',
      icon: <Car className="w-6 h-6 text-amber-500" />,
      badge: 'Heavy Traffic',
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
      action: () =>
        handleApplyScenario('Peak Rush Hour Gridlock', {
          weather: 'Clear',
          flood: 'Low',
          traffic: 'Heavy',
          crowd: 'High',
        }),
    },
    {
      title: 'Clear & Sunny Weekend',
      description: 'Ideal driving conditions across all regional shopping zones with light traffic.',
      icon: <Sun className="w-6 h-6 text-amber-400" />,
      badge: 'Clear Conditions',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      action: () =>
        handleApplyScenario('Clear & Sunny Weekend', {
          weather: 'Clear',
          flood: 'Low',
          traffic: 'Light',
          crowd: 'Medium',
        }),
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
              <Zap size={20} />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 dark:text-slate-100 text-base">
                Live Condition Simulator
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Test how ShopWise AI dynamic safety scores recalculate in severe weather.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-3">
          {scenarios.map((scen, sIdx) => (
            <button
              key={sIdx}
              onClick={scen.action}
              className="w-full text-left p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-sky-500 dark:hover:border-sky-500 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-sky-50/50 dark:hover:bg-sky-950/20 transition-all flex items-start gap-4 group"
            >
              <div className="shrink-0 p-2.5 rounded-xl bg-white dark:bg-slate-800 shadow-sm border border-slate-200/60 dark:border-slate-700/60">
                {scen.icon}
              </div>

              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 dark:text-slate-100 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                    {scen.title}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${scen.badgeColor}`}
                  >
                    {scen.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {scen.description}
                </p>
              </div>
            </button>
          ))}
        </div>

        <div className="p-3 bg-slate-100 dark:bg-slate-800/60 rounded-xl text-xs text-slate-600 dark:text-slate-400 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-sky-500 shrink-0" />
          <span>
            Applying a scenario updates all store markers on the interactive map and triggers an immediate AI recalculation.
          </span>
        </div>
      </div>
    </div>
  );
};
