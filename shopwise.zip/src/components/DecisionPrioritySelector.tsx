import React from 'react';
import { useApp } from '../context/AppContext';
import { DecisionPriority } from '../utils/recommendationEngine';
import { Scale, Zap, Tag, Users, Shield, Sparkles } from 'lucide-react';

export const DecisionPrioritySelector: React.FC = () => {
  const { decisionPriority, setDecisionPriority } = useApp();

  const options: { id: DecisionPriority; label: string; desc: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'balanced',
      label: 'Balanced',
      desc: 'Optimal mix of time, crowds & safety',
      icon: <Scale className="w-4 h-4" />,
      badge: 'Recommended'
    },
    {
      id: 'fastest',
      label: 'Fastest Route',
      desc: 'Minimizes driving delay & traffic',
      icon: <Zap className="w-4 h-4" />
    },
    {
      id: 'cheapest',
      label: 'Best Deals',
      desc: 'Prioritizes store discounts & lowest prices',
      icon: <Tag className="w-4 h-4" />
    },
    {
      id: 'crowd',
      label: 'Least Crowded',
      desc: 'Avoids queues & aisle congestion',
      icon: <Users className="w-4 h-4" />
    },
    {
      id: 'risk',
      label: 'Lowest Risk',
      desc: 'Avoids flood points, storms & bad weather',
      icon: <Shield className="w-4 h-4" />
    }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950/80 text-sky-600 dark:text-sky-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
              What matters most today?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Select your priority to recalculate ShopWise Scores & recommendations
            </p>
          </div>
        </div>
        <span className="text-[11px] font-bold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 px-2.5 py-1 rounded-full border border-sky-200 dark:border-sky-900/50 self-start sm:self-auto">
          Active: {options.find(o => o.id === decisionPriority)?.label}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 pt-1">
        {options.map((opt) => {
          const isSelected = decisionPriority === opt.id;
          return (
            <button
              key={opt.id}
              onClick={() => setDecisionPriority(opt.id)}
              className={`p-3 rounded-2xl border text-left transition-all relative flex flex-col justify-between ${
                isSelected
                  ? 'bg-sky-600 text-white border-sky-600 shadow-md shadow-sky-600/20 ring-2 ring-sky-400 dark:ring-sky-500'
                  : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-sky-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-1">
                <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                  {opt.icon}
                </div>
                {opt.badge && !isSelected && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                    {opt.badge}
                  </span>
                )}
              </div>
              <div>
                <div className={`text-xs font-bold leading-tight ${isSelected ? 'text-white' : 'text-slate-900 dark:text-slate-100'}`}>
                  {opt.label}
                </div>
                <div className={`text-[10px] mt-0.5 leading-tight ${isSelected ? 'text-sky-100' : 'text-slate-500 dark:text-slate-400'}`}>
                  {opt.desc}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
