import React from 'react';
import { useApp } from '../context/AppContext';
import { Clock, Sparkles, TrendingUp, Check, ArrowRight } from 'lucide-react';
import { DeparturePreset } from '../types';

export const BestTimeForecastWidget: React.FC = () => {
  const { plannedDeparture, setPlannedDeparturePreset, stores, snapshots } = useApp();

  const timeWindows: {
    preset: DeparturePreset;
    label: string;
    time: string;
    traffic: 'Light' | 'Moderate' | 'Heavy';
    crowd: 'Low' | 'Medium' | 'High';
    score: number;
    badge?: string;
  }[] = [
    {
      preset: 'now',
      label: 'Now',
      time: 'Live',
      traffic: 'Heavy',
      crowd: 'High',
      score: 68,
    },
    {
      preset: 'this_afternoon',
      label: '3:00 PM',
      time: 'Afternoon',
      traffic: 'Moderate',
      crowd: 'Medium',
      score: 82,
    },
    {
      preset: 'this_evening',
      label: '6:30 PM',
      time: 'Evening',
      traffic: 'Light',
      crowd: 'Low',
      score: 94,
      badge: '★ Best Time',
    },
    {
      preset: 'tomorrow_morning',
      label: 'Tomorrow 10 AM',
      time: 'Morning',
      traffic: 'Light',
      crowd: 'Low',
      score: 89,
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xs space-y-4">
      {/* Widget Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
            <Clock size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base">
                Go Now or Later?
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                Hourly Forecast
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Optimal departure window for minimum traffic & quietest stores
            </p>
          </div>
        </div>

        {/* Current Active Setting */}
        <div className="text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
          Selected: <span className="text-sky-600 dark:text-sky-400 font-bold">{plannedDeparture.formattedFull}</span>
        </div>
      </div>

      {/* Time Window Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {timeWindows.map((tw) => {
          const isCurrentPreset = plannedDeparture.preset === tw.preset;
          return (
            <div
              key={tw.preset}
              onClick={() => setPlannedDeparturePreset(tw.preset)}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all relative flex flex-col justify-between ${
                tw.badge
                  ? 'border-emerald-500/80 bg-gradient-to-b from-emerald-50/80 to-white dark:from-emerald-950/30 dark:to-slate-900 shadow-sm ring-1 ring-emerald-500/30'
                  : isCurrentPreset
                  ? 'border-sky-500 bg-sky-50/60 dark:bg-sky-950/30'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-800/40'
              }`}
            >
              {tw.badge && (
                <div className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full bg-emerald-600 text-white font-extrabold text-[9px] uppercase tracking-wider shadow-xs">
                  {tw.badge}
                </div>
              )}

              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{tw.label}</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{tw.time}</div>

                <div className="mt-3 space-y-1">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-slate-500">Traffic:</span>
                    <span className={`font-bold ${tw.traffic === 'Light' ? 'text-emerald-600 dark:text-emerald-400' : tw.traffic === 'Moderate' ? 'text-amber-600' : 'text-rose-600'}`}>
                      {tw.traffic}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-slate-500">Crowd:</span>
                    <span className={`font-bold ${tw.crowd === 'Low' ? 'text-emerald-600 dark:text-emerald-400' : tw.crowd === 'Medium' ? 'text-amber-600' : 'text-rose-600'}`}>
                      {tw.crowd}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="text-xs font-black text-slate-900 dark:text-slate-100">
                  {tw.score} <span className="text-[10px] font-normal text-slate-400">pts</span>
                </div>
                {isCurrentPreset ? (
                  <span className="text-[10px] font-bold text-sky-600 dark:text-sky-400 flex items-center gap-0.5">
                    <Check size={12} /> Active
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-slate-400 hover:text-sky-600">
                    Select
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Day & Date Contextual Intelligence Banner */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-sky-600 dark:text-sky-400 shrink-0" />
          <span>
            <strong className="text-slate-900 dark:text-slate-100">{plannedDeparture.dateLabel} ({plannedDeparture.dayType}): </strong>
            {plannedDeparture.intelligenceNote}
          </span>
        </div>
        <span className="text-[10px] font-mono px-2 py-0.5 bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 rounded-md shrink-0 font-semibold">
          {plannedDeparture.confidence}
        </span>
      </div>
    </div>
  );
};
