import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Clock, Calendar, Check, X, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { DeparturePreset } from '../types';

interface TimeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TimeSelectorModal: React.FC<TimeSelectorModalProps> = ({ isOpen, onClose }) => {
  const { plannedDeparture, setPlannedDeparturePreset } = useApp();
  const [selectedPreset, setSelectedPreset] = useState<DeparturePreset>(plannedDeparture.preset);
  const [customDate, setCustomDate] = useState<string>(() => {
    const d = new Date();
    d.setHours(d.getHours() + 2);
    return d.toISOString().slice(0, 16);
  });

  if (!isOpen) return null;

  const presets: { id: DeparturePreset; label: string; desc: string; icon: string }[] = [
    { id: 'now', label: 'Go Now', desc: 'Real-time live sensor conditions', icon: '⚡' },
    { id: 'in_30m', label: 'In 30 Minutes', desc: 'Predictive departure ETA', icon: '⏱' },
    { id: 'in_1h', label: 'In 1 Hour', desc: 'Upcoming traffic window', icon: '⏳' },
    { id: 'this_afternoon', label: 'This Afternoon (3:00 PM)', desc: 'Afternoon store traffic trend', icon: '☀️' },
    { id: 'this_evening', label: 'This Evening (6:30 PM)', desc: 'Post-work evening window', icon: '🌙' },
    { id: 'tomorrow_morning', label: 'Tomorrow Morning (10:00 AM)', desc: 'Weekend/Weekday morning trend', icon: '☕' },
    { id: 'tomorrow_afternoon', label: 'Tomorrow Afternoon (3:00 PM)', desc: 'Peak shopping window', icon: '🛍' },
    { id: 'custom', label: 'Custom Date & Time', desc: 'Specify custom departure date', icon: '📅' },
  ];

  const handleApply = () => {
    if (selectedPreset === 'custom' && customDate) {
      setPlannedDeparturePreset('custom', new Date(customDate));
    } else {
      setPlannedDeparturePreset(selectedPreset);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
              <Clock size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">Plan Trip Time</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Recalculates traffic, crowds, and route ETAs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          <div className="grid grid-cols-1 gap-2">
            {presets.map((p) => {
              const isSelected = selectedPreset === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedPreset(p.id)}
                  className={`flex items-start justify-between p-3.5 rounded-2xl border text-left transition-all ${
                    isSelected
                      ? 'bg-sky-50 dark:bg-sky-950/40 border-sky-500 dark:border-sky-500 shadow-xs ring-1 ring-sky-500/30'
                      : 'bg-white dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 hover:border-sky-200 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-lg leading-none">{p.icon}</span>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{p.label}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{p.desc}</div>
                    </div>
                  </div>
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-sky-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                      <Check size={12} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Custom Date Input */}
          {selectedPreset === 'custom' && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 mt-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Calendar size={14} className="text-sky-600" />
                Select Departure Date & Time
              </label>
              <input
                type="datetime-local"
                value={customDate}
                onChange={(e) => setCustomDate(e.target.value)}
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          )}

          {/* Time Context Info Banner */}
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-2xl flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-300">
            <Sparkles size={16} className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Date & Time Intelligence Active: </span>
              ShopWise adjusts traffic congestion and store crowds based on historical peak trends, day of the week, and holiday schedules.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-medium hidden sm:block">
            Currently set to <span className="font-bold text-slate-800 dark:text-slate-200">{plannedDeparture.formattedFull}</span>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md shadow-sky-600/20 transition-all flex items-center gap-1.5"
            >
              <Check size={14} />
              Apply Departure Time
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
