import React from 'react';
import { useApp } from '../context/AppContext';
import { Clock, X, Sparkles } from 'lucide-react';
import { ScrollingTimePicker } from './ScrollingTimePicker';

interface TimeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TimeSelectorModal: React.FC<TimeSelectorModalProps> = ({ isOpen, onClose }) => {
  const { plannedDeparture } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Clock size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">Select Departure Time</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Scroll time slots or drum picker to update route ETAs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body with Scrolling Time Picker */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          <ScrollingTimePicker onApply={onClose} />

          {/* Time Context Info Banner */}
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-2xl flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-300">
            <Sparkles size={16} className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Dynamic Time Intelligence Active: </span>
              ShopWise adjusts traffic congestion and store crowds based on historical peak trends, day of the week, and holiday schedules.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-medium">
            Active: <span className="font-bold text-slate-800 dark:text-slate-200">{plannedDeparture.formattedFull}</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md shadow-sky-600/20 transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

