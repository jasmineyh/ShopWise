import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, RefreshCw, Bell, Zap } from 'lucide-react';
import { WeatherSimulatorModal } from './WeatherSimulatorModal';
import { LocationBar } from './LocationBar';
import { LiveAlertsModal } from './LiveAlertsModal';

export const Header: React.FC = () => {
  const { userProfile, isRefreshing, refreshConditions, alerts, setActiveTab, activeTab } = useApp();
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const unreadAlertsCount = alerts.filter((a) => !a.is_read).length;

  const showLocationBar = ['home', 'explore', 'plan'].includes(activeTab);

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-600 via-teal-500 to-emerald-400 flex items-center justify-center text-white shadow-md shadow-sky-500/25 shrink-0 group cursor-pointer" onClick={() => setActiveTab('home')}>
              <ShoppingBag className="w-5 h-5 text-white transition-transform group-hover:scale-110" />
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-xs border-2 border-white dark:border-slate-900">
                <Zap size={9} className="fill-slate-950 stroke-slate-950" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 
                  onClick={() => setActiveTab('home')}
                  className="text-xl font-black tracking-tight text-slate-900 dark:text-slate-100 font-sans cursor-pointer hover:opacity-90 transition-opacity"
                >
                  ShopWise
                </h1>
              </div>
            </div>
          </div>

          {/* User & Quick Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Weather Simulator Button */}
            <button
              onClick={() => setIsSimulatorOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-300 text-xs font-semibold transition-colors border border-amber-200 dark:border-amber-800/60"
              title="Simulate severe weather storms or traffic jams to test AI re-routing"
            >
              <Zap size={14} className="text-amber-600 dark:text-amber-400" />
              <span className="hidden md:inline">Simulate Conditions</span>
            </button>

            {/* Refresh Conditions Button */}
            <button
              onClick={refreshConditions}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors border border-slate-200 dark:border-slate-700 disabled:opacity-50"
              title="Re-evaluate live conditions (weather, flood, traffic, parking) across all stores"
            >
              <RefreshCw size={14} className={`text-sky-600 dark:text-sky-400 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">{isRefreshing ? 'Updating...' : 'Refresh'}</span>
            </button>

            {/* Alerts Bell Button */}
            <button
              onClick={() => setIsAlertsOpen(true)}
              className="relative p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer"
              title="View Live Alerts"
            >
              <Bell size={18} />
              {unreadAlertsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                  {unreadAlertsCount}
                </span>
              )}
            </button>

            {/* User Profile Avatar */}
            <button
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors"
            >
              <div className="w-7 h-7 rounded-full bg-sky-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                {userProfile.name.charAt(0)}
              </div>
              <span className="hidden xl:inline">{userProfile.name}</span>
            </button>
          </div>
        </div>

        {/* Persistent Global Location Bar */}
        {showLocationBar && <LocationBar />}
      </header>

      <WeatherSimulatorModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
      />

      <LiveAlertsModal
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
      />
    </>
  );
};


