import React from 'react';
import { useApp } from '../context/AppContext';
import { Navigation, DollarSign, Clock, ArrowRight, CheckCircle, AlertTriangle, ShieldCheck } from 'lucide-react';

export const WorthTheDetourWidget: React.FC = () => {
  const { stores, setActiveStoreId, navigateToStoreDetails, addToast } = useApp();

  if (!stores || stores.length < 2) return null;

  // Compare closest store vs 2nd option
  const closestStore = stores[0];
  const candidateStore = stores[1] || stores[2] || stores[0];

  // Calculate extra distance & time
  const extraDistance = Math.max(0, candidateStore.distance_km - closestStore.distance_km).toFixed(1);
  const extraTime = Math.max(0, (candidateStore.travel_time_minutes || Math.round(candidateStore.distance_km * 3)) - (closestStore.travel_time_minutes || Math.round(closestStore.distance_km * 3)));

  // Estimated savings based on promotions & price index difference
  const promoCount = candidateStore.active_promotions?.length || 2;
  const priceIndexDiff = closestStore.average_price_index - candidateStore.average_price_index;
  const estimatedSavings = Math.max(12, Math.round(promoCount * 8 + priceIndexDiff * 10));

  const isWorthDetour = estimatedSavings >= 15 && extraTime <= 12;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400">
            <Navigation className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <span>Worth the Detour?</span>
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                AI Detour Analyzer
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Evaluates extra travel time vs estimated store promotion savings
            </p>
          </div>
        </div>

        <div className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 self-start sm:self-auto ${
          isWorthDetour
            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
            : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
        }`}>
          {isWorthDetour ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
          <span>{isWorthDetour ? 'Verdict: Worth the Detour!' : 'Verdict: Slight Detour'}</span>
        </div>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Option 1: Faster / Closer Store */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/70 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            <span>Closest / Quick Option</span>
            <span className="text-sky-600 dark:text-sky-400">Fastest</span>
          </div>
          <div className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">
            {closestStore.name}
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300 font-medium">
            <span>📍 {closestStore.distance_km} km</span>
            <span>⏱ ~{closestStore.travel_time_minutes || Math.round(closestStore.distance_km * 3)} mins drive</span>
          </div>
          <button
            onClick={() => {
              setActiveStoreId(closestStore.id);
              navigateToStoreDetails(closestStore.id);
            }}
            className="w-full mt-2 py-2 px-3 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-900 dark:text-slate-100 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-600 transition-colors flex items-center justify-center gap-1"
          >
            <span>Choose Faster Store</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Option 2: Detour Candidate Store */}
        <div className="p-4 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/60 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
            <span>Further / Deal Option</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">Est. Save RM {estimatedSavings}</span>
          </div>
          <div className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">
            {candidateStore.name}
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-700 dark:text-slate-300 font-medium">
            <span>📍 +{extraDistance} km extra</span>
            <span>⏱ +{extraTime} mins extra drive</span>
          </div>
          <button
            onClick={() => {
              setActiveStoreId(candidateStore.id);
              navigateToStoreDetails(candidateStore.id);
            }}
            className="w-full mt-2 py-2 px-3 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1"
          >
            <span>Choose Cheaper Store (Save RM {estimatedSavings})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
