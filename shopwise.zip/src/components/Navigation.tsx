import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Home,
  Map as MapIcon,
  Briefcase,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { NavigationTab } from '../types';

export const Navigation: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  const navItems: { id: NavigationTab; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: <Home size={20} />,
    },
    {
      id: 'explore',
      label: 'Explore',
      icon: <MapIcon size={20} />,
    },
    {
      id: 'plan',
      label: 'Plan',
      icon: <Briefcase size={20} />,
    }
  ];


  return (
    <>
      {/* Desktop Sidebar Navigation */}
      <aside className="hidden lg:flex flex-col w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 p-4 shrink-0 min-h-[calc(100vh-4rem)] justify-between sticky top-16">
        <div className="space-y-6">
          <div className="px-3 py-2 bg-gradient-to-r from-sky-50 to-teal-50 dark:from-sky-950/40 dark:to-teal-950/40 rounded-xl border border-sky-100 dark:border-sky-900/40">
            <div className="flex items-center gap-2 text-sky-800 dark:text-sky-300 font-bold text-xs mb-1">
              <Sparkles size={14} className="text-sky-600 dark:text-sky-400" />
              <span>Smart Travel Engine</span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-tight">
              Real-time multi-factor analysis: flood, traffic, crowds, parking & promos.
            </p>
          </div>

          <nav className="space-y-1.5">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-3 mb-2">
              Navigation
            </div>
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold text-sm transition-all ${
                    isActive
                      ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-bold font-mono ${
                        isActive
                          ? 'bg-white text-sky-700'
                          : 'bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer Widget */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-400 space-y-2">
          <div className="flex items-center gap-2 font-semibold text-slate-800 dark:text-slate-200">
            <ShieldCheck className="text-emerald-500 w-4 h-4 shrink-0" />
            <span>Safety Monitoring Active</span>
          </div>
          <p className="text-[11px] leading-relaxed">
            Live sensor feed active for 7 regional shopping zones.
          </p>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-2 flex items-center justify-around shadow-lg">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
                isActive
                  ? 'text-sky-600 dark:text-sky-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900'
              }`}
            >
              <div className="relative">
                {item.icon}
                {item.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-2.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold font-mono bg-rose-600 text-white">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-1 tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
