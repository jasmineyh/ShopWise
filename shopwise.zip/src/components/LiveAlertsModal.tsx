import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Bell,
  X,
  ShieldAlert,
  Car,
  Users,
  Sun,
  CheckCheck,
  ExternalLink,
  Info
} from 'lucide-react';

interface LiveAlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveAlertsModal: React.FC<LiveAlertsModalProps> = ({ isOpen, onClose }) => {
  const { alerts, stores, markAlertRead, markAllAlertsRead, navigateToStoreDetails } = useApp();
  const [filter, setFilter] = useState<'all' | 'unread' | 'flood' | 'traffic' | 'crowd'>('all');

  if (!isOpen) return null;

  const unreadCount = alerts.filter((a) => !a.is_read).length;

  const sortedAlerts = [...alerts].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  const filteredAlerts = sortedAlerts.filter((alert) => {
    if (filter === 'unread') return !alert.is_read;
    if (filter === 'flood') return alert.condition_type === 'flood';
    if (filter === 'traffic') return alert.condition_type === 'traffic';
    if (filter === 'crowd') return alert.condition_type === 'crowd';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold shrink-0">
              <Bell size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
                  Live Area Alerts
                </h3>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-extrabold">
                    {unreadCount} new
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Real-time sensor feeds on floods, traffic jams & crowd density
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Filter Bar & Quick Actions */}
        <div className="p-3 bg-slate-100/60 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 overflow-x-auto">
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'unread', label: `Unread (${unreadCount})` },
                { id: 'flood', label: 'Flood' },
                { id: 'traffic', label: 'Traffic' },
                { id: 'crowd', label: 'Crowd' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                onClick={() => setFilter(item.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  filter === item.id
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs border border-slate-200 dark:border-slate-700'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {unreadCount > 0 && (
            <button
              onClick={markAllAlertsRead}
              className="px-2.5 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-[11px] font-bold transition-colors flex items-center gap-1 shrink-0"
            >
              <CheckCheck size={14} className="text-emerald-500" />
              <span>Mark All Read</span>
            </button>
          )}
        </div>

        {/* Alerts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredAlerts.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <Info className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                No alerts found
              </p>
              <p className="text-xs text-slate-400">
                All clear in this category! Conditions are safe across monitored locations.
              </p>
            </div>
          ) : (
            filteredAlerts.map((alert) => {
              const store = stores.find((s) => s.id === alert.store_id);

              let icon = <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />;
              if (alert.condition_type === 'traffic') {
                icon = <Car className="w-5 h-5 text-sky-600 shrink-0" />;
              } else if (alert.condition_type === 'crowd') {
                icon = <Users className="w-5 h-5 text-amber-600 shrink-0" />;
              } else if (alert.condition_type === 'weather') {
                icon = <Sun className="w-5 h-5 text-indigo-600 shrink-0" />;
              }

              return (
                <div
                  key={alert.id}
                  onClick={() => {
                    markAlertRead(alert.id);
                    if (store) {
                      navigateToStoreDetails(store.id);
                      onClose();
                    }
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 group ${
                    !alert.is_read
                      ? 'bg-rose-50/60 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/60 shadow-xs hover:border-rose-300'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-xl shrink-0 ${
                      !alert.is_read
                        ? 'bg-white dark:bg-rose-950 border border-rose-200 dark:border-rose-900'
                        : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {icon}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <h4
                          className={`text-xs sm:text-sm font-bold truncate ${
                            !alert.is_read
                              ? 'text-slate-900 dark:text-slate-100'
                              : 'text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {store ? store.name : 'Area Risk Alert'}
                        </h4>
                        {!alert.is_read && (
                          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                        )}
                      </div>
                      <span className="text-[10px] font-semibold text-slate-400 whitespace-nowrap">
                        {new Date(alert.created_at).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <p
                      className={`text-xs leading-relaxed ${
                        !alert.is_read
                          ? 'text-slate-800 dark:text-slate-200'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {alert.message}
                    </p>

                    {store && (
                      <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-sky-600 dark:text-sky-400 group-hover:underline">
                        <span>View store conditions</span>
                        <ExternalLink size={12} />
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between text-xs text-slate-500">
          <span>Live sensor updates active</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
